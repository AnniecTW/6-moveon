# A8: Semantic Relationships and Retrieval — MoveOn Policy RAG

A Retrieval-Augmented Generation system over the **MoveOn Marketplace Policy** (67 clauses, 6,684 words).
It compares 3 embedding models (BGE small 384-d, base 768-d, large 1024-d) × 3 chunking strategies
(fixed length, overlapping paragraph, hybrid/strategic), with the team's A7 generator **Qwen/Qwen3-4B**
held constant in every experiment.

## Required files

| File | Contents |
|---|---|
| `rag_system.ipynb` | Full implementation and experiments, Parts 1–4, with saved outputs |
| `rag_analysis.md` | Evaluation tables, embedding and chunking comparisons, data scaling, failure analysis, cost analysis, RAG vs alternatives, system design and diagram |
| `requirements.txt` | All dependencies |
| `README.md` | This file |

## Folder layout

```
rag_system.ipynb          notebook (run from this folder)
rag_analysis.md           written analysis for Parts 1-4
requirements.txt
data/                     source PDF, 67 extracted clauses, chunk files, chunking rules and audits
src/
  rag_core.py             Part 1.1-1.2: PDF clause extraction and the three chunking strategies
  chunking_report.py      Part 1.2: chunk audit
  part3_analysis.py       Part 3: verifies the failure cases and builds the before/after comparison
  part4_cost_analysis.py  Part 4: cost measurements, top-k chart and system design diagram
A8_results/
  Part1/<run id>/         9 embedding indices (vectors.npy + metadata.json), retrieval and answer traces
  Part2/20261031/         90 experiment traces (JSONL), reviewed scores (CSV), full appendix (MD)
  Part3/                  failure audit, chunk-size comparison, selected configuration
  Part4/                  cost analysis (MD/JSON), top-k chart, system design diagram (PNG)
```

All paths are relative to this folder.

## Setup

**Option A — Google Colab (recommended, used for the recorded runs)**

1. Open `rag_system.ipynb` in Colab and choose **Runtime → Change runtime type → T4 GPU**.
2. **Runtime → Run all.** When the data cell asks for a file, upload this submission ZIP; it is extracted automatically.
3. Colab already has PyTorch; the first code cell installs the other pinned packages. If it says NumPy was updated, restart the runtime and run all again.

**Option B — local machine**

```bash
python3 -m venv .venv
```

```bash
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
```

```bash
jupyter notebook rag_system.ipynb
```

Use Python 3.11–3.13 (on Windows, activate with `.venv\Scripts\activate`). Start Jupyter **from this folder**, then choose **Run all**. The notebook uses a CUDA GPU if present, otherwise Apple MPS, otherwise CPU (CPU generation is slow).

## What running the notebook does

| Step | Work | Notes |
|---|---|---|
| Part 1 | Loads the prepared chunks, encodes them with the 3 BGE models into 9 indices, retrieves top-3 for the integration question, generates 9 answers with Qwen3-4B | Downloads ~10 GB of models from Hugging Face on first run (no login needed) |
| Part 2 | 5 queries × 9 configurations × 2 corpus sizes = 90 retrieval + generation runs | About 7 s per answer on a T4 |
| Part 3 | Verifies the four failure cases and rebuilds the before/after comparison from the reviewed Part 2 results | No GPU, a few seconds |
| Part 4 | Measures cost drivers, writes the cost report, chart and system diagram | No GPU, a few seconds |

New runs write to `outputs/run_<id>/` and `A8_results/Part2/<run id>/`. They do not overwrite the reviewed results in `A8_results/Part2/20261031/`, which `rag_analysis.md` and Parts 3–4 use. Generated answers can differ slightly between GPU types, so the hand-reviewed scores apply to the recorded run.

### Parts 3 and 4 without a GPU

```bash
python src/part3_analysis.py
```

```bash
python src/part4_cost_analysis.py
```

Both read only the saved results and need only `numpy` and `matplotlib`.

## Models

| Role | Model | Notes |
|---|---|---|
| Embedding, small | `BAAI/bge-small-en-v1.5` | 384-d, 33 M parameters |
| Embedding, medium | `BAAI/bge-base-en-v1.5` | 768-d, 109 M parameters |
| Embedding, large | `BAAI/bge-large-en-v1.5` | 1024-d, 335 M parameters |
| Generation (from A7) | `Qwen/Qwen3-4B` | FP16, thinking off, greedy decoding, max 512 new tokens; same for all experiments |

All model revisions are pinned in the notebook.
