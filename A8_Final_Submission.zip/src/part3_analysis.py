"""Verify Part 2 failures and report the completed Part 3 comparison."""

from __future__ import annotations

import csv
import json
import re
import time
from functools import wraps
from pathlib import Path
from typing import Any, Callable


WORKFLOW_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = WORKFLOW_DIR.parent
BASELINE_DIR = PROJECT_ROOT / "A8_results" / "Part2" / "20261031"
PART3_DIR = PROJECT_ROOT / "A8_results" / "Part3"
DETAIL_PATH = BASELINE_DIR / "experiment_results.jsonl"
TABLE_PATH = BASELINE_DIR / "evaluation_table.csv"
OUTPUT_PATH = PART3_DIR / "citation_guard_results.jsonl"
CHUNK_COMPARISON_PATH = PART3_DIR / "chunk_size_comparison.json"
REPORT_PATH = PART3_DIR / "part3_analysis.md"
CHUNK_BEFORE_ID = "large_67_clauses__bge_small__hybrid_strategic__bundle_discount"
CHUNK_AFTER_ID = "large_67_clauses__bge_small__fixed_length__bundle_discount"
SELECTED_CONFIG_PATH = PART3_DIR / "selected_configuration.json"
_CITATION_RE = re.compile(r"\[(\d+\.\d+)\]")
_SAFE_ABSTENTION = (
    "I can't verify the generated answer because it cites a policy clause that "
    "was not included in the retrieved evidence. The available context is "
    "insufficient to support that answer."
)

FAILURE_CASES = {
    "large_67_clauses__bge_small__fixed_length__bundle_three_items": {
        "title": "Contradictory Bundle answer",
        "cause": "Generation consistency",
        "diagnosis": (
            "The answer opens with a categorical 'No' but later says the policy "
            "does not establish a three-item limit. Retrieved [6.3] and [6.4] "
            "cover Bundle conditions, but do not state that numeric restriction."
        ),
    },
    "large_67_clauses__bge_small__hybrid_strategic__bundle_discount": {
        "title": "Unsupported negotiation claim",
        "cause": "Generation inference (retrieval contributes)",
        "diagnosis": (
            "The answer says a Buyer may negotiate the discount. Retrieved "
            "[6.2], [6.4], and [8.5] do not establish a negotiation right; the "
            "price cap and agreed-price rule do not entail one."
        ),
    },
    "large_67_clauses__bge_small__hybrid_strategic__return_item": {
        "title": "Incorrect clause citation",
        "cause": "Generation / citation control",
        "diagnosis": (
            "The answer attributes the no-penalty statement to [8.2], which "
            "was not retrieved. The included context contains [6.2], [8.5], "
            "and [13.1]."
        ),
    },
    "small_20_clause_subset__bge_large__hybrid_strategic__giveaway_donation": {
        "title": "Overclaim with missing policy evidence",
        "cause": "Corpus boundary and generation",
        "diagnosis": (
            "Clause [6.3], the direct Giveaway rule, is outside the 20-clause "
            "subset and absent from top-k. The answer nevertheless infers that "
            "a donation would likely violate the policy."
        ),
    },
}


def _read_baseline_records(path: Path = DETAIL_PATH) -> dict[str, dict[str, Any]]:
    if not path.is_file():
        raise FileNotFoundError(f"Part 2 detail file not found: {path}")
    records: dict[str, dict[str, Any]] = {}
    with path.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            record = json.loads(line)
            record_id = record.get("record_id")
            if not isinstance(record_id, str):
                raise ValueError(f"Missing record_id on JSONL line {line_number}")
            if record_id in records:
                raise ValueError(f"Duplicate Part 2 record: {record_id}")
            records[record_id] = record

    missing = set(FAILURE_CASES) - records.keys()
    if missing:
        raise ValueError(f"Part 2 baseline is missing failure records: {sorted(missing)}")
    return records


def guard_answer(answer: str, included_hits: list[dict[str, Any]]) -> dict[str, Any]:
    """Reject generated answers that cite clauses absent from their context."""
    if not isinstance(answer, str) or not answer.strip():
        raise ValueError("answer must be a nonempty string")
    if not isinstance(included_hits, list):
        raise TypeError("included_hits must be a list")

    allowed = {
        clause_id
        for hit in included_hits
        for clause_id in hit.get("paragraph_ids", [])
        if isinstance(clause_id, str)
    }
    cited = list(dict.fromkeys(_CITATION_RE.findall(answer)))
    invalid = [clause_id for clause_id in cited if clause_id not in allowed]
    triggered = bool(invalid)
    return {
        "answer": _SAFE_ABSTENTION if triggered else answer,
        "triggered": triggered,
        "cited_clause_ids": cited,
        "invalid_clause_ids": invalid,
        "included_clause_ids": sorted(allowed),
        "reason": "citation_not_in_included_evidence" if triggered else None,
    }


def install_citation_guard(
    generate_answer: Callable[..., dict[str, Any]],
) -> Callable[..., dict[str, Any]]:
    """Wrap the notebook generator so invalid citations cannot reach users."""
    if getattr(generate_answer, "_part3_citation_guard_installed", False):
        return generate_answer

    @wraps(generate_answer)
    def guarded_generate_answer(*args: Any, **kwargs: Any) -> dict[str, Any]:
        generated = generate_answer(*args, **kwargs)
        if not isinstance(generated, dict) or not isinstance(generated.get("answer"), str):
            raise TypeError("generate_answer must return a dict containing a string answer")

        guard = guard_answer(generated["answer"], generated.get("included_hits", []))
        result = dict(generated)
        result["citation_guard"] = {key: value for key, value in guard.items() if key != "answer"}
        if guard["triggered"]:
            result["raw_answer"] = result["answer"]
            result["answer"] = guard["answer"]
            flags = list(result.get("review_flags", []))
            if "citation_guard_rejected_answer" not in flags:
                flags.append("citation_guard_rejected_answer")
            result["review_flags"] = flags
            result["status"] = "completed_with_review_flags"
        return result

    setattr(guarded_generate_answer, "_part3_citation_guard_installed", True)
    return guarded_generate_answer


def _read_reviewed_scores(path: Path = TABLE_PATH) -> dict[str, dict[str, str]]:
    if not path.is_file():
        raise FileNotFoundError(f"Part 2 evaluation table not found: {path}")
    with path.open(encoding="utf-8-sig", newline="") as source:
        rows = csv.DictReader(source)
        required = {
            "record_id",
            "answer_relevance_1_3",
            "groundedness_1_3",
            "latency_seconds",
        }
        missing = required - set(rows.fieldnames or [])
        if missing:
            raise ValueError(f"Part 2 evaluation table is missing columns: {sorted(missing)}")
        return {
            row["record_id"]: row
            for row in rows
            if row.get("record_id") in (set(FAILURE_CASES) | {CHUNK_AFTER_ID})
        }


def _verify_failure(record_id: str, record: dict[str, Any]) -> None:
    answer = record.get("answer", "")
    hits = record.get("included_hits", [])
    if not isinstance(answer, str) or not isinstance(hits, list) or not hits:
        raise ValueError(f"Failure record has no answer or included evidence: {record_id}")
    included = {
        clause_id
        for hit in hits
        for clause_id in hit.get("paragraph_ids", [])
        if isinstance(clause_id, str)
    }

    if record_id.endswith("bundle_three_items"):
        if not {"6.3", "6.4"}.issubset(included):
            raise ValueError("Bundle contradiction trace no longer includes [6.3] and [6.4]")
        if not answer.lstrip().startswith("No,") or "does not explicitly restrict" not in answer.lower():
            raise ValueError("Bundle contradiction trace no longer starts with the contradictory 'No' claim")
    elif record_id.endswith("bundle_discount"):
        if "6.4" not in included or "may negotiate" not in answer.lower():
            raise ValueError("Negotiation failure could not be verified against its trace")
    elif record_id.endswith("return_item"):
        citation_audit = record.get("citation_audit", {})
        if "8.2" not in citation_audit.get("invalid_clause_ids", []) or "6.2" not in included:
            raise ValueError("Incorrect-citation failure could not be verified against its trace")
    elif record_id.endswith("giveaway_donation"):
        if "6.3" in included or "likely contradict" not in answer.lower():
            raise ValueError("Small-corpus overclaim could not be verified against its trace")


def run_part3_analysis() -> dict[str, Path]:
    """Verify four saved failures, apply the citation guard, and write Part 3 outputs."""
    records = _read_baseline_records()
    scores = _read_reviewed_scores()
    if set(scores) != (set(FAILURE_CASES) | {CHUNK_AFTER_ID}):
        raise ValueError("Part 2 evaluation table does not contain all selected failure records")

    PART3_DIR.mkdir(parents=True, exist_ok=True)
    guarded_records = []
    for record_id, failure in FAILURE_CASES.items():
        record = records[record_id]
        _verify_failure(record_id, record)
        started = time.perf_counter()
        guard = guard_answer(record["answer"], record["included_hits"])
        guard_latency_ms = (time.perf_counter() - started) * 1000
        guarded_records.append(
            {
                "record_id": record_id,
                "failure": failure["title"],
                "root_cause": failure["cause"],
                "retrieved_chunk_ids": [
                    hit["chunk_id"] for hit in record["included_hits"]
                ],
                "retrieved_clause_ids": sorted(
                    {
                        clause_id
                        for hit in record["included_hits"]
                        for clause_id in hit.get("paragraph_ids", [])
                    }
                ),
                "baseline_answer": record["answer"],
                "baseline_citation_audit": record.get("citation_audit", {}),
                "guarded_answer": guard["answer"],
                "citation_guard": {key: value for key, value in guard.items() if key != "answer"},
                "baseline_latency_seconds": float(scores[record_id]["latency_seconds"]),
                "guard_latency_ms": guard_latency_ms,
            }
        )

    with OUTPUT_PATH.open("w", encoding="utf-8", newline="\n") as output:
        for record in guarded_records:
            output.write(json.dumps(record, ensure_ascii=False) + "\n")

    before = records[CHUNK_BEFORE_ID]
    after = records[CHUNK_AFTER_ID]
    for field in ("query", "embedding_model_id", "generation_model_id", "generation_model_revision", "generation_settings", "corpus_size", "top_k"):
        if before[field] != after[field]:
            raise ValueError(f"Chunk-size comparison changed {field}")
    if before["chunk_strategy"] != "hybrid_strategic" or after["chunk_strategy"] != "fixed_length":
        raise ValueError("Chunk-size comparison uses unexpected strategies")
    chunk_comparison = {
        "method": "paired saved Part 2 results; chunk size and boundaries differ",
        "question": before["query"],
        "controlled": {field: before[field] for field in ("embedding_model_id", "generation_model_id", "generation_model_revision", "generation_settings", "corpus_size", "top_k")},
        "before": {
            "record_id": CHUNK_BEFORE_ID,
            "chunking": "clause-sized hybrid_strategic chunks",
            "retrieved_chunk_ids": before["included_chunk_ids"],
            "retrieved_chunk_word_counts": [hit["word_count"] for hit in before["included_hits"]],
            "retrieved_clause_ids": sorted({p for hit in before["included_hits"] for p in hit["paragraph_ids"]}),
            "answer": before["answer"],
            "context_relevance_1_3": int(scores[CHUNK_BEFORE_ID]["context_relevance_1_3"]),
            "context_completeness_1_3": int(scores[CHUNK_BEFORE_ID]["context_completeness_1_3"]),
            "answer_relevance_1_3": int(scores[CHUNK_BEFORE_ID]["answer_relevance_1_3"]),
            "groundedness_1_3": int(scores[CHUNK_BEFORE_ID]["groundedness_1_3"]),
            "latency_seconds": float(scores[CHUNK_BEFORE_ID]["latency_seconds"]),
        },
        "after": {
            "record_id": CHUNK_AFTER_ID,
            "chunking": "180-word target fixed_length chunks",
            "retrieved_chunk_ids": after["included_chunk_ids"],
            "retrieved_chunk_word_counts": [hit["word_count"] for hit in after["included_hits"]],
            "retrieved_clause_ids": sorted({p for hit in after["included_hits"] for p in hit["paragraph_ids"]}),
            "answer": after["answer"],
            "context_relevance_1_3": int(scores[CHUNK_AFTER_ID]["context_relevance_1_3"]),
            "context_completeness_1_3": int(scores[CHUNK_AFTER_ID]["context_completeness_1_3"]),
            "answer_relevance_1_3": int(scores[CHUNK_AFTER_ID]["answer_relevance_1_3"]),
            "groundedness_1_3": int(scores[CHUNK_AFTER_ID]["groundedness_1_3"]),
            "latency_seconds": float(scores[CHUNK_AFTER_ID]["latency_seconds"]),
        },
    }
    CHUNK_COMPARISON_PATH.write_text(json.dumps(chunk_comparison, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    selected_config = {
        "scope": "Bundle-discount question in the 67-clause corpus",
        "query_id": "bundle_discount",
        "embedding_model_id": after["embedding_model_id"],
        "chunk_strategy": after["chunk_strategy"],
        "chunk_target_words": 180,
        "top_k": after["top_k"],
        "generation_model_id": after["generation_model_id"],
        "source_record_id": CHUNK_AFTER_ID,
        "selection_basis": "reviewed paired Part 2 answer; case-specific, not a general chunk-size optimum",
    }
    SELECTED_CONFIG_PATH.write_text(json.dumps(selected_config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    _write_report(guarded_records, scores, records)
    return {"report": REPORT_PATH, "results": OUTPUT_PATH, "chunk_comparison": CHUNK_COMPARISON_PATH, "selected_configuration": SELECTED_CONFIG_PATH}


def _write_report(
    guarded_records: list[dict[str, Any]],
    scores: dict[str, dict[str, str]],
    baseline_records: dict[str, dict[str, Any]],
) -> None:
    by_id = {record["record_id"]: record for record in guarded_records}
    lines = [
        "# A8 Part 3: Failure Analysis and Improvement",
        "",
        "## Method",
        "",
        "Four failure records were selected from the completed Part 2 run. Each was checked against its saved `included_hits`, clause IDs, answer, and citation audit in `experiment_results.jsonl`; reviewed answer scores and total latency come from `evaluation_table.csv`. The improvement compares two saved configurations with the same query, source, embedding model, and generator; chunk size, boundaries, and retrieved context differ.",
        "",
        "## Failure cases and root causes",
        "",
        "| Failure record | Observed failure | Retrieved evidence | Root cause |",
        "|---|---|---|---|",
    ]
    for record_id, failure in FAILURE_CASES.items():
        record = by_id[record_id]
        clause_ids = sorted(
            {
                clause_id
                for hit in baseline_records[record_id]["included_hits"]
                for clause_id in hit.get("paragraph_ids", [])
            }
        )
        lines.append(
            f"| `{record_id}` | {failure['title']} | "
            f"{', '.join(f'[{clause_id}]' for clause_id in clause_ids)} | "
            f"{failure['cause']}. {failure['diagnosis']} |"
        )

    lines.extend([
        "",
        "### Step 3.2 factor assessment by failure",
        "",
        "| Failure | Chunking | Embedding model | Query formulation | Supported primary cause |",
        "|---|---|---|---|---|",
        "| Bundle item count | Relevant [6.4] was retrieved, so no demonstrated chunk gap. | No model-specific cause shown. | The question states the quantity clearly. | Generation contradiction. |",
        "| Bundle discount | [6.4] was retrieved; chunk boundaries may affect the answer, but the record does not isolate them. | No model-specific cause shown. | The question directly asks about negotiation. | Unsupported generation inference. |",
        "| Return citation | The cited [8.2] was absent while relevant [6.2] was present. | No model-specific cause shown. | The return question was specific enough to retrieve related clauses. | Generation citation error. |",
        "| Giveaway donation | [6.3] was excluded from the 20-clause corpus before chunking. | An embedding model cannot retrieve an excluded clause. | The question directly names a donation and a free item. | Corpus coverage gap, then generation overclaim. |",
    ])

    citation_id = "large_67_clauses__bge_small__hybrid_strategic__return_item"
    citation_record = by_id[citation_id]
    invalid_id = citation_record["citation_guard"]["invalid_clause_ids"][0]
    prompt_id = "large_67_clauses__bge_small__hybrid_strategic__bundle_discount"
    prompt_scores = scores[prompt_id]
    prompt_baseline_answer = (
        baseline_records[prompt_id]["answer"].replace("|", "&#124;").replace("\n", " ")
    )
    lines.extend(
        [
            "",
            "The first two failures have relevant clauses in the retrieved context, so their primary cause is unsupported generation rather than missing corpus coverage. In the small-corpus case, [6.3] is excluded before retrieval, making an evidence-based answer impossible; the generator should abstain instead of infer a policy rule. The citation failure is directly testable because its cited [8.2] is absent while [6.2], [8.5], and [13.1] are included.",
            "",
            "## Step 3.3: Implemented improvement — adjust chunk size",
            "",
            "The selected assignment option is **adjust chunk size**. For the Bundle discount question, switch from clause-sized `hybrid_strategic` chunks to the existing `fixed_length` index with a 180-word soft target. These are two completed Part 2 runs with the same query, 67-clause corpus, BGE-small embedding model, top-k=3, Qwen generation model, prompt, and decoding settings. The chunk boundaries and retrieved passages change with the size setting, so this paired observation does not isolate size alone.",
            "",
            "### Before vs. after (actual saved model outputs)",
            "",
            "| Measure | Before: clause-sized chunks | After: 180-word target chunks |",
            "|---|---|---|",
            f"| Retrieved chunks | {', '.join(baseline_records[prompt_id]['included_chunk_ids'])} | {', '.join(baseline_records[CHUNK_AFTER_ID]['included_chunk_ids'])} |",
            f"| Retrieved chunk word counts | {', '.join(str(hit['word_count']) for hit in baseline_records[prompt_id]['included_hits'])} | {', '.join(str(hit['word_count']) for hit in baseline_records[CHUNK_AFTER_ID]['included_hits'])} |",
            f"| Answer | {prompt_baseline_answer} | {baseline_records[CHUNK_AFTER_ID]['answer'].replace('|', '&#124;').replace(chr(10), ' ')} |",
            f"| Reviewed answer relevance / groundedness | {prompt_scores['answer_relevance_1_3']}/3; {prompt_scores['groundedness_1_3']}/3 | {scores[CHUNK_AFTER_ID]['answer_relevance_1_3']}/3; {scores[CHUNK_AFTER_ID]['groundedness_1_3']}/3 |",
            f"| Total query latency | {float(prompt_scores['latency_seconds']):.3f}s | {float(scores[CHUNK_AFTER_ID]['latency_seconds']):.3f}s |",
            "",
            "The after answer says the supplied policy does not establish whether a Bundle discount is fixed or negotiable. This removes the unsupported negotiation claim seen before; reviewed groundedness rises from 1/3 to 3/3 for this paired question. The fixed-length top-k does not include [6.4], so this is a case-specific improvement, not evidence that larger chunks always perform better. The complete paired data is in `chunk_size_comparison.json`.",
            "",
            "The selected configuration for this question is saved in `selected_configuration.json`. This applies the observed choice to the handoff configuration; it does not claim a new model run or improvement for other questions. The citation guard is a separate output check; it cannot detect unsupported claims that cite clauses present in context.",
            "",
            f"The additional citation guard catches the separate return-item error: the Part 2 answer cites missing [{invalid_id}], while the retrieved context contains [6.2], [8.5], and [13.1]. The baseline answer/guarded abstention and audit are retained in `citation_guard_results.jsonl`.",
            "",
            "## Reproduction",
            "",
            "From the assignment folder, `python src/part3_analysis.py` verifies the saved failures and regenerates the analysis, paired comparison, and selected configuration without loading models. The final Part 3 notebook code cell runs the same verifier. Running all notebook cells reruns Parts 1 and 2.",
            "",
        ]
    )
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    paths = run_part3_analysis()
    print(f"Part 3 report: {paths['report']}")
    print(f"Part 3 guard results: {paths['results']}")
    print(f"Part 3 selected configuration: {paths['selected_configuration']}")
