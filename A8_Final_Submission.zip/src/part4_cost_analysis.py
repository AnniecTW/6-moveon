"""Part 4: cost and system-design analysis

Run from the submission folder:  python src/part4_cost_analysis.py
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from statistics import mean, median

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parent.parent
PART2_DIR = PROJECT_ROOT / "A8_results" / "Part2" / "20261031"
PART1_DIR = PROJECT_ROOT / "A8_results" / "Part1" / "20261031T043110Z_6963cd94"
DATA_DIR = PROJECT_ROOT / "data"
PART4_DIR = PROJECT_ROOT / "A8_results" / "Part4"

MODELS = [  # key, model id, dimension, approximate parameters
    ("bge_small", "BAAI/bge-small-en-v1.5", 384, 33_400_000),
    ("bge_base", "BAAI/bge-base-en-v1.5", 768, 109_000_000),
    ("bge_large", "BAAI/bge-large-en-v1.5", 1024, 335_000_000),
]
STRATEGIES = ["fixed_length", "overlapping_paragraph", "hybrid_strategic"]
STRATEGY_LABELS = {"fixed_length": "Fixed length", "overlapping_paragraph": "Overlapping paragraph",
                   "hybrid_strategic": "Hybrid strategic"}
TOP_K_VALUES = [1, 3, 5, 10]

# Planning assumptions for Step 4.3. They are not measurements; change them here.
ASSUMPTIONS = {
    "users_per_day": 10_000,
    "queries_per_user_per_day": 3,
    "peak_hour_share_of_daily_traffic": 0.15,
    "answer_cache_hit_rate": 0.30,
    "continuous_batching_throughput_gain": 8,
    "redundancy_spare_gpus": 1,
    "gpu_hourly_price_usd": 0.35,  # illustrative on-demand T4-class price; replace with your provider's
}

# Reference palette, light mode, categorical slots 1-3 (validated all-pairs for three series).
SERIES_COLORS = {"fixed_length": "#2a78d6", "overlapping_paragraph": "#eb6834", "hybrid_strategic": "#1baf7a"}
TEXT_PRIMARY, TEXT_SECONDARY, GRID, SURFACE = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"


def _read_inputs():
    records = [json.loads(line) for line in (PART2_DIR / "experiment_results.jsonl").open(encoding="utf-8")]
    with (PART2_DIR / "evaluation_table.csv").open(encoding="utf-8-sig", newline="") as source:
        scores = {row["record_id"]: row for row in csv.DictReader(source)}
    if len(records) != 90 or set(scores) != {r["record_id"] for r in records}:
        raise ValueError("Expected the 90 reviewed Part 2 records")
    chunks = {s: json.loads((DATA_DIR / f"chunks_{s}.json").read_text(encoding="utf-8")) for s in STRATEGIES}
    index_summary = json.loads((PART1_DIR / "index_summary.json").read_text(encoding="utf-8"))
    return records, scores, chunks, index_summary


def _fit(features, target):
    x = np.column_stack([np.ones(len(target)), *features])
    y = np.asarray(target, dtype=float)
    coefficients, *_ = np.linalg.lstsq(x, y, rcond=None)
    r2 = 1 - float(((y - x @ coefficients) ** 2).sum() / ((y - y.mean()) ** 2).sum())
    return [float(c) for c in coefficients], r2


def analyse() -> dict:
    records, scores, chunks, index_summary = _read_inputs()
    large = [r for r in records if r["corpus_size"] == "large_67_clauses"]

    # Where does query time go? (all 90 records)
    stage_share = {
        "query_embedding_seconds_median_fresh": median(r["retrieval"]["timings"]["query_encoding_seconds"] for r in records
                                                       if not r["retrieval"]["query_embedding_reused"]),
        "similarity_search_ms_mean": 1000 * mean(r["retrieval"]["timings"]["similarity_ranking_seconds"] for r in records),
        "generation_seconds_mean": mean(r["timings"]["generation_seconds"] for r in records),
        "total_seconds_mean": mean(r["timings"]["total_query_seconds"] for r in records),
    }
    stage_share["generation_share_of_total"] = mean(
        r["timings"]["generation_seconds"] / r["timings"]["total_query_seconds"] for r in records)

    # Generation time vs tokens, and prompt tokens vs retrieved words.
    gen_coef, gen_r2 = _fit([[r["input_tokens"] for r in records], [r["output_tokens"] for r in records]],
                            [r["timings"]["generation_seconds"] for r in records])
    tok_coef, tok_r2 = _fit([[sum(h["word_count"] for h in r["included_hits"]) for r in records]],
                            [r["input_tokens"] for r in records])
    fits = {
        "generation_seconds": {"intercept": gen_coef[0], "per_input_token": gen_coef[1],
                               "per_output_token": gen_coef[2], "r2": gen_r2,
                               "output_to_input_token_cost_ratio": gen_coef[2] / gen_coef[1]},
        "prompt_tokens": {"fixed_overhead_tokens": tok_coef[0], "tokens_per_retrieved_word": tok_coef[1], "r2": tok_r2},
    }

    # 4.1a Embedding size.
    summary_by_config = {row["config_id"]: row for row in index_summary}
    embedding_rows = []
    for key, model_id, dim, params in MODELS:
        model_records = [r for r in records if r["config_id"].startswith(key + "__")]
        fresh = [r["retrieval"]["timings"]["query_encoding_seconds"] for r in model_records
                 if not r["retrieval"]["query_embedding_reused"]]
        index_bytes = {s: (PART1_DIR / "indices" / f"{key}__{s}" / "vectors.npy").stat().st_size for s in STRATEGIES}
        embedding_rows.append({
            "model": model_id, "dimension": dim, "parameters_millions": params / 1e6,
            "bytes_per_vector": dim * 4,
            "index_kib_hybrid_66_chunks": index_bytes["hybrid_strategic"] / 1024,
            "projected_gib_per_million_chunks": dim * 4 * 1_000_000 / 2**30,
            "query_embedding_ms_median": 1000 * median(fresh),
            "document_encoding_seconds_all_strategies": sum(
                summary_by_config[f"{key}__{s}"]["encoding_seconds"] for s in STRATEGIES),
            "model_load_seconds": summary_by_config[f"{key}__fixed_length"]["model_load_seconds"],
            "mean_context_relevance": mean(float(scores[r["record_id"]]["context_relevance_1_3"]) for r in model_records),
            "mean_groundedness": mean(float(scores[r["record_id"]]["groundedness_1_3"]) for r in model_records),
            "mean_generation_seconds": mean(r["timings"]["generation_seconds"] for r in model_records),
        })

    # 4.1b Chunk size (67-clause corpus, top-k = 3).
    chunk_rows = []
    for s in STRATEGIES:
        rs = [r for r in large if r["chunk_strategy"] == s]
        chunk_rows.append({
            "strategy": s, "chunks": len(chunks[s]),
            "mean_words_per_chunk": mean(c["word_count"] for c in chunks[s]),
            "indexed_words": sum(c["word_count"] for c in chunks[s]),
            "mean_retrieved_words_top3": mean(sum(h["word_count"] for h in r["included_hits"]) for r in rs),
            "mean_input_tokens": mean(r["input_tokens"] for r in rs),
            "mean_output_tokens": mean(r["output_tokens"] for r in rs),
            "mean_generation_seconds": mean(r["timings"]["generation_seconds"] for r in rs),
            "mean_groundedness": mean(float(scores[r["record_id"]]["groundedness_1_3"]) for r in rs),
        })

    # 4.1c Top-k: project prompt size from the measured token fit.
    overhead, per_word = tok_coef
    per_chunk_words = {row["strategy"]: row["mean_retrieved_words_top3"] / 3 for row in chunk_rows}
    topk_rows = []
    for s in STRATEGIES:
        for k in TOP_K_VALUES:
            tokens = overhead + per_word * per_chunk_words[s] * k
            topk_rows.append({"strategy": s, "top_k": k, "projected_input_tokens": tokens,
                              "projected_prefill_seconds": tokens * gen_coef[1]})
    corpus_words = sum(c["word_count"] for c in chunks["hybrid_strategic"])
    whole_corpus_tokens = overhead + per_word * corpus_words

    # 4.3 Load estimate for 10K users/day (assumption-driven).
    a = ASSUMPTIONS
    hybrid = next(row for row in chunk_rows if row["strategy"] == "hybrid_strategic")
    queries_per_day = a["users_per_day"] * a["queries_per_user_per_day"]
    peak_qps = queries_per_day * a["peak_hour_share_of_daily_traffic"] / 3600
    seconds_per_query = hybrid["mean_generation_seconds"]
    baseline_gpus = int(np.ceil(peak_qps * seconds_per_query))  # batch-1, one answer per GPU at a time
    llm_qps = peak_qps * (1 - a["answer_cache_hit_rate"])
    optimized_gpus = (max(1, int(np.ceil(llm_qps * seconds_per_query / a["continuous_batching_throughput_gain"])))
                      + a["redundancy_spare_gpus"])
    scaling = {
        "queries_per_day": queries_per_day, "average_qps": queries_per_day / 86400, "peak_qps": peak_qps,
        "generation_seconds_per_query_measured_T4": seconds_per_query,
        "input_tokens_per_day": queries_per_day * hybrid["mean_input_tokens"],
        "output_tokens_per_day": queries_per_day * hybrid["mean_output_tokens"],
        "baseline_batch1_gpus_at_peak": baseline_gpus,
        "baseline_gpu_cost_per_day_usd": baseline_gpus * 24 * a["gpu_hourly_price_usd"],
        "optimized_gpus_at_peak": optimized_gpus,
        "optimized_gpu_cost_per_day_usd": optimized_gpus * 24 * a["gpu_hourly_price_usd"],
        "query_embeddings_per_day_bge_base": queries_per_day * (1 - a["answer_cache_hit_rate"]),
        "peak_generator_memory_gb": max(r["peak_allocated_gpu_bytes"] for r in records) / 1e9,
    }
    return {"source": {"part2_run": str(PART2_DIR.relative_to(PROJECT_ROOT)), "records": len(records)},
            "stage_latency": stage_share, "fits": fits, "embedding_size": embedding_rows,
            "chunk_size": chunk_rows, "top_k_projection": topk_rows,
            "whole_corpus_prompt_tokens_estimate": whole_corpus_tokens, "assumptions": ASSUMPTIONS,
            "scaling_10k_users": scaling}


def _table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" if i == 0 else "---:" for i in range(len(headers))) + "|"]
    lines += ["| " + " | ".join(str(v) for v in row) + " |" for row in rows]
    return "\n".join(lines)


def render_markdown(result: dict) -> str:
    st, fit, sc, a = result["stage_latency"], result["fits"], result["scaling_10k_users"], result["assumptions"]
    gen, tok = fit["generation_seconds"], fit["prompt_tokens"]
    parts = ["# A8 Part 4: Cost analysis (generated)", "",
             f"Source: `{result['source']['part2_run']}` ({result['source']['records']} reviewed records, Tesla T4). "
             "Measured values come from saved runs; rows marked *projected* or *estimate* are derived from the fits below.", "",
             "## Where query time goes", "",
             _table(["Stage", "Mean time"], [
                 ["Query embedding (fresh encode, median)", f"{st['query_embedding_seconds_median_fresh'] * 1000:.1f} ms"],
                 ["Similarity search (NumPy cosine, top-3)", f"{st['similarity_search_ms_mean']:.2f} ms"],
                 ["LLM generation (Qwen3-4B FP16)", f"{st['generation_seconds_mean']:.2f} s"],
                 ["Total per query", f"{st['total_seconds_mean']:.2f} s"],
                 ["Generation share of total", f"{st['generation_share_of_total'] * 100:.1f}%"]]), "",
             f"Generation seconds = {gen['intercept']:.2f} + {gen['per_input_token'] * 1000:.2f} ms x input tokens + "
             f"{gen['per_output_token'] * 1000:.1f} ms x output tokens (R^2 = {gen['r2']:.3f}). "
             f"One output token costs about {gen['output_to_input_token_cost_ratio']:.0f}x an input token.", "",
             f"Prompt tokens = {tok['fixed_overhead_tokens']:.0f} + {tok['tokens_per_retrieved_word']:.2f} x retrieved words "
             f"(R^2 = {tok['r2']:.3f}).", "",
             "## 4.1a Embedding size", "",
             _table(["Model", "Dim", "Params (M)", "Bytes/vector", "Index, 66 hybrid chunks (KiB)",
                     "Projected GiB per 1M chunks", "Query embed median (ms)", "Mean context relevance", "Mean groundedness"],
                    [[r["model"], r["dimension"], f"{r['parameters_millions']:.0f}", r["bytes_per_vector"],
                      f"{r['index_kib_hybrid_66_chunks']:.0f}", f"{r['projected_gib_per_million_chunks']:.2f}",
                      f"{r['query_embedding_ms_median']:.1f}", f"{r['mean_context_relevance']:.2f}",
                      f"{r['mean_groundedness']:.2f}"] for r in result["embedding_size"]]), "",
             "## 4.1b Chunk size (67 clauses, top-k = 3)", "",
             _table(["Strategy", "Chunks", "Mean words/chunk", "Retrieved words (top-3)", "Mean input tokens",
                     "Mean output tokens", "Mean generation (s)", "Mean groundedness"],
                    [[STRATEGY_LABELS[r["strategy"]], r["chunks"], f"{r['mean_words_per_chunk']:.0f}",
                      f"{r['mean_retrieved_words_top3']:.0f}", f"{r['mean_input_tokens']:.0f}",
                      f"{r['mean_output_tokens']:.0f}", f"{r['mean_generation_seconds']:.2f}",
                      f"{r['mean_groundedness']:.2f}"] for r in result["chunk_size"]]), "",
             "## 4.1c Top-k (projected input tokens)", "",
             _table(["Strategy"] + [f"k = {k}" for k in TOP_K_VALUES],
                    [[STRATEGY_LABELS[s]] + [f"{row['projected_input_tokens']:.0f}" for row in result["top_k_projection"]
                                             if row["strategy"] == s] for s in STRATEGIES]), "",
             f"Placing the whole 6,684-word policy in the prompt instead (pure prompting) is estimated at "
             f"{result['whole_corpus_prompt_tokens_estimate']:,.0f} input tokens per query.", "",
             "## 4.3 Load estimate for 10K users/day", "",
             "Assumptions: " + "; ".join(f"{k} = {v}" for k, v in a.items()) + ".", "",
             _table(["Quantity", "Estimate"], [
                 ["Queries per day", f"{sc['queries_per_day']:,}"],
                 ["Average / peak queries per second", f"{sc['average_qps']:.2f} / {sc['peak_qps']:.2f}"],
                 ["Input / output LLM tokens per day", f"{sc['input_tokens_per_day'] / 1e6:.1f}M / {sc['output_tokens_per_day'] / 1e6:.1f}M"],
                 ["GPUs at peak, batch-1 as in our experiment", f"{sc['baseline_batch1_gpus_at_peak']} (about ${sc['baseline_gpu_cost_per_day_usd']:.0f}/day)"],
                 ["GPUs at peak, with answer cache + continuous batching (+1 spare)", f"{sc['optimized_gpus_at_peak']} (about ${sc['optimized_gpu_cost_per_day_usd']:.0f}/day)"],
                 ["Peak generator GPU memory (measured)", f"{sc['peak_generator_memory_gb']:.1f} GB"]]), ""]
    return "\n".join(parts)


def plot_topk(result: dict, path: Path) -> Path:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=150)
    fig.patch.set_facecolor(SURFACE)
    ax.set_facecolor(SURFACE)
    for s in STRATEGIES:
        rows = [r for r in result["top_k_projection"] if r["strategy"] == s]
        ks, ys = [r["top_k"] for r in rows], [r["projected_input_tokens"] for r in rows]
        ax.plot(ks, ys, color=SERIES_COLORS[s], linewidth=2, marker="o", markersize=6,
                markeredgecolor=SURFACE, markeredgewidth=1.5, label=STRATEGY_LABELS[s])
        ax.annotate(f"{STRATEGY_LABELS[s]}  {ys[-1]:,.0f}", (ks[-1], ys[-1]), xytext=(6, 0),
                    textcoords="offset points", va="center", fontsize=8.5, color=TEXT_PRIMARY)
    measured = {row["strategy"]: row["mean_input_tokens"] for row in result["chunk_size"]}
    ax.scatter([3] * 3, [measured[s] for s in STRATEGIES], s=70, facecolors="none",
               edgecolors=TEXT_SECONDARY, linewidths=1.2, zorder=3, label="Measured mean at k = 3")
    ax.set_xticks(TOP_K_VALUES)
    ax.set_xlim(0.5, 13.5)
    ax.set_xlabel("top-k retrieved chunks", color=TEXT_SECONDARY, fontsize=9)
    ax.set_ylabel("Prompt input tokens", color=TEXT_SECONDARY, fontsize=9)
    ax.set_title("Prompt size grows with top-k x chunk size", loc="left", fontsize=11, color=TEXT_PRIMARY)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.tick_params(colors=TEXT_SECONDARY, labelsize=8.5, length=0)
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.legend(frameon=False, fontsize=8.5, loc="upper left", labelcolor=TEXT_PRIMARY)
    fig.tight_layout()
    fig.savefig(path, facecolor=SURFACE)
    plt.close(fig)
    return path


def plot_system_design(path: Path) -> Path:
    """Draw the serving path (User -> ... -> Response) with the offline ingestion path."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

    fig, ax = plt.subplots(figsize=(12, 5.4), dpi=150)
    fig.patch.set_facecolor(SURFACE)
    ax.set_facecolor(SURFACE)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 5.4)
    ax.axis("off")
    online, offline, guard = "#2a78d6", "#52514e", "#1baf7a"

    def box(x, y, w, h, title, sub, color):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                    facecolor="white", edgecolor=color, linewidth=1.6))
        ax.text(x + w / 2, y + h * 0.68, title, ha="center", va="center", fontsize=9, weight="bold",
                color=TEXT_PRIMARY, linespacing=0.95)
        ax.text(x + w / 2, y + h * 0.3, sub, ha="center", va="center", fontsize=7.2, color=TEXT_SECONDARY)
        return (x, y, w, h)

    def arrow(a, b, color, label=None, style="-|>"):
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle=style, mutation_scale=12, color=color, linewidth=1.4))
        if label:
            ax.text((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + 0.12, label, ha="center", fontsize=6.8, color=TEXT_SECONDARY)

    y, h, w = 3.25, 1.05, 1.52
    steps = [("User", "web / app client"), ("Query", "API gateway, auth,\nrate limit, answer cache"),
             ("Embedding", "bge-base-en-v1.5\n768-d, ~12 ms"), ("Vector Store", "cosine top-k = 3\nNumPy -> FAISS/pgvector"),
             ("Retrieved\nContext", "clause IDs + pages\ntoken budget 4,096"), ("LLM", "Qwen3-4B (A7)\nvLLM, batching"),
             ("Response", "citation guard,\nstream to user")]
    xs = [0.15 + i * 1.69 for i in range(len(steps))]
    boxes = [box(x, y, w, h, t, s, guard if t == "Response" else online) for x, (t, s) in zip(xs, steps)]
    for left, right in zip(boxes, boxes[1:]):
        arrow((left[0] + left[2], y + h / 2), (right[0], y + h / 2), online)
    ax.text(0.15, 4.75, "Online serving path (per query)", fontsize=10.5, weight="bold", color=online)

    # Offline ingestion feeding the vector store.
    oy = 0.7
    ingest = [("Policy PDF", "versioned source"), ("Clause extraction", "67 clauses, audit"),
              ("Hybrid chunking", "whole clauses"), ("Batch embedding", "GPU job, FP32")]
    oxs = [0.15 + i * 1.69 for i in range(len(ingest))]
    oboxes = [box(x, oy, w, 0.95, t, s, offline) for x, (t, s) in zip(oxs, ingest)]
    for left, right in zip(oboxes, oboxes[1:]):
        arrow((left[0] + left[2], oy + 0.475), (right[0], oy + 0.475), offline)
    vs = boxes[3]
    top = oboxes[-1]
    arrow((top[0] + top[2] / 2, oy + 0.95), (vs[0] + vs[2] / 2, y), offline)
    ax.text(vs[0] + vs[2] / 2 + 0.08, (oy + 0.95 + y) / 2, "new index version", fontsize=6.8,
            color=TEXT_SECONDARY, va="center")
    ax.text(0.15, 1.85, "Offline ingestion (on policy change)", fontsize=10.5, weight="bold", color=offline)

    # Monitoring band.
    ax.add_patch(FancyBboxPatch((7.0, 0.7), 4.85, 0.95, boxstyle="round,pad=0.02,rounding_size=0.08",
                                facecolor="white", edgecolor=offline, linewidth=1.2, linestyle="--"))
    ax.text(9.42, 1.33, "Monitoring and evaluation", ha="center", fontsize=9.5, weight="bold", color=TEXT_PRIMARY)
    ax.text(9.42, 0.98, "latency p95, tokens/query, cache hit rate,\ncitation-guard failures, weekly groundedness review",
            ha="center", va="center", fontsize=7.2, color=TEXT_SECONDARY)
    arrow((boxes[6][0] + w / 2, y), (10.6, 1.67), offline, style="-|>")
    fig.tight_layout()
    fig.savefig(path, facecolor=SURFACE)
    plt.close(fig)
    return path


def run_part4_analysis() -> dict[str, Path]:
    PART4_DIR.mkdir(parents=True, exist_ok=True)
    result = analyse()
    outputs = {"cost_json": PART4_DIR / "cost_analysis.json", "cost_report": PART4_DIR / "cost_analysis.md",
               "topk_chart": PART4_DIR / "topk_prompt_tokens.png", "design_diagram": PART4_DIR / "system_design.png"}
    outputs["cost_json"].write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    outputs["cost_report"].write_text(render_markdown(result), encoding="utf-8")
    plot_topk(result, outputs["topk_chart"])
    plot_system_design(outputs["design_diagram"])
    return outputs


if __name__ == "__main__":
    for name, output in run_part4_analysis().items():
        print(f"{name}: {output.relative_to(PROJECT_ROOT)}")
    print()
    print((PART4_DIR / "cost_analysis.md").read_text(encoding="utf-8"))
