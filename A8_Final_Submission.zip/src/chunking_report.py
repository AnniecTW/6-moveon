"""Build and audit Task 2 artifacts without loading any models."""

from hashlib import sha256
import json
from pathlib import Path
from statistics import median

from rag_core import _sentence_ranges, make_chunks


STRATEGIES = ("fixed_length", "overlapping_paragraph", "hybrid_strategic")


def _digest(value):
    return sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                             separators=(",", ":")).encode("utf-8")).hexdigest()


def audit_chunking(paragraphs, chunk_sets, rules):
    """Check exact source coverage and structure; semantic review is separate."""
    by_id = {p["paragraph_id"]: p for p in paragraphs}
    positions = {p["paragraph_id"]: i for i, p in enumerate(paragraphs)}
    breaks = {(b["after"], b["before"]) for b in rules["topic_breaks"]}
    result = {"corpus_sha256": _digest(paragraphs), "rules_sha256": _digest(rules),
              "rules_version": rules["rules_version"], "strategies": {},
              "model_tokenizer_length_preflight": "Checked separately by Task 3; not implied by the chunking audit"}
    if result["corpus_sha256"] != rules["corpus_sha256"]:
        raise ValueError("Chunk audit corpus does not match the approved rules")
    for strategy in STRATEGIES:
        chunks = chunk_sets[strategy]
        coverage = {i: [0] * len(p["text"]) for i, p in by_id.items()}
        if not chunks or len({c["chunk_id"] for c in chunks}) != len(chunks):
            raise ValueError(f"Empty chunks or duplicate IDs: {strategy}")
        for chunk in chunks:
            spans = chunk["source_spans"]
            parts = []
            for span in spans:
                p = by_id[span["paragraph_id"]]
                start, end = span["start_char"], span["end_char"]
                bounds = _sentence_ranges(p["text"])
                if (not 0 <= start < end <= len(p["text"])
                        or start != bounds[span["sentence_start"] - 1][0]
                        or end != bounds[span["sentence_end"] - 1][1]):
                    raise ValueError(f"Invalid sentence/source boundary: {chunk['chunk_id']}")
                parts.append(p["text"][start:end])
                for index in range(start, end):
                    coverage[p["paragraph_id"]][index] += 1
                if strategy != "fixed_length" and (start != 0 or end != len(p["text"])):
                    raise ValueError(f"Whole-paragraph strategy contains a fragment: {chunk['chunk_id']}")
            ids = list(dict.fromkeys(s["paragraph_id"] for s in spans))
            if ("\n\n".join(parts) != chunk["text"] or ids != chunk["paragraph_ids"]
                    or len(chunk["text"].split()) != chunk["word_count"]
                    or chunk["source_pages"] != sorted({page for i in ids for page in by_id[i]["source_pages"]})):
                raise ValueError(f"Text, word count, IDs or pages mismatch: {chunk['chunk_id']}")
            for left, right in zip(ids, ids[1:]):
                if (positions[right] != positions[left] + 1 or (left, right) in breaks
                        or by_id[left]["section_id"] != by_id[right]["section_id"]):
                    raise ValueError(f"Chunk crosses a topic/section boundary: {chunk['chunk_id']}")
        repeated = []
        for clause_id, counts in coverage.items():
            counts = [n for char, n in zip(by_id[clause_id]["text"], counts) if not char.isspace()]
            if min(counts) < 1 or (strategy != "overlapping_paragraph" and max(counts) != 1):
                raise ValueError(f"Missing or unexpected duplicate text: {strategy}, {clause_id}")
            if max(counts) > 1:
                repeated.append(clause_id)
        if strategy == "overlapping_paragraph":
            expected = []
            for i, p in enumerate(paragraphs):
                def adjacent(j):
                    return (0 <= j < len(paragraphs) - 1
                            and paragraphs[j]["section_id"] == paragraphs[j + 1]["section_id"]
                            and (paragraphs[j]["paragraph_id"], paragraphs[j + 1]["paragraph_id"]) not in breaks)
                if adjacent(i):
                    expected.append([p["paragraph_id"], paragraphs[i + 1]["paragraph_id"]])
                elif not adjacent(i - 1):
                    expected.append([p["paragraph_id"]])
            if [c["paragraph_ids"] for c in chunks] != expected:
                raise ValueError("Overlap windows, singleton or final-tail handling is incorrect")
        else:
            for link in rules["linked_clauses"]:
                if not any(c["paragraph_ids"] == link["paragraph_ids"] for c in chunks):
                    raise ValueError(f"Explicit clause link not preserved: {strategy}")
            if strategy == "fixed_length":
                protected = [(x["paragraph_id"], 0, len(by_id[x["paragraph_id"]]["text"]))
                             for x in rules["protected_clauses"]]
                for x in rules["protected_sentence_groups"]:
                    spans = _sentence_ranges(by_id[x["paragraph_id"]]["text"])
                    protected.append((x["paragraph_id"], spans[x["sentence_start"] - 1][0],
                                      spans[x["sentence_end"] - 1][1]))
                for clause_id, start, end in protected:
                    if not any(s["paragraph_id"] == clause_id and s["start_char"] <= start
                               and s["end_char"] >= end for c in chunks for s in c["source_spans"]):
                        raise ValueError(f"Protected meaning unit split: {clause_id}")
            else:
                allowed_links = [x["paragraph_ids"] for x in rules["linked_clauses"]]
                if any(len(c["paragraph_ids"]) > 1 and c["paragraph_ids"] not in allowed_links for c in chunks):
                    raise ValueError("Hybrid contains an undeclared merge")
        lengths = [c["word_count"] for c in chunks]
        distribution = {f"{low}-{high}": sum(low <= n <= high for n in lengths)
                        for low, high in ((1, 79), (80, 139), (140, 179), (180, 219), (220, 259))}
        distribution["260+"] = sum(n >= 260 for n in lengths)
        result["strategies"][strategy] = {
            "chunks_sha256": _digest(chunks), "chunk_count": len(chunks),
            "minimum_words": min(lengths), "maximum_words": max(lengths),
            "median_words": median(lengths), "stored_words": sum(lengths),
            "length_distribution": distribution, "covered_paragraphs": len(coverage),
            "repeated_paragraph_ids": repeated, "structural_checks": "passed",
        }
    return result


def write_chunking_report(paragraphs, chunk_sets, rules, audit):
    by_id = {p["paragraph_id"]: p for p in paragraphs}
    lines = ["# Task 2 chunking and semantic-boundary report\n",
             "The approved corpus contains 67 clauses and 6,684 body words. Titles are metadata, not counted body text.\n",
             "## Actual strategy outputs\n",
             "| Strategy | Chunks | Min words | Median | Max words | Stored body words |",
             "|---|---:|---:|---:|---:|---:|"]
    for name, stats in audit["strategies"].items():
        lines.append(f"| {name} | {stats['chunk_count']} | {stats['minimum_words']} | {stats['median_words']} | {stats['maximum_words']} | {stats['stored_words']} |")
    lines += ["\nFixed Length uses a soft 180-word target: compare the nearest allowed boundaries on either side, choose earlier on ties, and flush at topic/section boundaries. Protected units can exceed the target; complete tails can be shorter than 80 words.",
              "\nOverlap uses adjacent whole-clause pairs with stride one inside each topic group. Singletons appear once and no extra last-paragraph copy is emitted. Hybrid keeps full clauses and explicitly links only 3.3+3.4.",
              "\n## Length distributions\n"]
    for name, stats in audit["strategies"].items():
        lines.append(f"- {name}: `{json.dumps(stats['length_distribution'])}`")
    lines += ["\n## Explicit within-section topic breaks\n"]
    for x in rules["topic_breaks"]:
        lines.append(f"- {x['after']} / {x['before']}: {x['reason']}")
    lines += ["\n## Complete sentences that lose necessary meaning in isolation\n",
              "These are identified and protected risks, not unresolved defects in the final chunks.\n"]
    cases = [("8.1", 4, 3, 4, "Until then refers to a designated safe-exchange location awaiting approval and publication."),
             ("10.4", 3, 2, 3, "same retention rule refers to the preceding retention conditions; one academic year remains an example, not a fixed mandatory deadline."),
             ("13.1", 3, 1, 3, "that fails refers to first attempting a direct settlement."),
             ("14.2", 2, 1, 2, "this period means the final two weeks of each semester.")]
    for clause_id, sentence, first, last, reason in cases:
        text = by_id[clause_id]["text"]
        bounds = _sentence_ranges(text)
        start, end = bounds[sentence - 1]
        left, right = bounds[first - 1][0], bounds[last - 1][1]
        hosts = [c["chunk_id"] for c in chunk_sets["fixed_length"] for span in c["source_spans"]
                 if span["paragraph_id"] == clause_id and span["start_char"] <= left and span["end_char"] >= right]
        lines += [f"### {clause_id}, sentence {sentence}\n", "> " + text[start:end] + "\n", reason + "\n",
                  "Preserved context:\n\n> " + text[left:right] + "\n", "Actual Fixed Length host: `" + ", ".join(hosts) + "`.\n"]
    lines += ["## Explicit cross-clause dependency\n",
              "> " + by_id["3.4"]["text"][:_sentence_ranges(by_id["3.4"]["text"])[0][1]] + "\n",
              "these user duties in 3.4 refers to the account-security duties in 3.3. Fixed and Hybrid preserve both full clauses as one 191-word unit; Overlap naturally produces the same pair in this two-clause topic group.\n"]
    for name in STRATEGIES:
        ids = [c["chunk_id"] for c in chunk_sets[name] if c["paragraph_ids"] == ["3.3", "3.4"]]
        lines.append(f"- {name}: `{', '.join(ids)}`")
    lines += ["\n## Actual within-clause cuts reviewed\n",
              "Only Fixed Length introduces within-clause cuts. Source sentence numbers are inclusive. Protected rule/exception and antecedent groups remain intact.\n",
              "| Clause | Chunk and sentence range |", "|---|---|"]
    for paragraph in paragraphs:
        pieces = [(c["chunk_id"], span["sentence_start"], span["sentence_end"])
                  for c in chunk_sets["fixed_length"] for span in c["source_spans"]
                  if span["paragraph_id"] == paragraph["paragraph_id"]]
        if len(pieces) > 1:
            lines.append(f"| {paragraph['paragraph_id']} | " + "; ".join(f"`{i}` sentences {a}-{b}" for i, a, b in pieces) + " |")
    lines += ["\nReview expanded 4.2 protection to sentences 1-3 and protected all of 14.4. Other cuts separate independent definitions or rules. The last sentence of 8.5 retains its payment-completion condition and exceptions in one sentence, so it can stand alone.\n",
              "## Two actual examples per strategy\n"]
    examples = {"fixed_length": chunk_sets["fixed_length"][2:4],
                "overlapping_paragraph": [next(c for c in chunk_sets["overlapping_paragraph"] if c["paragraph_ids"] == ids)
                                          for ids in (["8.1", "8.2"], ["8.2", "8.3"])],
                "hybrid_strategic": [next(c for c in chunk_sets["hybrid_strategic"] if c["paragraph_ids"] == ids)
                                     for ids in (["3.3", "3.4"], ["8.1"])]}
    for name, chunks in examples.items():
        for chunk in chunks:
            lines += [f"### {chunk['chunk_id']} ({chunk['word_count']} words)\n",
                      f"Clauses: {', '.join(chunk['paragraph_ids'])}; original PDF pages: {chunk['source_pages']}.\n", chunk["text"] + "\n"]
    lines += ["## Verification boundary\n",
              "Checks cover every non-whitespace source character, unexpected duplication, sentence/character/page mappings, topic boundaries, overlap tail handling, and protected units. Semantic review is a separate review of actual cuts and topic groups.",
              "\nsource_pages lists the original PDF pages of contributing clauses, not exact per-sentence PDF positions. Revised clauses retain their revision_id provenance.",
              "\nTask 3 tokenizer compatibility is reported separately. Each strategy must provide identical chunks to all embedding models; it must not silently change chunks per model."]
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/chunking_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_chunking_outputs(paragraphs, rules):
    chunk_sets = {name: make_chunks(paragraphs, name, rules) for name in STRATEGIES}
    audit = audit_chunking(paragraphs, chunk_sets, rules)
    for name, chunks in chunk_sets.items():
        Path(f"data/chunks_{name}.json").write_text(json.dumps(chunks, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    Path("data/chunking_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_chunking_report(paragraphs, chunk_sets, rules, audit)
    return chunk_sets, audit


if __name__ == "__main__":
    paragraphs = json.loads(Path("data/policy_paragraphs.json").read_text(encoding="utf-8"))
    rules = json.loads(Path("data/chunking_rules.json").read_text(encoding="utf-8"))
    _, audit = build_chunking_outputs(paragraphs, rules)
    print(json.dumps(audit["strategies"], ensure_ascii=False, indent=2))
