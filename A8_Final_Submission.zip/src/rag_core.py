"""MoveOn policy corpus preparation and source-traceable chunking."""

from copy import deepcopy
from hashlib import sha256
from importlib.metadata import version
import json
from pathlib import Path
import re
from typing import NotRequired, TypedDict

from pypdf import PdfReader


class Paragraph(TypedDict):
    paragraph_id: str
    section_id: str
    section_title: str
    clause_title: str
    text: str
    source_pages: list[int]
    word_count: int
    text_origin: NotRequired[str]
    revision_id: NotRequired[str]


_SECTION = re.compile(r"^(\d+)\.\s+(.+)$")
_CLAUSE = re.compile(r"^(\d+\.\d+)\s+(.+?)\.\s+(.+)$")
_HEADER = re.compile(r"^MoveOn Marketplace Policy Version .+ · Draft$")
_FOOTER = re.compile(r"^University of Illinois Urbana-Champaign · INFO 490 Page \d+ of \d+$")
_SCOPE_APPROVAL = {
    "source_sha256": "99b3c8e77be02c22880ace8cf3cbb2d24df57ed049ffa6073ff2dc1c9ea2de2d",
    "scope": "all_numbered_clauses",
    "user_instruction": "Adopt all clauses",
    "user_instruction_is_translation": True,
    "recorded_date": "2026-10-30",
}


def extract_policy_corpus(pdf_path: str | Path) -> tuple[list[Paragraph], dict]:
    """Extract this policy's numbered body and audit the actual omitted regions.

    A paragraph is one complete numbered clause, excluding its title. The
    state machine skips table summaries until the next clause/section and
    continues a clause across pages. It does not rewrite or extend policy.
    """
    path = Path(pdf_path)
    reader = PdfReader(path)
    paragraphs: list[Paragraph] = []
    excluded: dict[tuple[int, str], list[str]] = {}
    line_joins = []
    current = None
    section_id, section_title = "", ""
    summary, revision = False, False
    seen = set()

    def finish_clause():
        nonlocal current
        if current is not None:
            if not current["text"] or "\ufffd" in current["text"]:
                raise ValueError(f"Empty or damaged clause: {current['paragraph_id']}")
            current["word_count"] = len(current["text"].split())
            paragraphs.append(current)
            current = None

    for page_number, page in enumerate(reader.pages, 1):
        for raw_line in (page.extract_text() or "").splitlines():
            line = raw_line.strip()
            if not line:
                continue
            reason = None
            if page_number <= 2:
                reason = "cover_contents_and_policy_overview"
            elif _HEADER.fullmatch(line):
                reason = "repeated_header"
            elif _FOOTER.fullmatch(line):
                reason = "repeated_footer"
            elif revision or line == "Revision history":
                finish_clause()
                revision = True
                reason = "revision_history"
            elif line.startswith("The table below"):
                finish_clause()
                summary = True
                reason = "summary_introduction_and_table"
            elif match := _SECTION.fullmatch(line):
                finish_clause()
                section_id, section_title = match.groups()
                summary = False
                continue
            elif match := _CLAUSE.fullmatch(line):
                finish_clause()
                clause_id, clause_title, body = match.groups()
                if clause_id in seen or clause_id.split(".")[0] != section_id:
                    raise ValueError(f"Duplicate clause or section mismatch: {clause_id}")
                seen.add(clause_id)
                summary = False
                current = Paragraph(
                    paragraph_id=clause_id, section_id=section_id,
                    section_title=section_title, clause_title=clause_title,
                    text=body, source_pages=[page_number], word_count=0,
                )
                continue
            elif summary:
                reason = "summary_introduction_and_table"
            elif current is not None:
                separator = " "
                if current["text"].endswith("-"):
                    # These are compounds (desk-and-chair, peer-to-peer,
                    # move-out), verified in this PDF. Keep the real hyphen.
                    separator = ""
                    line_joins.append({
                        "paragraph_id": current["paragraph_id"],
                        "source_page": page_number,
                        "left": current["text"].split()[-1],
                        "right": line.split()[0],
                        "action": "join_without_space_preserving_hyphen",
                    })
                current["text"] += separator + line
                if page_number not in current["source_pages"]:
                    current["source_pages"].append(page_number)
                continue
            else:
                reason = "outside_numbered_body"
            excluded.setdefault((page_number, reason), []).append(line)

    finish_clause()
    if not paragraphs:
        raise ValueError("PDF contains no numbered policy clauses")

    canonical = json.dumps(paragraphs, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":")).encode("utf-8")
    short = [{"paragraph_id": p["paragraph_id"], "word_count": p["word_count"]}
             for p in paragraphs if p["word_count"] < 80]
    long = [{"paragraph_id": p["paragraph_id"], "word_count": p["word_count"]}
            for p in paragraphs if p["word_count"] > 200]
    source_hash = sha256(path.read_bytes()).hexdigest()
    scope_confirmed = source_hash == _SCOPE_APPROVAL["source_sha256"]
    audit = {
        "schema_version": 1,
        "parser_version": "task1-v1",
        "source_file": "data/" + path.name,
        "source_sha256": source_hash,
        "source_page_count": len(reader.pages),
        "corpus_sha256": sha256(canonical).hexdigest(),
        "hash_serialization": "UTF-8 JSON, sorted object keys, compact separators, document-order array",
        "extractor": {"name": "pypdf", "version": version("pypdf")},
        "knowledge_base": "MoveOn policy draft Q&A; not evidence of deployed functionality",
        "corpus_status": ("provisional_pending_short_paragraph_decision" if scope_confirmed
                          else "provisional_pending_scope_and_short_paragraph_decisions"),
        "paragraph_definition": "one complete numbered clause, excluding its title",
        "word_count_method": "len(text.split()); body only; compound hyphens retained",
        "page_numbering": "1-based physical PDF pages",
        "adopted_scope": ("all numbered clauses, user-confirmed" if scope_confirmed
                          else "all numbered clauses, provisionally"),
        "scope_approval": _SCOPE_APPROVAL.copy() if scope_confirmed else None,
        "short_paragraph_action": "retain original text unchanged and flag for review",
        "approved_content_changes": [],
        "statistics": {
            "paragraph_count": len(paragraphs),
            "section_count": len({p["section_id"] for p in paragraphs}),
            "total_words": sum(p["word_count"] for p in paragraphs),
            "minimum_paragraph_words": min(p["word_count"] for p in paragraphs),
            "maximum_paragraph_words": max(p["word_count"] for p in paragraphs),
            "paragraphs_80_to_200_words": len(paragraphs) - len(short) - len(long),
            "short_paragraphs": short,
            "long_paragraphs": long,
        },
        "cross_page_clauses": [{"paragraph_id": p["paragraph_id"], "source_pages": p["source_pages"]}
                               for p in paragraphs if len(p["source_pages"]) > 1],
        "excluded_regions": [{"source_page": page, "reason": reason, "text": " ".join(lines)}
                             for (page, reason), lines in excluded.items()],
        "hyphenated_line_joins": line_joins,
        "pending_decisions": ([] if scope_confirmed else [
            "Confirm all numbered clauses as the final experiment scope.",
        ]) + [
            "Decide treatment of paragraphs below approximately 80 words; none were removed or expanded.",
        ],
    }
    return paragraphs, audit


def load_policy_paragraphs(pdf_path: str | Path) -> list[Paragraph]:
    """Return numbered clauses in PDF order without writing any files."""
    paragraphs, _ = extract_policy_corpus(pdf_path)
    return paragraphs


def apply_policy_revisions(
    paragraphs: list[Paragraph], audit: dict, revisions_path: str | Path,
) -> tuple[list[Paragraph], dict]:
    """Apply the authorized short-clause edits, preserving the raw extraction."""
    path = Path(revisions_path)
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest["source_sha256"] != audit["source_sha256"]:
        raise ValueError("Revision source PDF hash does not match")
    original_hash = sha256(json.dumps(
        paragraphs, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")).hexdigest()
    if original_hash != manifest["original_corpus_sha256"]:
        raise ValueError("Revision original corpus hash does not match")

    revised = deepcopy(paragraphs)
    revised_audit = deepcopy(audit)
    by_id = {p["paragraph_id"]: p for p in revised}
    changes = []
    for entry in manifest["revisions"]:
        paragraph = by_id[entry["paragraph_id"]]
        if paragraph["text"] != entry["original_text"]:
            raise ValueError(f"Revision original text mismatch: {entry['paragraph_id']}")
        word_count = len(entry["revised_text"].split())
        if not 80 <= word_count <= 90:
            raise ValueError(f"Revised clause outside 80-90 words: {entry['paragraph_id']}")
        paragraph.update(text=entry["revised_text"], word_count=word_count,
                         text_origin="approved_revision", revision_id=manifest["revision_id"])
        changes.append({**entry, "revised_word_count": word_count})

    short = [{"paragraph_id": p["paragraph_id"], "word_count": p["word_count"]}
             for p in revised if p["word_count"] < 80]
    long = [{"paragraph_id": p["paragraph_id"], "word_count": p["word_count"]}
            for p in revised if p["word_count"] > 200]
    revised_audit["original_corpus_sha256"] = original_hash
    revised_audit["original_statistics"] = deepcopy(audit["statistics"])
    revised_audit["corpus_sha256"] = sha256(json.dumps(
        revised, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")).hexdigest()
    revised_audit["statistics"].update(
        total_words=sum(p["word_count"] for p in revised),
        minimum_paragraph_words=min(p["word_count"] for p in revised),
        maximum_paragraph_words=max(p["word_count"] for p in revised),
        paragraphs_80_to_200_words=len(revised) - len(short) - len(long),
        short_paragraphs=short, long_paragraphs=long,
    )
    revised_audit.update(
        approved_content_changes=changes,
        revision_id=manifest["revision_id"],
        revision_file="data/" + path.name,
        revision_file_sha256=sha256(path.read_bytes()).hexdigest(),
        revision_authorization=manifest["authorization"],
        source_pdf_is_verbatim_for_all_paragraphs=False,
        short_paragraph_action="user-authorized meaning-preserving revisions to 80-90 words",
        corpus_status="ready_for_chunking" if not short and not long else "requires_length_review",
        pending_decisions=[] if not short and not long else ["Review remaining length outliers."],
    )
    return revised, revised_audit


class SourceSpan(TypedDict):
    paragraph_id: str
    start_char: int
    end_char: int
    sentence_start: int
    sentence_end: int


class Chunk(TypedDict):
    chunk_id: str
    strategy: str
    strategy_version: str
    topic_group: int
    text: str
    paragraph_ids: list[str]
    source_pages: list[int]
    source_spans: list[SourceSpan]
    word_count: int


def _sentence_ranges(text: str) -> list[tuple[int, int]]:
    """Policy-specific English sentence boundaries; preserve exact offsets.

    Decimal clause references and addresses contain no space after their
    internal dots. This is not a general-purpose abbreviation tokenizer.
    """
    return [(m.start(), m.end()) for m in re.finditer(
        r'''\S.*?(?:[.!?]["”’')\]]*(?=\s|$)|$)''', text)]


def _topic_groups(paragraphs: list[Paragraph], params: dict) -> list[list[Paragraph]]:
    positions = {p["paragraph_id"]: i for i, p in enumerate(paragraphs)}
    if len(positions) != len(paragraphs):
        raise ValueError("Duplicate paragraph IDs")
    breaks = set()
    for entry in params.get("topic_breaks", []):
        left, right = entry["after"], entry["before"]
        if left not in positions or right not in positions or positions[right] != positions[left] + 1:
            raise ValueError(f"Topic break must identify adjacent paragraphs: {left}, {right}")
        breaks.add((left, right))
    groups = []
    for paragraph in paragraphs:
        if (not groups or groups[-1][-1]["section_id"] != paragraph["section_id"]
                or (groups[-1][-1]["paragraph_id"], paragraph["paragraph_id"]) in breaks):
            groups.append([])
        groups[-1].append(paragraph)
    group_by_id = {p["paragraph_id"]: i for i, group in enumerate(groups) for p in group}
    for link in params.get("linked_clauses", []):
        ids = link["paragraph_ids"]
        if (not ids or any(i not in positions for i in ids)
                or any(positions[b] != positions[a] + 1 for a, b in zip(ids, ids[1:]))
                or len({group_by_id[i] for i in ids}) != 1):
            raise ValueError(f"Linked clauses must be consecutive in one topic group: {ids}")
    return groups


def _chunk_units(group: list[Paragraph], params: dict, whole: bool) -> list[list[SourceSpan]]:
    """Units are complete sentences, protected sentence groups, or linked clauses."""
    links = {x["paragraph_ids"][0]: x["paragraph_ids"] for x in params.get("linked_clauses", [])}
    protected = {x["paragraph_id"] for x in params.get("protected_clauses", [])}
    by_id = {p["paragraph_id"]: p for p in group}

    def full_span(paragraph):
        return SourceSpan(paragraph_id=paragraph["paragraph_id"], start_char=0,
                          end_char=len(paragraph["text"]), sentence_start=1,
                          sentence_end=len(_sentence_ranges(paragraph["text"])))

    units = []
    position = 0
    while position < len(group):
        paragraph = group[position]
        clause_id = paragraph["paragraph_id"]
        if clause_id in links:
            ids = links[clause_id]
            units.append([full_span(by_id[i]) for i in ids])
            position += len(ids)
        elif whole or clause_id in protected:
            units.append([full_span(paragraph)])
            position += 1
        else:
            ranges = _sentence_ranges(paragraph["text"])
            blocks = sorted((x["sentence_start"] - 1, x["sentence_end"])
                            for x in params.get("protected_sentence_groups", [])
                            if x["paragraph_id"] == clause_id)
            previous_end = 0
            for start, end in blocks:
                if not previous_end <= start < end <= len(ranges):
                    raise ValueError(f"Invalid or overlapping protected sentence group: {clause_id}")
                previous_end = end
            block_ends = dict(blocks)
            sentence = 0
            while sentence < len(ranges):
                end = block_ends.get(sentence, sentence + 1)
                units.append([SourceSpan(
                    paragraph_id=clause_id, start_char=ranges[sentence][0],
                    end_char=ranges[end - 1][1], sentence_start=sentence + 1, sentence_end=end)])
                sentence = end
            position += 1
    return units


def make_chunks(paragraphs: list[Paragraph], strategy: str, params: dict) -> list[Chunk]:
    """Implement the three approved strategies over one immutable corpus.

    Fixed length uses a soft target, selecting the closer allowed boundary
    and the earlier boundary on ties. Overlap uses whole-paragraph windows
    of two and stride one. Hybrid uses whole clauses plus explicit links.
    """
    if strategy not in {"fixed_length", "overlapping_paragraph", "hybrid_strategic"}:
        raise ValueError(f"Unknown chunk strategy: {strategy}")
    if not paragraphs or any(not p["text"].strip() for p in paragraphs):
        raise ValueError("Chunking requires nonempty paragraphs")
    corpus_hash = sha256(json.dumps(paragraphs, ensure_ascii=False, sort_keys=True,
                                   separators=(",", ":")).encode("utf-8")).hexdigest()
    if "corpus_sha256" in params and params["corpus_sha256"] != corpus_hash:
        raise ValueError("Chunking rules do not match this corpus")
    target = params.get("target_words", 180)
    if not isinstance(target, int) or target <= 0:
        raise ValueError("target_words must be a positive integer")
    groups = _topic_groups(paragraphs, params)
    by_id = {p["paragraph_id"]: p for p in paragraphs}
    chunks: list[Chunk] = []

    def emit(unit_list, group_number):
        spans = []
        for unit in unit_list:
            for source in unit:
                span = source.copy()
                if spans and spans[-1]["paragraph_id"] == span["paragraph_id"]:
                    previous = spans[-1]
                    gap = by_id[span["paragraph_id"]]["text"][previous["end_char"]:span["start_char"]]
                    if gap.strip():
                        raise ValueError("Noncontiguous source spans inside a chunk")
                    previous["end_char"] = span["end_char"]
                    previous["sentence_end"] = span["sentence_end"]
                else:
                    spans.append(span)
        ids = list(dict.fromkeys(s["paragraph_id"] for s in spans))
        text = "\n\n".join(by_id[s["paragraph_id"]]["text"][s["start_char"]:s["end_char"]]
                            for s in spans)
        chunks.append(Chunk(
            chunk_id=f"{strategy}-{len(chunks) + 1:03d}", strategy=strategy,
            strategy_version=params.get("rules_version", "task2-v1"), topic_group=group_number,
            text=text, paragraph_ids=ids,
            source_pages=sorted({page for i in ids for page in by_id[i]["source_pages"]}),
            source_spans=spans, word_count=len(text.split()),
        ))

    for group_number, group in enumerate(groups, 1):
        if strategy == "overlapping_paragraph":
            # Whole paragraphs preserve within-clause protections; explicit
            # cross-clause merges belong to Fixed and Hybrid, not this window.
            units = [[SourceSpan(paragraph_id=p["paragraph_id"], start_char=0,
                                 end_char=len(p["text"]), sentence_start=1,
                                 sentence_end=len(_sentence_ranges(p["text"])))] for p in group]
            for position in range(max(1, len(units) - 1)):
                emit(units[position:position + 2], group_number)
        else:
            units = _chunk_units(group, params, whole=strategy == "hybrid_strategic")
            if strategy == "hybrid_strategic":
                for unit in units:
                    emit([unit], group_number)
                continue
            weights = [sum(len(by_id[s["paragraph_id"]]["text"][
                s["start_char"]:s["end_char"]].split()) for s in unit) for unit in units]
            position = 0
            while position < len(units):
                end, total = position, 0
                while end < len(units) and total < target:
                    total += weights[end]
                    end += 1
                if total >= target and end - position > 1:
                    earlier_total = total - weights[end - 1]
                    if abs(earlier_total - target) <= abs(total - target):
                        end -= 1
                emit(units[position:end], group_number)
                position = end
    return chunks


if __name__ == "__main__":
    policy_path = Path("data/MoveOn_Marketplace_Policy.pdf")
    originals, audit = extract_policy_corpus(policy_path)
    paragraphs, audit = apply_policy_revisions(
        originals, audit, policy_path.with_name("policy_revisions.json"))
    for destination, value in (("policy_paragraphs_original.json", originals),
                               ("policy_paragraphs.json", paragraphs), ("corpus_audit.json", audit)):
        policy_path.with_name(destination).write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(audit["statistics"], ensure_ascii=False, indent=2))
