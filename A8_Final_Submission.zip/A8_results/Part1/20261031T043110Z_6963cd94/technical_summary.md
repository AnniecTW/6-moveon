Run `20261031T043110Z_6963cd94`: **9 indices**, **9 searches**, **9 answers**; **0 answers with review flags**.

| Configuration | Question | Status | Input/output tokens | Review flags |
|---|---|---|---:|---|
| bge_small__fixed_length | giveaway_donation | completed | 871/60 | none |
| bge_small__overlapping_paragraph | giveaway_donation | completed | 983/59 | none |
| bge_small__hybrid_strategic | giveaway_donation | completed | 604/60 | none |
| bge_base__fixed_length | giveaway_donation | completed | 727/60 | none |
| bge_base__overlapping_paragraph | giveaway_donation | completed | 970/60 | none |
| bge_base__hybrid_strategic | giveaway_donation | completed | 608/60 | none |
| bge_large__fixed_length | giveaway_donation | completed | 1037/60 | none |
| bge_large__overlapping_paragraph | giveaway_donation | completed | 990/60 | none |
| bge_large__hybrid_strategic | giveaway_donation | completed | 582/60 | none |

Semantic answer review: pending review of the new outputs.
