# Part 2 appendix: complete retrieved chunks and answers (all 90 runs)

Each section is one run: query, the three retrieved chunks exactly as given to Qwen3-4B, the full answer, reviewed scores, and latency. Scores: context relevance / completeness, answer relevance / groundedness (1–3).

## Full corpus (67 clauses)

### BAAI/bge-small-en-v1.5 · Fixed length · Q1

Record `large_67_clauses__bge_small__fixed_length__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.7304

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 2** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.7109

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `fixed_length-008`, clauses [4.1, 4.2], cosine 0.6949

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters.

**Answer:** If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the Seller. The team can help review the situation but cannot force a refund, collect money, or take back an item. If direct communication fails, the team can investigate the case but still cannot enforce a refund or take back an item. For larger issues, users may need to pursue legal remedies through small claims court or other lawful means. Returns are not explicitly covered by the policy, and the team does not handle return processes.

**Scores:** context 3/2, answer 3/2 · **Latency:** 8.35 s · input/output tokens 999/116 · **Notes:** Key clause [8.5], [13.1] at rank 1; minor unsupported inference; no clause citation

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q2

Record `large_67_clauses__bge_small__fixed_length__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `fixed_length-014`, clauses [6.3, 6.4], cosine 0.6772

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `fixed_length-038`, clauses [14.2, 14.3, 14.4], cosine 0.6605

> The team may add a short pickup-window feature so Buyers can plan trips efficiently. At the start of each semester, new students arrive with little furniture and tight budgets. During this period the team will give priority in search results to Listings that are free or well priced, and Moderators will watch more closely for price gouging, scams aimed at new students, and fake Listings. Orientation material and the platform's home page will include safety tips written for first-year and international students, who may be unfamiliar with local scams and with the risks of meeting strangers. Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Rank 3** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6359

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** No, a Buyer may not purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. However, it does not explicitly restrict the number of items a Buyer can purchase from a Bundle. The policy focuses on the Bundle's pricing and description requirements, not on the quantity of items a Buyer can take. Therefore, the policy does not establish a rule that limits Buyers to purchasing only three items or fewer from a Bundle [6.3].

**Scores:** context 3/3, answer 1/1 · **Latency:** 8.49 s · input/output tokens 1010/121 · **Notes:** Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’); **Part 3 failure F1**

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q3

Record `large_67_clauses__bge_small__fixed_length__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `fixed_length-013`, clauses [6.1, 6.2], cosine 0.6987

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup. Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Rank 2** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.6970

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 3** — `fixed_length-020`, clauses [8.4, 8.5], cosine 0.6789

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price.

**Answer:** The evidence does not mention a "Bundle discount" or specify whether such a discount is fixed or negotiable. Therefore, it cannot be determined from the provided policy evidence whether the Bundle discount is fixed or can be negotiated.

**Scores:** context 3/2, answer 3/3 · **Latency:** 3.45 s · input/output tokens 909/45 · **Notes:** Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; no clause citation

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q4

Record `large_67_clauses__bge_small__fixed_length__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `fixed_length-020`, clauses [8.4, 8.5], cosine 0.7938

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price.

**Rank 2** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.7486

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 3** — `fixed_length-027`, clauses [10.4, 10.5], cosine 0.7208

> If the team learns of a breach that affects personal data, it will tell affected Users promptly and explain what happened and what they should do. Users may view, correct, and download the personal data they have given MoveOn, and may ask the team to delete their account. When an account is deleted, active Listings are removed and Messages are anonymized, except where the team must keep a record to resolve an open Report or comply with the law. Users who want to see what the platform holds about them, or who have a privacy concern, may contact the team, which will reply within a reasonable time, normally within ten business days. If MoveOn is adopted by the University, University privacy rules and applicable laws will be added to this section.

**Answer:** MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. [8.4] If a Buyer does not show up or has a payment problem and can no longer be contacted, MoveOn does not provide direct help or protection in such situations. The platform does not intervene in payment disputes or take action to recover payments. Users are encouraged to resolve such issues through direct communication or legal means. [13.1]

**Scores:** context 3/2, answer 3/3 · **Latency:** 13.41 s · input/output tokens 816/206 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q5

Record `large_67_clauses__bge_small__fixed_length__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `fixed_length-014`, clauses [6.3, 6.4], cosine 0.7573

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `fixed_length-023`, clauses [9.2, 9.3], cosine 0.6596

> Posting a Listing as a front for an off-platform business, a resale operation that buys items in bulk from others, or a lead-generation scheme is not permitted unless the team has approved it in advance. MoveOn is meant for students selling their own belongings, not for businesses. A User who regularly lists large numbers of new items, buys from free Listings in order to resell, or appears to run a store may be asked to stop. Student organizations may hold fundraising sales only with advance permission from the team, and must label such Listings clearly. Local businesses and landlords may not post on MoveOn, though the team may work with them separately on donation drives or move-out collections.

**Rank 3** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.6584

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.37 s · input/output tokens 871/60 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q1

Record `large_67_clauses__bge_small__overlapping_paragraph__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.7261

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 2** — `overlapping_paragraph-008`, clauses [4.1, 4.2], cosine 0.7024

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them.

**Rank 3** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6975

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the Seller. The team can help review the situation but cannot force a refund, collect money, or take back an item. If direct communication fails, the team can investigate the case but does not have the authority to enforce a refund or other actions. For larger issues, users may need to pursue legal remedies through small claims court or other lawful means. Returns are not explicitly covered in the policy, and the team does not guarantee item accuracy or safety. Users are responsible for judging whether to buy or sell and for taking sensible care when doing so. [13.1]

**Scores:** context 3/2, answer 3/3 · **Latency:** 10.36 s · input/output tokens 1017/145 · **Notes:** Key clause [8.5], [13.1] at rank 1

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q2

Record `large_67_clauses__bge_small__overlapping_paragraph__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `overlapping_paragraph-015`, clauses [6.3, 6.4], cosine 0.6772

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6366

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 3** — `overlapping_paragraph-041`, clauses [14.3, 14.4], cosine 0.6333

> At the start of each semester, new students arrive with little furniture and tight budgets. During this period the team will give priority in search results to Listings that are free or well priced, and Moderators will watch more closely for price gouging, scams aimed at new students, and fake Listings. Orientation material and the platform's home page will include safety tips written for first-year and international students, who may be unfamiliar with local scams and with the risks of meeting strangers. Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Answer:** No, a Buyer cannot purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. However, it does not explicitly restrict the number of items a Buyer can purchase from a Bundle. The policy focuses on the Bundle's pricing and description requirements, not on the quantity a Buyer can take. Therefore, there is no policy restriction on the number of items a Buyer can purchase from a Bundle. [6.3]

**Scores:** context 3/3, answer 1/1 · **Latency:** 8.31 s · input/output tokens 964/116 · **Notes:** Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’)

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q3

Record `large_67_clauses__bge_small__overlapping_paragraph__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6992

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 2** — `overlapping_paragraph-014`, clauses [6.1, 6.2], cosine 0.6987

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup. Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Rank 3** — `overlapping_paragraph-021`, clauses [8.4, 8.5], cosine 0.6829

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** The evidence does not establish whether the Bundle discount is fixed or if negotiation is allowed. The policy focuses on pricing guidelines, such as pricing used items well below retail and avoiding price gouging, but does not specifically mention Bundle discounts or negotiation regarding them [6.1, 6.2, 13.1, 13.2].

**Scores:** context 3/2, answer 3/3 · **Latency:** 5.45 s · input/output tokens 984/72 · **Notes:** Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; no clause citation

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q4

Record `large_67_clauses__bge_small__overlapping_paragraph__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `overlapping_paragraph-021`, clauses [8.4, 8.5], cosine 0.7918

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 2** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.7444

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 3** — `overlapping_paragraph-020`, clauses [8.2, 8.3], cosine 0.7170

> Users should tell a friend or roommate where they are going, who they are meeting, and when they expect to return. They should meet during daylight when possible, bring a friend for large or valuable items, keep their phone charged, and trust their instincts: anyone who feels uncomfortable may leave without explanation and cancel the sale. Neither side may pressure the other to go to a second location or to move an item to a private place. A User who feels threatened should leave, call campus police or 911 in an emergency, and report the incident to MoveOn afterward so that the team can act to protect others. Many items on MoveOn, such as desks, bookshelves, and mini fridges, are too large to carry to a public location. For these, the Seller should arrange pickup at the building entrance or a shared lobby, and the Buyer should bring help and a way to move the item. Users must follow residence hall rules on guests, escorts, and quiet hours, and must not bring non-resident visitors into a building in violation of those rules. Neither party should carry heavy furniture alone, and both should respect other residents by keeping hallways and elevators clear during handoff.

**Answer:** MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. The platform does not process payments and is not a party to any sale, so it does not intervene in payment disputes or contact issues. Users are expected to resolve such issues through direct communication or other means. If a User feels threatened during a meeting, they are advised to leave, call campus police or 911 in an emergency, and report the incident to MoveOn afterward so that the team can act to protect others. However, MoveOn does not guarantee the safety of Users or provide direct assistance in cases of non-attendance or payment problems. [8.4]

**Scores:** context 3/2, answer 3/3 · **Latency:** 10.33 s · input/output tokens 976/147 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q5

Record `large_67_clauses__bge_small__overlapping_paragraph__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `overlapping_paragraph-015`, clauses [6.3, 6.4], cosine 0.7573

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6579

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 3** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6518

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.58 s · input/output tokens 983/59 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q1

Record `large_67_clauses__bge_small__hybrid_strategic__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `hybrid_strategic-031`, clauses [8.5], cosine 0.7336

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 2** — `hybrid_strategic-020`, clauses [6.2], cosine 0.7111

> Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Rank 3** — `hybrid_strategic-050`, clauses [13.1], cosine 0.7062

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes.

**Answer:** If you buy an item you do not like or it does not match the Listing, you may have the right to return it, but the process depends on the circumstances. If the item differs from the Listing, you may decline it or ask for a lower price [8.5]. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13 [8.5]. If the item is not as described, the Buyer may decline it without penalty, and the Seller should accept that choice politely [8.2]. For other disputes, most disagreements can be solved by a polite conversation, and if that fails, either person may ask the team to look at the case. The team can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item [13.1].

**Scores:** context 3/3, answer 3/2 · **Latency:** 13.76 s · input/output tokens 620/220 · **Notes:** Key clause [8.5], [13.1] at rank 1; minor unsupported inference; cites [8.2], which is not in context; **Part 3 failure F3**

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q2

Record `large_67_clauses__bge_small__hybrid_strategic__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `hybrid_strategic-022`, clauses [6.4], cosine 0.7472

> Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `hybrid_strategic-020`, clauses [6.2], cosine 0.6846

> Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Rank 3** — `hybrid_strategic-057`, clauses [14.4], cosine 0.6675

> Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is implied that Buyers can choose individual items from a Bundle, as every item in a Bundle must be described individually in the Listing [6.4]. Therefore, a Buyer could potentially purchase only three items or fewer from a Bundle, depending on the specific items available and the Buyer's selection.

**Scores:** context 3/3, answer 3/3 · **Latency:** 5.38 s · input/output tokens 627/82 · **Notes:** Key clause [6.4] at rank 1

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q3

Record `large_67_clauses__bge_small__hybrid_strategic__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `hybrid_strategic-020`, clauses [6.2], cosine 0.7373

> Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Rank 2** — `hybrid_strategic-022`, clauses [6.4], cosine 0.7101

> Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 3** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6942

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** The Bundle discount is not fixed, and a Buyer may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. This implies that the Bundle price is determined by the Seller and may be subject to negotiation, as there is no explicit rule that the Bundle discount is fixed or non-negotiable. However, the platform does not provide specific guidance on negotiation practices for Bundle discounts. [6.4]

**Scores:** context 3/2, answer 2/1 · **Latency:** 7.34 s · input/output tokens 620/114 · **Notes:** Key clause [6.4] only at rank 2; no clause says whether the discount is negotiable; unsupported claim; **Part 3 failure F2**

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q4

Record `large_67_clauses__bge_small__hybrid_strategic__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `hybrid_strategic-030`, clauses [8.4], cosine 0.8001

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect.

**Rank 2** — `hybrid_strategic-051`, clauses [13.2], cosine 0.7249

> MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 3** — `hybrid_strategic-034`, clauses [9.3], cosine 0.7160

> MoveOn is meant for students selling their own belongings, not for businesses. A User who regularly lists large numbers of new items, buys from free Listings in order to resell, or appears to run a store may be asked to stop. Student organizations may hold fundraising sales only with advance permission from the team, and must label such Listings clearly. Local businesses and landlords may not post on MoveOn, though the team may work with them separately on donation drives or move-out collections.

**Answer:** MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. The platform does not process payments and is not involved in the sale, so it does not intervene in such situations. Users are advised to use safe payment methods and to never send money before inspecting the item, as these steps are meant to reduce the risk of scams rather than provide recourse if issues arise [8.4].

**Scores:** context 3/2, answer 3/3 · **Latency:** 6.19 s · input/output tokens 589/96 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q5

Record `large_67_clauses__bge_small__hybrid_strategic__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `hybrid_strategic-021`, clauses [6.3], cosine 0.7726

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price.

**Rank 2** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6667

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 3** — `hybrid_strategic-050`, clauses [13.1], cosine 0.6599

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must truly be free, and a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 3.97 s · input/output tokens 604/60 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q1

Record `large_67_clauses__bge_base__fixed_length__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.6759

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 2** — `fixed_length-029`, clauses [11.3], cosine 0.6412

> Users may not post content that infringes another person's copyright, trademark, or other rights. Listings may not use brand logos in a way that suggests the Seller is an authorized dealer, and may not offer items that copy a protected product or design. Pirated media, unlicensed software, and fake designer goods are prohibited. A rights holder who believes a Listing infringes their rights may send a written notice to the team, which will review it promptly, remove the content if the claim appears valid, and tell the affected User, who may respond.

**Rank 3** — `fixed_length-012`, clauses [5.4], cosine 0.6365

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the Seller. Users are encouraged to try to settle the problem directly, for example by agreeing on a partial refund or returning the item [13.1]. If this fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item [13.1]. For larger losses, users may use small claims court or other lawful routes [13.1]. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale [13.1].

**Scores:** context 3/2, answer 3/3 · **Latency:** 11.96 s · input/output tokens 677/185 · **Notes:** Key clause [8.5], [13.1] at rank 1

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q2

Record `large_67_clauses__bge_base__fixed_length__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `fixed_length-014`, clauses [6.3, 6.4], cosine 0.6600

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `fixed_length-038`, clauses [14.2, 14.3, 14.4], cosine 0.6182

> The team may add a short pickup-window feature so Buyers can plan trips efficiently. At the start of each semester, new students arrive with little furniture and tight budgets. During this period the team will give priority in search results to Listings that are free or well priced, and Moderators will watch more closely for price gouging, scams aimed at new students, and fake Listings. Orientation material and the platform's home page will include safety tips written for first-year and international students, who may be unfamiliar with local scams and with the risks of meeting strangers. Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Rank 3** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.5914

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is clear that a Bundle is a group of related items offered together, and the Bundle price must be lower than or equal to the combined price of its parts [6.4]. The policy also states that the team may highlight selected bundles as Featured Bundles, and that items included in a Featured Bundle must pass a quick quality and safety check [14.3]. While the policy does not specify a minimum number of items in a Bundle, it does mention that a Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set [6.4]. Therefore, it is possible that a Buyer could purchase only three items or fewer from a Bundle, but this would depend on the specific terms of the Listing.

**Scores:** context 3/3, answer 3/3 · **Latency:** 12.86 s · input/output tokens 1016/182 · **Notes:** Key clause [6.4] at rank 1

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q3

Record `large_67_clauses__bge_base__fixed_length__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.6070

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 2** — `fixed_length-014`, clauses [6.3, 6.4], cosine 0.6020

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 3** — `fixed_length-013`, clauses [6.1, 6.2], cosine 0.5849

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup. Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Answer:** The Bundle discount is not fixed, and Buyers may negotiate it with the Seller. According to clause 6.2, every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. This implies that the Bundle price is set by the Seller, but there is no explicit restriction against negotiation. However, the policy does not directly address negotiation of Bundle discounts, so it is not explicitly prohibited. [6.2]

**Scores:** context 3/2, answer 2/1 · **Latency:** 7.43 s · input/output tokens 997/102 · **Notes:** Key clause [6.4] only at rank 2; no clause says whether the discount is negotiable; unsupported claim

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q4

Record `large_67_clauses__bge_base__fixed_length__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `fixed_length-020`, clauses [8.4, 8.5], cosine 0.7208

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price.

**Rank 2** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.6834

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 3** — `fixed_length-023`, clauses [9.2, 9.3], cosine 0.6568

> Posting a Listing as a front for an off-platform business, a resale operation that buys items in bulk from others, or a lead-generation scheme is not permitted unless the team has approved it in advance. MoveOn is meant for students selling their own belongings, not for businesses. A User who regularly lists large numbers of new items, buys from free Listings in order to resell, or appears to run a store may be asked to stop. Student organizations may hold fundraising sales only with advance permission from the team, and must label such Listings clearly. Local businesses and landlords may not post on MoveOn, though the team may work with them separately on donation drives or move-out collections.

**Answer:** MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. The platform does not process payments and is not a party to any sale, so it does not intervene in payment disputes or contact issues between Buyers and Sellers. Instead, Users are encouraged to resolve such issues through direct communication. If direct communication fails, either party may ask the team to look at the case, but the team acts as a neutral helper and cannot force a refund, collect money, or take back an item. Users may need to seek legal remedies through small claims court or other lawful routes if necessary. [8.4]

**Scores:** context 3/2, answer 3/3 · **Latency:** 9.23 s · input/output tokens 799/138 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q5

Record `large_67_clauses__bge_base__fixed_length__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `fixed_length-014`, clauses [6.3, 6.4], cosine 0.7036

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `fixed_length-029`, clauses [11.3], cosine 0.6156

> Users may not post content that infringes another person's copyright, trademark, or other rights. Listings may not use brand logos in a way that suggests the Seller is an authorized dealer, and may not offer items that copy a protected product or design. Pirated media, unlicensed software, and fake designer goods are prohibited. A rights holder who believes a Listing infringes their rights may send a written notice to the team, which will review it promptly, remove the content if the claim appears valid, and tell the affected User, who may respond.

**Rank 3** — `fixed_length-012`, clauses [5.4], cosine 0.6056

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.20 s · input/output tokens 727/60 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q1

Record `large_67_clauses__bge_base__overlapping_paragraph__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6733

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 2** — `overlapping_paragraph-038`, clauses [13.4], cosine 0.6339

> Occasional sales of used personal belongings by students are generally not business activity, but Users are responsible for knowing and following any tax or licensing rules that apply to them. Sellers must not list items in violation of lease terms, residence hall rules, product recalls, or safety laws. The team may remove any item that appears on a recall list, such as a space heater or a crib, even if the Seller was unaware of the recall, and will explain the reason to the Seller.

**Rank 3** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6321

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the seller. The team can help review the situation, but they cannot force a refund, collect money, or take back an item. If the conversation fails, the team can assist in reviewing the case, but they do not act as a judge. For larger losses, users may need to use small claims court or other lawful routes. The specific process for returns is not detailed in the provided evidence. [13.1]

**Scores:** context 3/2, answer 3/3 · **Latency:** 7.87 s · input/output tokens 823/116 · **Notes:** Key clause [8.5], [13.1] at rank 1

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q2

Record `large_67_clauses__bge_base__overlapping_paragraph__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `overlapping_paragraph-015`, clauses [6.3, 6.4], cosine 0.6600

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `overlapping_paragraph-041`, clauses [14.3, 14.4], cosine 0.5997

> At the start of each semester, new students arrive with little furniture and tight budgets. During this period the team will give priority in search results to Listings that are free or well priced, and Moderators will watch more closely for price gouging, scams aimed at new students, and fake Listings. Orientation material and the platform's home page will include safety tips written for first-year and international students, who may be unfamiliar with local scams and with the risks of meeting strangers. Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Rank 3** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.5890

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Answer:** No, a Buyer cannot purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. However, it does not explicitly restrict the number of items a Buyer can purchase from a Bundle. The policy focuses on the pricing and description requirements for Bundles, not on the quantity of items a Buyer can take. Therefore, the policy does not establish a rule that limits Buyers to purchasing only three items or fewer from a Bundle. [6.3]

**Scores:** context 3/3, answer 1/1 · **Latency:** 8.59 s · input/output tokens 964/122 · **Notes:** Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’)

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q3

Record `large_67_clauses__bge_base__overlapping_paragraph__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6040

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 2** — `overlapping_paragraph-015`, clauses [6.3, 6.4], cosine 0.6020

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 3** — `overlapping_paragraph-021`, clauses [8.4, 8.5], cosine 0.5850

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** The Bundle discount is not fixed, and Buyers may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. This implies that the Bundle price is set by the Seller and can be negotiated, as the Bundle price is not necessarily fixed. Additionally, the policy does not explicitly state that the Bundle discount is fixed, which supports the idea that negotiation is possible. [6.4]

**Scores:** context 3/2, answer 3/3 · **Latency:** 7.91 s · input/output tokens 995/110 · **Notes:** Key clause [6.4] only at rank 2; no clause says whether the discount is negotiable

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q4

Record `large_67_clauses__bge_base__overlapping_paragraph__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `overlapping_paragraph-021`, clauses [8.4, 8.5], cosine 0.7163

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 2** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6844

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 3** — `overlapping_paragraph-014`, clauses [6.1, 6.2], cosine 0.6454

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup. Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Answer:** MoveOn provides protection by allowing Sellers to offer the item to others if a Buyer does not show up or becomes uncontactable. The platform expects both Sellers and Buyers to honor their agreed-upon price and pickup time. If a Buyer agrees to buy and then stops responding, the Seller should be told so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges. Additionally, MoveOn does not process payments and will never ask for payment information in a Message. If a payment problem arises, Users should never send money before they have seen the item, and MoveOn does not facilitate payment processing, so it cannot directly assist with payment issues. However, the platform encourages Users to resolve such issues through direct communication or by seeking legal remedies if necessary. [6.2]

**Scores:** context 3/3, answer 3/3 · **Latency:** 12.15 s · input/output tokens 995/173 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q5

Record `large_67_clauses__bge_base__overlapping_paragraph__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `overlapping_paragraph-015`, clauses [6.3, 6.4], cosine 0.7036

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6248

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6216

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.61 s · input/output tokens 970/60 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q1

Record `large_67_clauses__bge_base__hybrid_strategic__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `hybrid_strategic-050`, clauses [13.1], cosine 0.6957

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes.

**Rank 2** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6919

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 3** — `hybrid_strategic-020`, clauses [6.2], cosine 0.6594

> Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Answer:** If you buy an item you do not like or it does not match the Listing, you may have the option to return it, but the process depends on the circumstances. According to the policy, if an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely [6.2]. Additionally, if a Buyer finds that an item differs from the Listing, they may decline it or ask for a lower price [8.5]. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13 [8.5]. The team can review the case, remove misleading content, and apply this policy to behavior, but it cannot force a refund, collect money, or take back an item [13.1]. For larger losses, users may use small claims court or other lawful routes.

**Scores:** context 3/3, answer 3/3 · **Latency:** 12.96 s · input/output tokens 620/206 · **Notes:** Key clause [8.5], [13.1] at rank 1

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q2

Record `large_67_clauses__bge_base__hybrid_strategic__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `hybrid_strategic-022`, clauses [6.4], cosine 0.7162

> Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `hybrid_strategic-057`, clauses [14.4], cosine 0.6579

> Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Rank 3** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6093

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** The evidence does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is implied that Buyers can purchase individual items from a Bundle, as every item in a Bundle must be described individually in the Listing [6.4]. Additionally, the policy allows Buyers to decline an item if it differs from the Listing [8.5], suggesting that partial purchases may be possible. Since the policy does not explicitly restrict the number of items a Buyer can purchase from a Bundle, it is reasonable to infer that a Buyer could purchase three items or fewer from a Bundle.

**Scores:** context 3/3, answer 3/3 · **Latency:** 7.66 s · input/output tokens 601/120 · **Notes:** Key clause [6.4] at rank 1

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q3

Record `large_67_clauses__bge_base__hybrid_strategic__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `hybrid_strategic-022`, clauses [6.4], cosine 0.6727

> Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `hybrid_strategic-050`, clauses [13.1], cosine 0.6135

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes.

**Rank 3** — `hybrid_strategic-057`, clauses [14.4], cosine 0.6082

> Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Answer:** The evidence does not establish whether the Bundle discount is fixed or if negotiation is allowed. It states that the Bundle price must be lower than or equal to the combined price of its parts, but it does not mention negotiation of the discount [6.4].

**Scores:** context 3/2, answer 3/3 · **Latency:** 3.49 s · input/output tokens 631/52 · **Notes:** Key clause [6.4] at rank 1; no clause says whether the discount is negotiable

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q4

Record `large_67_clauses__bge_base__hybrid_strategic__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `hybrid_strategic-030`, clauses [8.4], cosine 0.7236

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect.

**Rank 2** — `hybrid_strategic-051`, clauses [13.2], cosine 0.6662

> MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 3** — `hybrid_strategic-034`, clauses [9.3], cosine 0.6499

> MoveOn is meant for students selling their own belongings, not for businesses. A User who regularly lists large numbers of new items, buys from free Listings in order to resell, or appears to run a store may be asked to stop. Student organizations may hold fundraising sales only with advance permission from the team, and must label such Listings clearly. Local businesses and landlords may not post on MoveOn, though the team may work with them separately on donation drives or move-out collections.

**Answer:** MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. The platform does not process payments and is not involved in the sale, so it does not intervene in such situations. Users are advised to use safe payment methods and to never send money before inspecting the item, as these steps are meant to reduce the risk of scams rather than provide recourse if issues arise [8.4].

**Scores:** context 3/2, answer 3/3 · **Latency:** 6.12 s · input/output tokens 589/96 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q5

Record `large_67_clauses__bge_base__hybrid_strategic__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `hybrid_strategic-021`, clauses [6.3], cosine 0.7183

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price.

**Rank 2** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6336

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `hybrid_strategic-020`, clauses [6.2], cosine 0.6281

> Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must truly be free, and a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.02 s · input/output tokens 608/60 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q1

Record `large_67_clauses__bge_large__fixed_length__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.7107

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 2** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6825

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `fixed_length-012`, clauses [5.4], cosine 0.6759

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the Seller. The policy encourages users to try to settle the problem directly, such as by agreeing on a partial refund or returning the item [13.1]. If this fails, either party may ask the team to look at the case, but the team acts as a neutral helper and cannot force a refund, collect money, or take back an item [13.2]. The process for returns is not explicitly detailed in the provided policy, but the general approach is to resolve disputes through direct communication or by involving the team as a neutral party. For larger issues, users may need to pursue legal remedies through small claims court or other lawful means.

**Scores:** context 3/2, answer 3/3 · **Latency:** 10.74 s · input/output tokens 822/161 · **Notes:** Key clause [8.5], [13.1] at rank 1

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q2

Record `large_67_clauses__bge_large__fixed_length__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `fixed_length-014`, clauses [6.3, 6.4], cosine 0.6721

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `fixed_length-016`, clauses [7.2, 7.3], cosine 0.6699

> Messages are for arranging the sale or gift of an item and may not be used for advertising, recruiting, political campaigning, surveys, or chain messages. Mass messaging, copy-and-paste offers sent to many Sellers, and the use of bots, scrapers, or scripts to post, message, or collect data are not allowed. A User may not send the same message to more than a small number of Sellers in a short period, and the platform may limit the number of new conversations a new account can start each day. These limits protect Sellers from being overwhelmed during Move-Out Season, when a single popular Listing can attract dozens of inquiries within minutes.

**Rank 3** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6696

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** No, a Buyer may not purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. However, it does not explicitly restrict the number of items a Buyer can purchase from a Bundle. The policy focuses on the Bundle's pricing and description requirements, not on the quantity a Buyer can take. Therefore, the policy does not establish a limit on the number of items a Buyer may purchase from a Bundle. [6.3]

**Scores:** context 3/3, answer 1/1 · **Latency:** 8.28 s · input/output tokens 911/119 · **Notes:** Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’)

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q3

Record `large_67_clauses__bge_large__fixed_length__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.6568

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Rank 2** — `fixed_length-013`, clauses [6.1, 6.2], cosine 0.6560

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup. Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Rank 3** — `fixed_length-020`, clauses [8.4, 8.5], cosine 0.6454

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price.

**Answer:** The evidence does not mention a "Bundle discount" or specify whether such a discount is fixed or negotiable. Therefore, it cannot be determined from the provided policy evidence whether the Bundle discount is fixed or can be negotiated. [No applicable clause]

**Scores:** context 3/2, answer 3/2 · **Latency:** 3.90 s · input/output tokens 909/50 · **Notes:** Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; minor unsupported inference; no clause citation

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q4

Record `large_67_clauses__bge_large__fixed_length__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `fixed_length-020`, clauses [8.4, 8.5], cosine 0.7295

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price.

**Rank 2** — `fixed_length-019`, clauses [8.2, 8.3], cosine 0.7012

> A User who feels threatened should leave, call campus police or 911 in an emergency, and report the incident to MoveOn afterward so that the team can act to protect others. Many items on MoveOn, such as desks, bookshelves, and mini fridges, are too large to carry to a public location. For these, the Seller should arrange pickup at the building entrance or a shared lobby, and the Buyer should bring help and a way to move the item. Users must follow residence hall rules on guests, escorts, and quiet hours, and must not bring non-resident visitors into a building in violation of those rules. Neither party should carry heavy furniture alone, and both should respect other residents by keeping hallways and elevators clear during handoff.

**Rank 3** — `fixed_length-034`, clauses [13.1, 13.2], cosine 0.6959

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk.

**Answer:** MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. The platform does not process payments and is not a party to any sale, so it does not intervene in payment disputes or follow-up actions between Buyers and Sellers. Instead, Buyers and Sellers are expected to resolve such issues themselves, with the platform only offering guidance on safe payment practices [8.4]. If a problem cannot be resolved directly, Users may seek legal remedies through small claims court or other lawful routes [13.1]. MoveOn does not guarantee the accuracy of Listings, the safety of items, or the identity of Users, and does not take part in the sale process [13.2].

**Scores:** context 3/2, answer 3/3 · **Latency:** 10.37 s · input/output tokens 815/154 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q5

Record `large_67_clauses__bge_large__fixed_length__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `fixed_length-014`, clauses [6.3, 6.4], cosine 0.7753

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6577

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6472

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, and a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.90 s · input/output tokens 1037/60 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q1

Record `large_67_clauses__bge_large__overlapping_paragraph__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.7221

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 2** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6770

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `overlapping_paragraph-008`, clauses [4.1, 4.2], cosine 0.6658

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them.

**Answer:** If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the seller. The policy encourages users to try to settle the problem directly, such as by agreeing on a partial refund or returning the item [13.1]. If this fails, either party may ask the team to look at the case. The team acts as a neutral helper and can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. However, the team cannot force a refund, collect money, or take back an item [13.2]. For returns, the policy does not explicitly outline a return process, but it does state that once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time [4.3]. This suggests that once a sale is completed, the item is no longer available for return through the platform. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes.

**Scores:** context 3/2, answer 3/3 · **Latency:** 16.20 s · input/output tokens 1017/232 · **Notes:** Key clause [8.5], [13.1] at rank 1

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q2

Record `large_67_clauses__bge_large__overlapping_paragraph__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6784

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-015`, clauses [6.3, 6.4], cosine 0.6721

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 3** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.6621

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it specifies that every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts [6.3]. It also mentions that a Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set [6.3]. Therefore, the policy does not prohibit a Buyer from purchasing only three items or fewer from a Bundle, but it does not confirm this as a permitted action either. The ability to purchase a subset of items from a Bundle is not addressed in the provided policy evidence.

**Scores:** context 3/3, answer 3/3 · **Latency:** 11.02 s · input/output tokens 1070/151 · **Notes:** Key clause [6.4] only at rank 2

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q3

Record `large_67_clauses__bge_large__overlapping_paragraph__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6579

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 2** — `overlapping_paragraph-021`, clauses [8.4, 8.5], cosine 0.6566

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 3** — `overlapping_paragraph-014`, clauses [6.1, 6.2], cosine 0.6560

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup. Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Answer:** The evidence does not mention a "Bundle discount" or provide information on whether such a discount is fixed or negotiable. Therefore, it cannot be determined from the provided policy evidence whether a Bundle discount is fixed or can be negotiated with the Seller. [0]

**Scores:** context 3/2, answer 3/2 · **Latency:** 4.18 s · input/output tokens 984/53 · **Notes:** Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; minor unsupported inference; no clause citation

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q4

Record `large_67_clauses__bge_large__overlapping_paragraph__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `overlapping_paragraph-021`, clauses [8.4, 8.5], cosine 0.7367

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 2** — `overlapping_paragraph-036`, clauses [13.1, 13.2], cosine 0.6958

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes. MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Rank 3** — `overlapping_paragraph-020`, clauses [8.2, 8.3], cosine 0.6854

> Users should tell a friend or roommate where they are going, who they are meeting, and when they expect to return. They should meet during daylight when possible, bring a friend for large or valuable items, keep their phone charged, and trust their instincts: anyone who feels uncomfortable may leave without explanation and cancel the sale. Neither side may pressure the other to go to a second location or to move an item to a private place. A User who feels threatened should leave, call campus police or 911 in an emergency, and report the incident to MoveOn afterward so that the team can act to protect others. Many items on MoveOn, such as desks, bookshelves, and mini fridges, are too large to carry to a public location. For these, the Seller should arrange pickup at the building entrance or a shared lobby, and the Buyer should bring help and a way to move the item. Users must follow residence hall rules on guests, escorts, and quiet hours, and must not bring non-resident visitors into a building in violation of those rules. Neither party should carry heavy furniture alone, and both should respect other residents by keeping hallways and elevators clear during handoff.

**Answer:** MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. The platform does not process payments and is not a party to any sale, so it does not intervene in payment disputes or contact issues. Users are expected to resolve such issues through direct communication or other means. If a User feels threatened during a meeting, they are advised to leave, call campus police or 911 in an emergency, and report the incident to MoveOn afterward so that the team can act to protect others. However, MoveOn does not guarantee the safety of Users or provide direct assistance in cases of non-attendance or payment problems. [8.4]

**Scores:** context 3/2, answer 3/3 · **Latency:** 10.30 s · input/output tokens 976/147 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q5

Record `large_67_clauses__bge_large__overlapping_paragraph__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `overlapping_paragraph-015`, clauses [6.3, 6.4], cosine 0.7753

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price. Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6685

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `overlapping_paragraph-021`, clauses [8.4, 8.5], cosine 0.6548

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect. Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.64 s · input/output tokens 990/60 · **Notes:** Key clause [6.3] at rank 1

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q1

Record `large_67_clauses__bge_large__hybrid_strategic__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `hybrid_strategic-050`, clauses [13.1], cosine 0.7153

> Most disagreements about a sale can be solved by a polite conversation. Users are asked to try first to settle a problem directly, for example by agreeing on a partial refund or returning an item. If that fails, either person may ask the team to look at the case. The team acts as a neutral helper and not as a judge: it can review Messages and Listings, ask each side for their account, remove misleading content, and apply this policy to behavior. It cannot force a refund, collect money, or take back an item. Users who want a legal remedy for a larger loss may use small claims court or other lawful routes.

**Rank 2** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6970

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 3** — `hybrid_strategic-020`, clauses [6.2], cosine 0.6848

> Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Answer:** If you buy an item you do not like or it does not match the Listing, you may have the option to return it, but the process depends on the circumstances. According to the policy, if an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely [6.2]. Additionally, if a Buyer finds that an item differs from the Listing, they may decline it or ask for a lower price [8.5]. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13 [8.5]. The team can review the case, remove misleading content, and apply this policy to behavior, but it cannot force a refund, collect money, or take back an item [13.1]. For larger losses, users may use small claims court or other lawful routes.

**Scores:** context 3/3, answer 3/3 · **Latency:** 13.14 s · input/output tokens 620/206 · **Notes:** Key clause [8.5], [13.1] at rank 1

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q2

Record `large_67_clauses__bge_large__hybrid_strategic__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `hybrid_strategic-022`, clauses [6.4], cosine 0.7649

> Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `hybrid_strategic-057`, clauses [14.4], cosine 0.6810

> Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Rank 3** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6717

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** The evidence does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is implied that Buyers can purchase individual items from a Bundle, as every item in a Bundle must be described individually in the Listing [6.4]. Additionally, the policy allows Buyers to decline an item if it differs from the Listing [8.5], suggesting that partial purchases may be possible. Since the policy does not explicitly restrict the number of items a Buyer can purchase from a Bundle, it is reasonable to infer that a Buyer could purchase three items or fewer from a Bundle.

**Scores:** context 3/3, answer 3/3 · **Latency:** 7.77 s · input/output tokens 601/120 · **Notes:** Key clause [6.4] at rank 1

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q3

Record `large_67_clauses__bge_large__hybrid_strategic__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `hybrid_strategic-022`, clauses [6.4], cosine 0.7194

> Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2** — `hybrid_strategic-020`, clauses [6.2], cosine 0.6933

> Once a Seller and a Buyer agree on a price and a pickup time, both are expected to honor the agreement. A Seller may not raise the price after the Buyer arrives, and a Buyer may not demand a lower price at the handoff unless the item is materially different from the Listing. If an item is not as described, the Buyer may decline it without penalty and the Seller should accept that choice politely. A Buyer who agrees to buy and then stops responding should tell the Seller, so the item can be offered to others. Repeated "no-shows" may lead to a warning and then to a temporary loss of messaging privileges.

**Rank 3** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6699

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** The Bundle discount is not fixed, and a Buyer may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. This implies that the Bundle price is subject to the combined price of its parts, but it does not explicitly state whether negotiation is allowed. However, since the Bundle price is not fixed and must be lower than or equal to the combined price, it suggests that the Seller has some flexibility in setting the Bundle price, which could imply that negotiation is possible. Therefore, based on the evidence provided, it is reasonable to conclude that the Bundle discount is not fixed and can be negotiated with the Seller. [6.4]

**Scores:** context 3/2, answer 3/3 · **Latency:** 10.50 s · input/output tokens 620/160 · **Notes:** Key clause [6.4] at rank 1; no clause says whether the discount is negotiable

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q4

Record `large_67_clauses__bge_large__hybrid_strategic__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `hybrid_strategic-030`, clauses [8.4], cosine 0.7182

> MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are cash in person or a trusted peer-to-peer app used only after the Buyer has inspected the item. Users should never send money before they have seen the item, never pay a deposit to "hold" an item for someone they have not met, and never accept an overpayment with a request to refund the difference, which is a common scam. MoveOn will never ask for payment information in a Message. If the platform adds payment features later, this section will be updated and Users will be told before the change takes effect.

**Rank 2** — `hybrid_strategic-032`, clauses [9.1], cosine 0.6863

> Marketplaces attract fraud, and students are frequent targets because they are young, busy, and often new to a city. The most common scams include fake Listings that use photos taken from the internet, Sellers who ask for payment before showing the item, Buyers who send a fake payment confirmation or a bad check, requests to pay with gift cards, "overpayment" refund tricks, and messages that claim to be from MoveOn or the University and ask for a login. Users should treat any request for advance payment, an unusual payment method, or a rush as a warning sign. MoveOn will publish short safety tips on the platform and will refresh them each semester.

**Rank 3** — `hybrid_strategic-051`, clauses [13.2], cosine 0.6753

> MoveOn only provides a place where students can find each other. The team does not own, inspect, store, or guarantee any item, and does not take part in the sale. It cannot promise that a Listing is accurate, that an item is safe or legal, or that a User is who they claim to be, even though verification and moderation lower the risk. Each User is responsible for judging whether to buy, sell, or meet, and for taking sensible care when doing so.

**Answer:** MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. The platform does not process payments, own, inspect, store, or guarantee any item, and does not take part in the sale. Users are responsible for resolving such issues themselves, as MoveOn does not intervene in disputes or payment problems between Buyers and Sellers [13.2].

**Scores:** context 3/2, answer 3/3 · **Latency:** 5.82 s · input/output tokens 624/88 · **Notes:** Key clause [8.4], [8.5] at rank 1

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q5

Record `large_67_clauses__bge_large__hybrid_strategic__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `hybrid_strategic-021`, clauses [6.3], cosine 0.7664

> Free items are central to MoveOn's sustainability mission. A Giveaway must truly be free: a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return. When many people ask for a free item, the Seller may choose any fair method, such as first come first served, a random draw, or giving priority to someone in need, but should explain the method in the Listing. Because free items attract resellers, a Seller may ask Buyers not to resell Giveaways for profit. Users may not take free items from MoveOn only to relist them at a price.

**Rank 2** — `hybrid_strategic-031`, clauses [8.5], cosine 0.6573

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Rank 3** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6548

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** No, a seller may not require a donation for a free item. According to the policy, a Giveaway must truly be free, and a Seller may not ask for a payment, a donation, a favor, a tip, or the purchase of another item in return [6.3].

**Scores:** context 3/3, answer 3/3 · **Latency:** 4.10 s · input/output tokens 582/60 · **Notes:** Key clause [6.3] at rank 1

---

## Small subset (20 clauses)

### BAAI/bge-small-en-v1.5 · Fixed length · Q1

Record `small_20_clause_subset__bge_small__fixed_length__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.7109

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-008`, clauses [4.1, 4.2], cosine 0.6949

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters.

**Rank 3** — `fixed_length-012`, clauses [5.4], cosine 0.6932

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** The provided policy evidence does not address return policies or procedures for items purchased on MoveOn. Therefore, it cannot be determined from the given information whether returns are allowed or how the process would work.

**Scores:** context 1/1, answer 3/3 · **Latency:** 3.11 s · input/output tokens 888/40 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q2

Record `small_20_clause_subset__bge_small__fixed_length__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6359

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6280

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 3** — `fixed_length-012`, clauses [5.4], cosine 0.6076

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit, but does not specify quantity restrictions for purchases from a Bundle. [5.4]

**Scores:** context 2/1, answer 3/3 · **Latency:** 4.49 s · input/output tokens 860/62 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q3

Record `small_20_clause_subset__bge_small__fixed_length__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6470

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6314

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 3** — `fixed_length-008`, clauses [4.1, 4.2], cosine 0.6299

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters.

**Answer:** The evidence does not establish whether the Bundle discount is fixed or if Buyers can negotiate it with Sellers. The policy mentions "Bundle" as a group of related items offered together but does not specify rules regarding discounts or negotiation for Bundles [4.3].

**Scores:** context 1/1, answer 3/3 · **Latency:** 4.20 s · input/output tokens 1040/52 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q4

Record `small_20_clause_subset__bge_small__fixed_length__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6830

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6815

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 3** — `fixed_length-007`, clauses [3.3, 3.4], cosine 0.6786

> Users are responsible for everything done through their accounts. They should choose a strong, unique password, avoid reusing passwords from other services, and sign out of shared computers in labs or libraries. MoveOn will never ask a User for a password in a message, and Users should never give their password to anyone who claims to be a moderator. If a User suspects someone else has accessed their account, they should change the password at once and report the incident. The team may temporarily lock an account that shows signs of compromise, such as sudden mass posting or messages that look automated, and will restore access after identity is confirmed. The team's own technical practices support these user duties during both development and everyday operation of the platform. Secret keys and credentials are kept outside the code repository in local environment files that are never committed. Only a template identifying the required settings is shared, and production settings are separated from development settings so the two environments remain distinct. Demo data used for testing is clearly separate from real user data and is never presented to the public as real Listings.

**Answer:** MoveOn does not explicitly provide specific help or protection for a Buyer who does not show up or has a payment problem and can no longer be contacted. The policy focuses on seller responsibilities, such as marking a Listing as closed within twenty-four hours if the item is sold, given away, or no longer available [4.2]. It also outlines seller obligations regarding item ownership and listing rules [4.3], but does not detail specific mechanisms for resolving issues related to Buyers failing to contact or pay for items.

**Scores:** context 1/1, answer 2/3 · **Latency:** 7.42 s · input/output tokens 995/103 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Fixed length · Q5

Record `small_20_clause_subset__bge_small__fixed_length__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6558

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-012`, clauses [5.4], cosine 0.6408

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `fixed_length-010`, clauses [5.1, 5.2], cosine 0.6076

> The following may never be listed, offered, or requested on MoveOn: firearms, ammunition, explosives, and weapons of any kind; illegal drugs and drug paraphernalia; prescription medication and controlled substances; alcohol, tobacco, vaping products, and cannabis products; stolen goods; counterfeit or knock-off items sold as genuine; fake or altered identification cards; and anything whose sale is barred by Illinois or federal law. Services that facilitate academic dishonesty, such as paid essay writing, answer keys, or exam-taking, are also prohibited, as are tickets or passes the Seller is not allowed to transfer. Listings for live animals, human body products, and adult or sexually explicit material are not allowed. These rules apply regardless of how the Listing is worded, including coded language or jokes. Some items may be listed only under conditions that protect the buyer. Used mattresses and upholstered furniture must be disclosed as such and must be free of pests, mold, and strong odors, because bed bugs are a real risk in shared housing.

**Answer:** The evidence does not explicitly address whether a seller can require a donation for a free item. However, based on the provided information, it is clear that MoveOn prohibits the sale of certain items, including firearms, ammunition, explosives, and weapons of any kind, as well as illegal drugs and drug paraphernalia, prescription medication and controlled substances, alcohol, tobacco, vaping products, and cannabis products, among others [5.1, 5.2]. Additionally, the platform prohibits the listing of items that are stolen goods, counterfeit or knock-off items sold as genuine, and fake or altered identification cards [5.1, 5.2]. Since the question pertains to a donation for a free item, which is not explicitly covered by the provided evidence, it cannot be determined from the given information whether such a practice is allowed or prohibited. The evidence focuses on prohibited items and the rules around listing and selling items, but does not address the specific scenario of requiring a donation for a free item. Therefore, the answer cannot be determined from the provided evidence.

**Scores:** context 1/1, answer 3/3 · **Latency:** 14.09 s · input/output tokens 808/216 · **Notes:** Key clause [6.3] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q1

Record `small_20_clause_subset__bge_small__overlapping_paragraph__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `overlapping_paragraph-008`, clauses [4.1, 4.2], cosine 0.7024

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them.

**Rank 2** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6975

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6859

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** The provided policy evidence does not address return policies or procedures for items purchased on MoveOn. It focuses on listing requirements, item descriptions, and prohibited items, but does not specify how returns or exchanges are handled. Therefore, the evidence does not establish a requested fact about return policies.

**Scores:** context 1/1, answer 3/3 · **Latency:** 4.53 s · input/output tokens 1004/57 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q2

Record `small_20_clause_subset__bge_small__overlapping_paragraph__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6313

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6216

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.6135

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, and there is no restriction mentioned on the number of items a Buyer can purchase from a Bundle. Therefore, based on the provided evidence, it is not possible to determine if a Buyer can purchase only three items or fewer from a Bundle.

**Scores:** context 2/1, answer 3/3 · **Latency:** 6.30 s · input/output tokens 1013/85 · **Notes:** Key clause [6.4] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q3

Record `small_20_clause_subset__bge_small__overlapping_paragraph__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6444

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-008`, clauses [4.1, 4.2], cosine 0.6360

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them.

**Rank 3** — `overlapping_paragraph-009`, clauses [4.2, 4.3], cosine 0.6305

> A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The evidence provided does not mention a Bundle discount or any mechanism for Buyers to negotiate discounts with Sellers. Therefore, it cannot be determined from the given information whether the Bundle discount is fixed or negotiable. [0]

**Scores:** context 1/1, answer 3/2 · **Latency:** 3.76 s · input/output tokens 1026/44 · **Notes:** Key clause [6.4] is outside the 20-clause subset; minor unsupported inference; no clause citation

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q4

Record `small_20_clause_subset__bge_small__overlapping_paragraph__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `overlapping_paragraph-002`, clauses [1.2, 1.3], cosine 0.6943

> This policy applies to everyone who uses MoveOn in any way: people who browse listings, post items, save items to a personal list, assemble or view featured bundles, or send messages to other users. It also applies to the student team that builds and maintains the platform, and to any volunteer moderators the team appoints. The rules cover activity on the platform itself and activity that the platform makes possible, including in-person exchanges arranged through MoveOn messaging. If a feature is added later, such as ratings, payments, or notifications, this policy applies to it automatically until a more specific rule is written. Six principles shape every rule below. Safety comes first, because a cheap desk lamp is never worth a person's wellbeing. Honesty comes second, because buyers can only make good choices when listings are accurate. Respect applies to every message and every meetup. Affordability and sustainability explain why the platform exists at all. Privacy by default means MoveOn collects and shows only what a transaction requires. Fairness means rules are applied consistently, with a clear way to ask for a second look. When two rules seem to conflict, the team resolves the conflict in favor of the principle that better protects users from harm.

**Rank 2** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6831

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `overlapping_paragraph-007`, clauses [3.3, 3.4], cosine 0.6786

> Users are responsible for everything done through their accounts. They should choose a strong, unique password, avoid reusing passwords from other services, and sign out of shared computers in labs or libraries. MoveOn will never ask a User for a password in a message, and Users should never give their password to anyone who claims to be a moderator. If a User suspects someone else has accessed their account, they should change the password at once and report the incident. The team may temporarily lock an account that shows signs of compromise, such as sudden mass posting or messages that look automated, and will restore access after identity is confirmed. The team's own technical practices support these user duties during both development and everyday operation of the platform. Secret keys and credentials are kept outside the code repository in local environment files that are never committed. Only a template identifying the required settings is shared, and production settings are separated from development settings so the two environments remain distinct. Demo data used for testing is clearly separate from real user data and is never presented to the public as real Listings.

**Answer:** The evidence does not establish whether MoveOn provides help or protection for a Buyer who does not show up or has a payment problem and can no longer be contacted. The policy evidence focuses on rules regarding listings, user responsibilities, and technical practices, but does not mention specific mechanisms for resolving payment issues or non-attendance by Buyers.

**Scores:** context 1/1, answer 3/3 · **Latency:** 4.94 s · input/output tokens 955/66 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Overlapping paragraph · Q5

Record `small_20_clause_subset__bge_small__overlapping_paragraph__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6518

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6378

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `overlapping_paragraph-009`, clauses [4.2, 4.3], cosine 0.6145

> A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** No, a seller cannot require a donation for a free item. According to the policy, a Listing must clearly mark the price as "free" or specify a price. Requiring a donation would not be considered a clear "free" marking and could be seen as misleading information. Additionally, the policy emphasizes that Listings must describe one item or a clearly defined set of items, and any additional requirements beyond the stated price or "free" marking would not align with the guidelines provided in the evidence. [4.3]

**Scores:** context 1/1, answer 2/3 · **Latency:** 7.47 s · input/output tokens 948/105 · **Notes:** Key clause [6.3] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q1

Record `small_20_clause_subset__bge_small__hybrid_strategic__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `hybrid_strategic-011`, clauses [4.1], cosine 0.6999

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so.

**Rank 2** — `hybrid_strategic-018`, clauses [5.4], cosine 0.6932

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6907

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The provided evidence does not address return policies or procedures for items purchased on MoveOn. Therefore, it cannot be determined from the given information whether returns are allowed or how the return process works.

**Scores:** context 1/1, answer 3/3 · **Latency:** 2.83 s · input/output tokens 639/39 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q2

Record `small_20_clause_subset__bge_small__hybrid_strategic__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6353

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Rank 2** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6136

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Rank 3** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6099

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit, but does not specify quantity restrictions on purchases from a Bundle. Therefore, the evidence does not establish whether a Buyer can purchase only three items or fewer from a Bundle.

**Scores:** context 2/1, answer 3/3 · **Latency:** 5.17 s · input/output tokens 644/78 · **Notes:** Key clause [6.4] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q3

Record `small_20_clause_subset__bge_small__hybrid_strategic__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `hybrid_strategic-019`, clauses [6.1], cosine 0.6702

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup.

**Rank 2** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6394

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Rank 3** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6323

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The evidence does not establish whether the Bundle discount is fixed or if Buyers can negotiate it with Sellers. The policy mentions "Bundle" as a group of related items offered together but does not specify rules regarding discounts or negotiation for Bundles [4.3].

**Scores:** context 3/2, answer 3/3 · **Latency:** 3.70 s · input/output tokens 673/52 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q4

Record `small_20_clause_subset__bge_small__hybrid_strategic__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `hybrid_strategic-019`, clauses [6.1], cosine 0.6896

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup.

**Rank 2** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6891

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Rank 3** — `hybrid_strategic-002`, clauses [1.2], cosine 0.6888

> This policy applies to everyone who uses MoveOn in any way: people who browse listings, post items, save items to a personal list, assemble or view featured bundles, or send messages to other users. It also applies to the student team that builds and maintains the platform, and to any volunteer moderators the team appoints. The rules cover activity on the platform itself and activity that the platform makes possible, including in-person exchanges arranged through MoveOn messaging. If a feature is added later, such as ratings, payments, or notifications, this policy applies to it automatically until a more specific rule is written.

**Answer:** The evidence provided does not specify what help or protection MoveOn provides if a Buyer does not show up or has a payment problem and can no longer be contacted. The policy details focus on pricing guidelines, definitions of terms, and the scope of the policy, but do not address resolution mechanisms for buyer non-attendance or payment issues.

**Scores:** context 1/1, answer 3/3 · **Latency:** 4.52 s · input/output tokens 684/67 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-small-en-v1.5 · Hybrid strategic · Q5

Record `small_20_clause_subset__bge_small__hybrid_strategic__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6424

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `hybrid_strategic-018`, clauses [5.4], cosine 0.6408

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6290

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The evidence does not explicitly address whether a seller can require a donation for a free item. However, it is clear that sellers must list only items they own or have clear permission to sell, and they cannot post the same item more than once or repost it repeatedly. Additionally, sellers must mark a Listing as closed within twenty-four hours if the item is sold, given away, or no longer available. These rules focus on the ownership and listing practices but do not directly address the possibility of requiring a donation for a free item. Therefore, the policy as drafted does not provide information to determine if this practice is allowed.

**Scores:** context 1/1, answer 3/3 · **Latency:** 7.94 s · input/output tokens 569/124 · **Notes:** Key clause [6.3] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q1

Record `small_20_clause_subset__bge_base__fixed_length__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `fixed_length-012`, clauses [5.4], cosine 0.6365

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 2** — `fixed_length-008`, clauses [4.1, 4.2], cosine 0.6325

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters.

**Rank 3** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6219

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Answer:** The policy evidence provided does not address return policies or procedures for items purchased on MoveOn. Therefore, it cannot be determined from the given information whether a return is possible or how the process would work.

**Scores:** context 1/1, answer 3/3 · **Latency:** 3.21 s · input/output tokens 888/41 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q2

Record `small_20_clause_subset__bge_base__fixed_length__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.5914

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 2** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.5479

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `fixed_length-011`, clauses [5.2, 5.3], cosine 0.5434

> Electrical items such as space heaters, hot plates, extension cords, and lamps must be in safe working condition, and Sellers should not list items that University housing rules ban in residence halls, such as certain cooking appliances, candles, or halogen lamps, without a clear note that the item may not be allowed in a dorm. Used helmets, car seats, and similar safety gear may be listed only with a clear statement of their age and history, since hidden damage can cause injury. Opened cosmetics and personal care items may not be sold. Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit. Since the policy does not specify a limit on the number of items a Buyer can purchase from a Bundle, it is not possible to determine from the provided evidence whether a Buyer can purchase only three items or fewer. [5.2]

**Scores:** context 2/1, answer 3/3 · **Latency:** 6.75 s · input/output tokens 993/92 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q3

Record `small_20_clause_subset__bge_base__fixed_length__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.5523

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 2** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.5522

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `fixed_length-008`, clauses [4.1, 4.2], cosine 0.5377

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters.

**Answer:** The policy does not explicitly address whether Bundle discounts are fixed or negotiable. However, it states that a Bundle is a group of related items offered together, and a Featured Bundle is one the team highlights on the browse page. Since the policy does not specify rules about pricing for Bundles, including whether discounts are fixed or negotiable, it cannot be determined from the provided evidence. [4.2]

**Scores:** context 1/1, answer 3/3 · **Latency:** 6.23 s · input/output tokens 1040/82 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q4

Record `small_20_clause_subset__bge_base__fixed_length__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6405

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 2** — `fixed_length-012`, clauses [5.4], cosine 0.6221

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `fixed_length-010`, clauses [5.1, 5.2], cosine 0.6035

> The following may never be listed, offered, or requested on MoveOn: firearms, ammunition, explosives, and weapons of any kind; illegal drugs and drug paraphernalia; prescription medication and controlled substances; alcohol, tobacco, vaping products, and cannabis products; stolen goods; counterfeit or knock-off items sold as genuine; fake or altered identification cards; and anything whose sale is barred by Illinois or federal law. Services that facilitate academic dishonesty, such as paid essay writing, answer keys, or exam-taking, are also prohibited, as are tickets or passes the Seller is not allowed to transfer. Listings for live animals, human body products, and adult or sexually explicit material are not allowed. These rules apply regardless of how the Listing is worded, including coded language or jokes. Some items may be listed only under conditions that protect the buyer. Used mattresses and upholstered furniture must be disclosed as such and must be free of pests, mold, and strong odors, because bed bugs are a real risk in shared housing.

**Answer:** The evidence does not establish what help or protection MoveOn provides if a Buyer does not show up or has a payment problem and can no longer be contacted.

**Scores:** context 1/1, answer 3/3 · **Latency:** 2.62 s · input/output tokens 830/32 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Fixed length · Q5

Record `small_20_clause_subset__bge_base__fixed_length__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `fixed_length-012`, clauses [5.4], cosine 0.6056

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 2** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.5951

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `fixed_length-008`, clauses [4.1, 4.2], cosine 0.5852

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters.

**Answer:** No, a seller cannot require a donation for a free item. According to the policy, a Listing must either state a price or a clear "free" marking. If an item is listed as free, the seller cannot impose a donation or any other form of payment. [4.2]

**Scores:** context 1/1, answer 2/3 · **Latency:** 4.44 s · input/output tokens 870/60 · **Notes:** Key clause [6.3] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q1

Record `small_20_clause_subset__bge_base__overlapping_paragraph__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6321

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-008`, clauses [4.1, 4.2], cosine 0.6301

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them.

**Rank 3** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6184

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** The policy evidence provided does not address return policies or procedures for items purchased on MoveOn. Therefore, it cannot be determined from the given information whether returns are allowed or how the process would work.

**Scores:** context 1/1, answer 3/3 · **Latency:** 3.38 s · input/output tokens 1004/40 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q2

Record `small_20_clause_subset__bge_base__overlapping_paragraph__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.5773

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Rank 2** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.5669

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `overlapping_paragraph-012`, clauses [5.2, 5.3], cosine 0.5545

> Some items may be listed only under conditions that protect the buyer. Used mattresses and upholstered furniture must be disclosed as such and must be free of pests, mold, and strong odors, because bed bugs are a real risk in shared housing. Electrical items such as space heaters, hot plates, extension cords, and lamps must be in safe working condition, and Sellers should not list items that University housing rules ban in residence halls, such as certain cooking appliances, candles, or halogen lamps, without a clear note that the item may not be allowed in a dorm. Used helmets, car seats, and similar safety gear may be listed only with a clear statement of their age and history, since hidden damage can cause injury. Opened cosmetics and personal care items may not be sold. Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit, but does not specify quantity restrictions on purchases from a Bundle. Therefore, the evidence does not establish whether a Buyer can purchase only three items or fewer from a Bundle. [5.2]

**Scores:** context 2/1, answer 3/3 · **Latency:** 6.45 s · input/output tokens 1072/83 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q3

Record `small_20_clause_subset__bge_base__overlapping_paragraph__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.5612

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.5437

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Rank 3** — `overlapping_paragraph-008`, clauses [4.1, 4.2], cosine 0.5360

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them.

**Answer:** The evidence does not establish whether the Bundle discount is fixed or if Buyers can negotiate it with Sellers. The policy mentions "Bundle" as a group of related items offered together but does not specify rules regarding discounts or negotiation for Bundles [4.3].

**Scores:** context 1/1, answer 3/3 · **Latency:** 4.40 s · input/output tokens 1089/52 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q4

Record `small_20_clause_subset__bge_base__overlapping_paragraph__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6452

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 2** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.6293

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Rank 3** — `overlapping_paragraph-001`, clauses [1.1, 1.2], cosine 0.6012

> MoveOn exists so that University of Illinois Urbana-Champaign students can buy, sell, give away, and reuse dorm and apartment items with one another. Every August, December, and May, thousands of students arrive or leave with furniture, small appliances, bedding, kitchenware, textbooks, and décor. Much of it is thrown away, while other students pay full retail price for the same things a few weeks later. This policy sets the rules that keep that exchange safe, fair, affordable, and trustworthy. Its goal is to make the marketplace useful to the whole campus community without letting it become a source of scams, harassment, unsafe meetups, or wasted time. This policy applies to everyone who uses MoveOn in any way: people who browse listings, post items, save items to a personal list, assemble or view featured bundles, or send messages to other users. It also applies to the student team that builds and maintains the platform, and to any volunteer moderators the team appoints. The rules cover activity on the platform itself and activity that the platform makes possible, including in-person exchanges arranged through MoveOn messaging. If a feature is added later, such as ratings, payments, or notifications, this policy applies to it automatically until a more specific rule is written.

**Answer:** MoveOn does not provide specific help or protection for a Buyer who does not show up or has a payment problem and can no longer be contacted. The policy focuses on prohibiting prohibited items and enforcing rules around listings, exchanges, and user behavior, but it does not outline specific mechanisms for resolving issues related to Buyers failing to appear or payment problems. [1.1]

**Scores:** context 1/1, answer 2/3 · **Latency:** 5.82 s · input/output tokens 1054/74 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Overlapping paragraph · Q5

Record `small_20_clause_subset__bge_base__overlapping_paragraph__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6248

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 2** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6216

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `overlapping_paragraph-012`, clauses [5.2, 5.3], cosine 0.5895

> Some items may be listed only under conditions that protect the buyer. Used mattresses and upholstered furniture must be disclosed as such and must be free of pests, mold, and strong odors, because bed bugs are a real risk in shared housing. Electrical items such as space heaters, hot plates, extension cords, and lamps must be in safe working condition, and Sellers should not list items that University housing rules ban in residence halls, such as certain cooking appliances, candles, or halogen lamps, without a clear note that the item may not be allowed in a dorm. Used helmets, car seats, and similar safety gear may be listed only with a clear statement of their age and history, since hidden damage can cause injury. Opened cosmetics and personal care items may not be sold. Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed.

**Answer:** The evidence does not explicitly address whether a seller can require a donation for a free item. However, it is clear that MoveOn has strict policies regarding the sale of items, including restrictions on selling access codes, pirated materials, and items with university property tags. The policy also emphasizes that sellers must not post the same item multiple times or repost items to keep them at the top of the page. Additionally, sellers must ensure that items they list are ones they own or have clear permission to sell. While the policy does not directly mention donations for free items, it does emphasize that sellers must not engage in practices that could be considered scams or violations, which could include requiring donations for free items. Therefore, based on the evidence, it is not explicitly allowed, and sellers should consult the team before posting such an item. [5.3]

**Scores:** context 1/1, answer 3/3 · **Latency:** 11.87 s · input/output tokens 972/170 · **Notes:** Key clause [6.3] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q1

Record `small_20_clause_subset__bge_base__hybrid_strategic__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `hybrid_strategic-018`, clauses [5.4], cosine 0.6365

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 2** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6351

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `hybrid_strategic-011`, clauses [4.1], cosine 0.6350

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so.

**Answer:** The provided evidence does not address return policies or procedures for items purchased on MoveOn. Therefore, it cannot be determined from the given information whether a return is possible or how the return process works.

**Scores:** context 1/1, answer 3/3 · **Latency:** 2.84 s · input/output tokens 625/40 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q2

Record `small_20_clause_subset__bge_base__hybrid_strategic__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `hybrid_strategic-005`, clauses [2.1], cosine 0.5803

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Rank 2** — `hybrid_strategic-014`, clauses [4.4], cosine 0.5697

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `hybrid_strategic-013`, clauses [4.3], cosine 0.5680

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit, but does not specify any restrictions on the number of items a Buyer can purchase from a Bundle. Therefore, the policy does not provide sufficient information to determine if a Buyer can purchase only three items or fewer from a Bundle.

**Scores:** context 2/1, answer 3/3 · **Latency:** 5.83 s · input/output tokens 644/89 · **Notes:** Key clause [6.4] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q3

Record `small_20_clause_subset__bge_base__hybrid_strategic__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `hybrid_strategic-011`, clauses [4.1], cosine 0.5611

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so.

**Rank 2** — `hybrid_strategic-013`, clauses [4.3], cosine 0.5540

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Rank 3** — `hybrid_strategic-005`, clauses [2.1], cosine 0.5526

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Answer:** The evidence does not establish whether the Bundle discount is fixed or if Buyers can negotiate it with Sellers. The policy evidence provided focuses on definitions and general listing requirements but does not address discount flexibility for Bundles [2.1].

**Scores:** context 1/1, answer 3/3 · **Latency:** 3.38 s · input/output tokens 699/46 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q4

Record `small_20_clause_subset__bge_base__hybrid_strategic__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6429

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6403

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Rank 3** — `hybrid_strategic-017`, clauses [5.3], cosine 0.6379

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed.

**Answer:** The evidence does not establish what help or protection MoveOn provides if a Buyer does not show up or has a payment problem and can no longer be contacted.

**Scores:** context 1/1, answer 3/3 · **Latency:** 2.41 s · input/output tokens 654/32 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-base-en-v1.5 · Hybrid strategic · Q5

Record `small_20_clause_subset__bge_base__hybrid_strategic__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6336

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6133

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Rank 3** — `hybrid_strategic-018`, clauses [5.4], cosine 0.6056

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** The evidence does not explicitly address whether a seller can require a donation for a free item. However, it is clear that sellers must adhere to rules regarding ownership and listing practices. Since the policy focuses on prohibiting the sale of items without proper ownership or permission, and does not mention donations or free items, it is not possible to determine from the provided evidence whether requiring a donation for a free item would be allowed.

**Scores:** context 1/1, answer 3/3 · **Latency:** 5.41 s · input/output tokens 569/83 · **Notes:** Key clause [6.3] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q1

Record `small_20_clause_subset__bge_large__fixed_length__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6825

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-012`, clauses [5.4], cosine 0.6759

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `fixed_length-008`, clauses [4.1, 4.2], cosine 0.6645

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters.

**Answer:** The provided policy evidence does not address return policies or procedures for items purchased on MoveOn. It focuses on listing requirements, prohibited items, and moderation practices. Therefore, the evidence does not establish whether returns are allowed or how they would work.

**Scores:** context 1/1, answer 3/3 · **Latency:** 3.74 s · input/output tokens 888/49 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q2

Record `small_20_clause_subset__bge_large__fixed_length__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6696

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6672

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 3** — `fixed_length-011`, clauses [5.2, 5.3], cosine 0.6324

> Electrical items such as space heaters, hot plates, extension cords, and lamps must be in safe working condition, and Sellers should not list items that University housing rules ban in residence halls, such as certain cooking appliances, candles, or halogen lamps, without a clear note that the item may not be allowed in a dorm. Used helmets, car seats, and similar safety gear may be listed only with a clear statement of their age and history, since hidden damage can cause injury. Opened cosmetics and personal care items may not be sold. Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit, and mentions that a "Featured Bundle" is a Bundle the team highlights on the browse page. Since the policy does not restrict the number of items a Buyer can purchase from a Bundle, it is implied that Buyers can purchase all items in a Bundle, but it does not explicitly confirm if purchasing only three items or fewer is allowed. [5.3]

**Scores:** context 2/1, answer 3/3 · **Latency:** 8.41 s · input/output tokens 993/116 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q3

Record `small_20_clause_subset__bge_large__fixed_length__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6333

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.5956

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 3** — `fixed_length-012`, clauses [5.4], cosine 0.5640

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** The policy does not specify whether Bundle discounts are fixed or if Buyers can negotiate them with Sellers. The evidence provided only mentions that a "Bundle" is a group of related items offered together, but does not address discount flexibility or negotiation practices [2.2].

**Scores:** context 1/1, answer 3/3 · **Latency:** 3.96 s · input/output tokens 863/53 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q4

Record `small_20_clause_subset__bge_large__fixed_length__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6860

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-012`, clauses [5.4], cosine 0.6656

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 3** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6532

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Answer:** MoveOn does not provide specific help or protection for a Buyer who does not show up or has a payment problem and can no longer be contacted. The policy focuses on seller responsibilities, such as marking a Listing as closed within twenty-four hours if the item is sold, given away, or no longer available. It does not address buyer-related issues like non-attendance or payment problems. [4.2]

**Scores:** context 1/1, answer 2/3 · **Latency:** 5.87 s · input/output tokens 874/82 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Fixed length · Q5

Record `small_20_clause_subset__bge_large__fixed_length__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `fixed_length-009`, clauses [4.2, 4.3, 4.4], cosine 0.6577

> Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `fixed_length-003`, clauses [2.1, 2.2], cosine 0.6472

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban.

**Rank 3** — `fixed_length-012`, clauses [5.4], cosine 0.6329

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** No, a seller cannot require a donation for a free item. According to the policy, a "Giveaway" is a Listing offered for free, and there is no mention of requiring donations for free items. The policy focuses on prohibiting the sale of items that do not belong to the seller or with whom they do not have clear permission to sell, but it does not address donations for free items. [2.2]

**Scores:** context 2/1, answer 2/3 · **Latency:** 6.11 s · input/output tokens 858/86 · **Notes:** Key clause [6.3] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q1

Record `small_20_clause_subset__bge_large__overlapping_paragraph__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6770

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-008`, clauses [4.1, 4.2], cosine 0.6658

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so. A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them.

**Rank 3** — `overlapping_paragraph-005`, clauses [2.2, 2.3], cosine 0.6399

> "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs. "Move-In Season" means roughly the two weeks before and after the start of each semester, and "Move-Out Season" means the final two weeks of the spring and fall semesters. During these periods the platform expects much higher volume and applies the special rules in Section 14. "Personal Information" means any information that identifies or could reasonably identify a person, including name, email address, phone number, residence hall or apartment address, class schedule, and photographs showing a person's face. "Prohibited Item" and "Restricted Item" are defined in Section 5. Headings are for convenience only and do not change the meaning of any clause.

**Answer:** The policy provided does not address return policies or procedures for items purchased on the platform. It focuses on listing requirements, item ownership, and enforcement actions related to violations. There is no mention of return processes, refund policies, or mechanisms for resolving disputes after a purchase. Therefore, the evidence does not establish the requested fact.

**Scores:** context 1/1, answer 3/3 · **Latency:** 5.23 s · input/output tokens 1064/65 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q2

Record `small_20_clause_subset__bge_large__overlapping_paragraph__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6784

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.6621

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Rank 3** — `overlapping_paragraph-012`, clauses [5.2, 5.3], cosine 0.6497

> Some items may be listed only under conditions that protect the buyer. Used mattresses and upholstered furniture must be disclosed as such and must be free of pests, mold, and strong odors, because bed bugs are a real risk in shared housing. Electrical items such as space heaters, hot plates, extension cords, and lamps must be in safe working condition, and Sellers should not list items that University housing rules ban in residence halls, such as certain cooking appliances, candles, or halogen lamps, without a clear note that the item may not be allowed in a dorm. Used helmets, car seats, and similar safety gear may be listed only with a clear statement of their age and history, since hidden damage can cause injury. Opened cosmetics and personal care items may not be sold. Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit, and mentions that a "Featured Bundle" is a Bundle the team highlights on the browse page. Since the policy does not restrict the number of items a Buyer can purchase from a Bundle, it is implied that Buyers can purchase all items in a Bundle, but it does not specify a limit of three items or fewer. [5.2]

**Scores:** context 2/1, answer 3/3 · **Latency:** 8.42 s · input/output tokens 1072/113 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q3

Record `small_20_clause_subset__bge_large__overlapping_paragraph__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6235

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.5971

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Rank 3** — `overlapping_paragraph-009`, clauses [4.2, 4.3], cosine 0.5824

> A complete Listing includes a clear title, at least one original photo of the actual item, a price or a clear "free" marking, a category, a condition, and a general pickup area such as a residence hall or neighborhood. It should also state the date range during which the item is available, because move-out deadlines make timing important. The title should name the item plainly, for example "IKEA desk, 47 inches, white", and not use all capital letters, excessive punctuation, or unrelated keywords meant to trick the search filters. Listings with missing or misleading information may be hidden from search results until the Seller fixes them. A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The policy does not specify whether Bundle discounts are fixed or if Buyers can negotiate them with Sellers. The evidence provides definitions for "Bundle" but does not mention discount flexibility or negotiation practices [4.2, 4.3].

**Scores:** context 1/1, answer 3/3 · **Latency:** 4.00 s · input/output tokens 1051/47 · **Notes:** Key clause [6.4] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q4

Record `small_20_clause_subset__bge_large__overlapping_paragraph__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6554

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.6481

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Rank 3** — `overlapping_paragraph-013`, clauses [5.3, 5.4], cosine 0.6281

> Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed. When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Answer:** MoveOn does not provide specific help or protection for Buyers who do not show up or have payment problems and can no longer be contacted. The policy focuses on seller responsibilities, such as marking a Listing as closed within twenty-four hours if the item is sold, given away, or no longer available. It does not address mechanisms for resolving issues between Buyers and Sellers after a transaction has been initiated. [4.3]

**Scores:** context 1/1, answer 2/3 · **Latency:** 6.47 s · input/output tokens 1027/84 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Overlapping paragraph · Q5

Record `small_20_clause_subset__bge_large__overlapping_paragraph__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `overlapping_paragraph-010`, clauses [4.3, 4.4], cosine 0.6685

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators. Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `overlapping_paragraph-012`, clauses [5.2, 5.3], cosine 0.6451

> Some items may be listed only under conditions that protect the buyer. Used mattresses and upholstered furniture must be disclosed as such and must be free of pests, mold, and strong odors, because bed bugs are a real risk in shared housing. Electrical items such as space heaters, hot plates, extension cords, and lamps must be in safe working condition, and Sellers should not list items that University housing rules ban in residence halls, such as certain cooking appliances, candles, or halogen lamps, without a clear note that the item may not be allowed in a dorm. Used helmets, car seats, and similar safety gear may be listed only with a clear statement of their age and history, since hidden damage can cause injury. Opened cosmetics and personal care items may not be sold. Textbooks, course materials, and lab kits may be sold, but Sellers may not sell access codes that have already been used, copies that violate a publisher's license, or pirated PDFs. Event tickets may be listed only at or below face value and only if the venue permits resale. Gift cards, digital downloads, and software licenses are not accepted on MoveOn because they are hard to verify and are a common vehicle for scams. Items that involve a University property tag, a library marking, or a lab label are presumed to belong to the University and may not be listed.

**Rank 3** — `overlapping_paragraph-004`, clauses [2.1, 2.2], cosine 0.6403

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature. "Moderator" means a team member or approved volunteer who reviews reports and enforces this policy. A "Report" is a complaint a User submits about a Listing, Message, or User. A "Violation" is any act or omission that breaks this policy, and an "Enforcement Action" is the response to a Violation, such as a warning, removal of a Listing, suspension, or permanent ban. "Exchange" means the handoff of an item from Seller to Buyer, whether in person or by another agreed method. "Safe Exchange Location" means a public, well-lit, camera-monitored campus or campus-adjacent place that the team recommends for handoffs.

**Answer:** No, a seller cannot require a donation for a free item. A "Giveaway" is defined as a Listing offered for free, and there are no provisions in the policy that allow a seller to require a donation for a free item. The policy focuses on ensuring that items are listed accurately and in compliance with University rules, but it does not mention donations as a condition for free items [2.1].

**Scores:** context 2/1, answer 2/3 · **Latency:** 6.43 s · input/output tokens 1070/83 · **Notes:** Key clause [6.3] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q1

Record `small_20_clause_subset__bge_large__hybrid_strategic__return_item`

**Query:** If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work?

**Rank 1** — `hybrid_strategic-018`, clauses [5.4], cosine 0.6759

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 2** — `hybrid_strategic-011`, clauses [4.1], cosine 0.6576

> Every Listing must describe the item truthfully. A Seller must state the item's category, its condition, its approximate age, and any defects that a reasonable buyer would want to know about, such as a wobbly chair leg, a stained mattress, a missing remote, or a frayed power cord. Condition labels should be used consistently: "new" means unused and in original packaging, "like new" means used lightly with no visible wear, "good" means normal wear that does not affect function, and "fair" means visible wear or a minor problem that is disclosed. Sellers may not hide defects, edit photos to conceal damage, or describe an item as working when they have not tested it. If the Seller has not tested an electrical item, the Listing must say so.

**Rank 3** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6543

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The policy evidence provided does not address return policies or procedures for items purchased on MoveOn. Therefore, it cannot be determined from the given information whether a return is possible or how the return process works.

**Scores:** context 1/1, answer 3/3 · **Latency:** 3.02 s · input/output tokens 639/41 · **Notes:** Key clause [8.5], [13.1] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q2

Record `small_20_clause_subset__bge_large__hybrid_strategic__bundle_three_items`

**Query:** Can a Buyer purchase only three items or fewer from a Bundle?

**Rank 1** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6600

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Rank 2** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6542

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Rank 3** — `hybrid_strategic-016`, clauses [5.2], cosine 0.6460

> Some items may be listed only under conditions that protect the buyer. Used mattresses and upholstered furniture must be disclosed as such and must be free of pests, mold, and strong odors, because bed bugs are a real risk in shared housing. Electrical items such as space heaters, hot plates, extension cords, and lamps must be in safe working condition, and Sellers should not list items that University housing rules ban in residence halls, such as certain cooking appliances, candles, or halogen lamps, without a clear note that the item may not be allowed in a dorm. Used helmets, car seats, and similar safety gear may be listed only with a clear statement of their age and history, since hidden damage can cause injury. Opened cosmetics and personal care items may not be sold.

**Answer:** The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it defines a "Bundle" as a group of related items offered together, such as a dorm starter kit. Since the policy does not specify a limit on the number of items a Buyer can purchase from a Bundle, it is not possible to determine from the provided evidence whether a Buyer can purchase only three items or fewer. [5.2]

**Scores:** context 2/1, answer 3/3 · **Latency:** 6.09 s · input/output tokens 694/92 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q3

Record `small_20_clause_subset__bge_large__hybrid_strategic__bundle_discount`

**Query:** Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller?

**Rank 1** — `hybrid_strategic-019`, clauses [6.1], cosine 0.6340

> Sellers set their own prices, but MoveOn is a student marketplace and its purpose is affordability. Sellers should price used items well below retail and should consider the item's age, condition, and the short window in which students need it. The platform does not allow price gouging during Move-In Season, such as charging far above a reasonable resale value for a fan or a mini fridge because demand is high. Moderators may remove a Listing whose price is plainly abusive, and Sellers who are asked to justify a price should explain it in good faith. A price must be shown in US dollars and must be the full price, with no hidden fees added at pickup.

**Rank 2** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6204

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Rank 3** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6039

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Answer:** The evidence does not establish whether the Bundle discount is fixed or if Buyers can negotiate it with Sellers. The policy mentions "Bundle" as a group of related items offered together but does not specify rules regarding discounts or negotiation for Bundles [2.1].

**Scores:** context 3/2, answer 3/3 · **Latency:** 3.63 s · input/output tokens 673/52 · **Notes:** Key clause [6.4] is outside the 20-clause subset; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q4

Record `small_20_clause_subset__bge_large__hybrid_strategic__buyer_no_show_payment`

**Query:** What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted?

**Rank 1** — `hybrid_strategic-018`, clauses [5.4], cosine 0.6656

> When a Moderator is unsure whether an item is allowed, the Listing is hidden and the Seller is asked for more information to clarify the item's status. A Seller who wonders whether an item is allowed should ask the team before posting it on MoveOn. Repeated attempts to list a Prohibited Item, even with small changes in wording, will be treated as a deliberate Violation. Users who see a Prohibited Item should report it and should not contact the Seller to investigate on their own.

**Rank 2** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6518

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 3** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6518

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Answer:** The evidence does not establish what help or protection MoveOn provides if a Buyer does not show up or has a payment problem and can no longer be contacted.

**Scores:** context 1/1, answer 3/3 · **Latency:** 2.35 s · input/output tokens 635/32 · **Notes:** Key clause [8.4], [8.5] is outside the 20-clause subset; no clause citation; answer correctly says evidence is insufficient or stays within it

---

### BAAI/bge-large-en-v1.5 · Hybrid strategic · Q5

Record `small_20_clause_subset__bge_large__hybrid_strategic__giveaway_donation`

**Query:** Can a seller require a donation for a free item?

**Rank 1** — `hybrid_strategic-014`, clauses [4.4], cosine 0.6548

> Sellers may list only items they own or have clear permission to sell. A person may not list an item that belongs to a roommate, a landlord, a residence hall, a student organization, or the University. Items that were provided with a lease or a housing contract, such as furnished apartment furniture, may not be sold unless the landlord has agreed in writing. Anyone who sells an item they do not own may be held responsible by the true owner and by the University, and MoveOn will cooperate with legitimate requests from campus officials.

**Rank 2** — `hybrid_strategic-005`, clauses [2.1], cosine 0.6514

> In this policy, "MoveOn" means the website, its database, and the student team that runs it. A "User" is any person with an account. A "Seller" is a User who posts a listing, and a "Buyer" is a User who asks to acquire a listed item. A "Listing" is a post describing one item or one set of items, including its photos, price, condition, and pickup details. A "Giveaway" is a Listing offered for free. A "Bundle" is a group of related items offered together, such as a dorm starter kit, and a "Featured Bundle" is a Bundle the team highlights on the browse page. A "Saved Item" is a Listing a User has bookmarked for later. A "Message" is any communication sent through MoveOn's messaging feature.

**Rank 3** — `hybrid_strategic-013`, clauses [4.3], cosine 0.6388

> A Listing should describe one item or one clearly defined set of items. Sellers may not post the same item more than once, post it in several categories, or repost it repeatedly to keep it at the top of the page. If an item remains unsold, the Seller may edit the Listing, lower the price, or renew it once a week. Once an item is sold, given away, or no longer available, the Seller must mark the Listing as closed within twenty-four hours so that Buyers do not waste time. A Seller who regularly leaves sold items active may have their Listings hidden by Moderators.

**Answer:** The policy does not explicitly address whether a seller can require a donation for a free item. However, it states that a "Giveaway" is a Listing offered for free [2.1]. Since a giveaway is defined as a free item, requiring a donation would likely contradict the nature of a giveaway. Additionally, the policy emphasizes that sellers must not list items they do not own [4.4], and any listing that does not comply with these rules may be removed or restricted. Therefore, while the policy does not directly answer this question, it implies that requiring a donation for a free item would likely be against the policy's guidelines.

**Scores:** context 2/1, answer 3/3 · **Latency:** 8.32 s · input/output tokens 642/129 · **Notes:** Key clause [6.3] is outside the 20-clause subset; **Part 3 failure F4**

---
