# A8 Part 4: Cost analysis (generated)

Source: `A8_results/Part2/20261031` (90 reviewed records, Tesla T4). Measured values come from saved runs; rows marked *projected* or *estimate* are derived from the fits below.

## Where query time goes

| Stage | Mean time |
|---|---:|
| Query embedding (fresh encode, median) | 14.8 ms |
| Similarity search (NumPy cosine, top-3) | 0.30 ms |
| LLM generation (Qwen3-4B FP16) | 6.68 s |
| Total per query | 6.69 s |
| Generation share of total | 99.8% |

Generation seconds = -1.17 + 2.11 ms x input tokens + 63.5 ms x output tokens (R^2 = 0.998). One output token costs about 30x an input token.

Prompt tokens = 230 + 1.26 x retrieved words (R^2 = 0.987).

## 4.1a Embedding size

| Model | Dim | Params (M) | Bytes/vector | Index, 66 hybrid chunks (KiB) | Projected GiB per 1M chunks | Query embed median (ms) | Mean context relevance | Mean groundedness |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| BAAI/bge-small-en-v1.5 | 384 | 33 | 1536 | 99 | 1.43 | 12.6 | 2.17 | 2.70 |
| BAAI/bge-base-en-v1.5 | 768 | 109 | 3072 | 198 | 2.86 | 12.4 | 2.10 | 2.87 |
| BAAI/bge-large-en-v1.5 | 1024 | 335 | 4096 | 264 | 3.81 | 21.0 | 2.27 | 2.87 |

## 4.1b Chunk size (67 clauses, top-k = 3)

| Strategy | Chunks | Mean words/chunk | Retrieved words (top-3) | Mean input tokens | Mean output tokens | Mean generation (s) | Mean groundedness |
|---|---:|---:|---:|---:|---:|---:|---:|
| Fixed length | 46 | 145 | 529 | 888 | 117 | 8.10 | 2.47 |
| Overlapping paragraph | 48 | 183 | 612 | 981 | 118 | 8.43 | 2.67 |
| Hybrid strategic | 66 | 101 | 310 | 610 | 116 | 7.48 | 2.80 |

## 4.1c Top-k (projected input tokens)

| Strategy | k = 1 | k = 3 | k = 5 | k = 10 |
|---|---:|---:|---:|---:|
| Fixed length | 451 | 894 | 1337 | 2445 |
| Overlapping paragraph | 486 | 999 | 1511 | 2793 |
| Hybrid strategic | 359 | 619 | 878 | 1527 |

Placing the whole 6,684-word policy in the prompt instead (pure prompting) is estimated at 8,628 input tokens per query.

## 4.3 Load estimate for 10K users/day

Assumptions: users_per_day = 10000; queries_per_user_per_day = 3; peak_hour_share_of_daily_traffic = 0.15; answer_cache_hit_rate = 0.3; continuous_batching_throughput_gain = 8; redundancy_spare_gpus = 1; gpu_hourly_price_usd = 0.35.

| Quantity | Estimate |
|---|---:|
| Queries per day | 30,000 |
| Average / peak queries per second | 0.35 / 1.25 |
| Input / output LLM tokens per day | 18.3M / 3.5M |
| GPUs at peak, batch-1 as in our experiment | 10 (about $84/day) |
| GPUs at peak, with answer cache + continuous batching (+1 spare) | 2 (about $17/day) |
| Peak generator GPU memory (measured) | 10.5 GB |
