# A8 Part 3: Failure Analysis and Improvement

## Method

Four failure records were selected from the completed Part 2 run. Each was checked against its saved `included_hits`, clause IDs, answer, and citation audit in `experiment_results.jsonl`; reviewed answer scores and total latency come from `evaluation_table.csv`. The improvement compares two saved configurations with the same query, source, embedding model, and generator; chunk size, boundaries, and retrieved context differ.

## Failure cases and root causes

| Failure record | Observed failure | Retrieved evidence | Root cause |
|---|---|---|---|
| `large_67_clauses__bge_small__fixed_length__bundle_three_items` | Contradictory Bundle answer | [14.2], [14.3], [14.4], [4.2], [4.3], [4.4], [6.3], [6.4] | Generation consistency. The answer opens with a categorical 'No' but later says the policy does not establish a three-item limit. Retrieved [6.3] and [6.4] cover Bundle conditions, but do not state that numeric restriction. |
| `large_67_clauses__bge_small__hybrid_strategic__bundle_discount` | Unsupported negotiation claim | [6.2], [6.4], [8.5] | Generation inference (retrieval contributes). The answer says a Buyer may negotiate the discount. Retrieved [6.2], [6.4], and [8.5] do not establish a negotiation right; the price cap and agreed-price rule do not entail one. |
| `large_67_clauses__bge_small__hybrid_strategic__return_item` | Incorrect clause citation | [13.1], [6.2], [8.5] | Generation / citation control. The answer attributes the no-penalty statement to [8.2], which was not retrieved. The included context contains [6.2], [8.5], and [13.1]. |
| `small_20_clause_subset__bge_large__hybrid_strategic__giveaway_donation` | Overclaim with missing policy evidence | [2.1], [4.3], [4.4] | Corpus boundary and generation. Clause [6.3], the direct Giveaway rule, is outside the 20-clause subset and absent from top-k. The answer nevertheless infers that a donation would likely violate the policy. |

### Step 3.2 factor assessment by failure

| Failure | Chunking | Embedding model | Query formulation | Supported primary cause |
|---|---|---|---|---|
| Bundle item count | Relevant [6.4] was retrieved, so no demonstrated chunk gap. | No model-specific cause shown. | The question states the quantity clearly. | Generation contradiction. |
| Bundle discount | [6.4] was retrieved; chunk boundaries may affect the answer, but the record does not isolate them. | No model-specific cause shown. | The question directly asks about negotiation. | Unsupported generation inference. |
| Return citation | The cited [8.2] was absent while relevant [6.2] was present. | No model-specific cause shown. | The return question was specific enough to retrieve related clauses. | Generation citation error. |
| Giveaway donation | [6.3] was excluded from the 20-clause corpus before chunking. | An embedding model cannot retrieve an excluded clause. | The question directly names a donation and a free item. | Corpus coverage gap, then generation overclaim. |

The first two failures have relevant clauses in the retrieved context, so their primary cause is unsupported generation rather than missing corpus coverage. In the small-corpus case, [6.3] is excluded before retrieval, making an evidence-based answer impossible; the generator should abstain instead of infer a policy rule. The citation failure is directly testable because its cited [8.2] is absent while [6.2], [8.5], and [13.1] are included.

## Step 3.3: Implemented improvement — adjust chunk size

The selected assignment option is **adjust chunk size**. For the Bundle discount question, switch from clause-sized `hybrid_strategic` chunks to the existing `fixed_length` index with a 180-word soft target. These are two completed Part 2 runs with the same query, 67-clause corpus, BGE-small embedding model, top-k=3, Qwen generation model, prompt, and decoding settings. The chunk boundaries and retrieved passages change with the size setting, so this paired observation does not isolate size alone.

### Before vs. after (actual saved model outputs)

| Measure | Before: clause-sized chunks | After: 180-word target chunks |
|---|---|---|
| Retrieved chunks | hybrid_strategic-020, hybrid_strategic-022, hybrid_strategic-031 | fixed_length-013, fixed_length-034, fixed_length-020 |
| Retrieved chunk word counts | 113, 121, 90 | 229, 176, 161 |
| Answer | The Bundle discount is not fixed, and a Buyer may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. This implies that the Bundle price is determined by the Seller and may be subject to negotiation, as there is no explicit rule that the Bundle discount is fixed or non-negotiable. However, the platform does not provide specific guidance on negotiation practices for Bundle discounts. [6.4] | The evidence does not mention a "Bundle discount" or specify whether such a discount is fixed or negotiable. Therefore, it cannot be determined from the provided policy evidence whether the Bundle discount is fixed or can be negotiated. |
| Reviewed answer relevance / groundedness | 2/3; 1/3 | 3/3; 3/3 |
| Total query latency | 7.344s | 3.449s |

The after answer says the supplied policy does not establish whether a Bundle discount is fixed or negotiable. This removes the unsupported negotiation claim seen before; reviewed groundedness rises from 1/3 to 3/3 for this paired question. The fixed-length top-k does not include [6.4], so this is a case-specific improvement, not evidence that larger chunks always perform better. The complete paired data is in `chunk_size_comparison.json`.

The selected configuration for this question is saved in `selected_configuration.json`. This applies the observed choice to the handoff configuration; it does not claim a new model run or improvement for other questions. The citation guard is a separate output check; it cannot detect unsupported claims that cite clauses present in context.

The additional citation guard catches the separate return-item error: the Part 2 answer cites missing [8.2], while the retrieved context contains [6.2], [8.5], and [13.1]. The baseline answer/guarded abstention and audit are retained in `citation_guard_results.jsonl`.

## Reproduction

From the assignment folder, `python src/part3_analysis.py` verifies the saved failures and regenerates the analysis, paired comparison, and selected configuration without loading models. The final Part 3 notebook code cell runs the same verifier. Running all notebook cells reruns Parts 1 and 2.
