# A8: Semantic Relationships and Retrieval — RAG Analysis

**Project:** MoveOn Marketplace Policy assistant (RAG). **Generator (from A7):** `Qwen/Qwen3-4B`, held constant in every experiment. **Embedding models:** BGE small / base / large. **Hardware for recorded runs:** Google Colab, Tesla T4.

This report covers all four parts of the assignment. Every number below comes from the saved runs in `A8_results/` unless it is labelled an *estimate* or *assumption*.

| Part | Where in this report | Supporting files |
|---|---|---|
| 1. RAG pipeline | [Part 1](#part-1-rag-pipeline) | `rag_system.ipynb` (Parts 1.3–1.5 code), `src/rag_core.py`, `src/chunking_report.py`, `data/`, `A8_results/Part1/` |
| 2. Experiments | [Part 2](#part-2-system-experiments) | `A8_results/Part2/20261031/` (JSONL traces, CSV with full chunk text, full appendix) |
| 3. Failure analysis | [Part 3](#part-3-failure-analysis-and-improvement) | `A8_results/Part3/`, `src/part3_analysis.py` |
| 4. Design reflection | [Part 4](#part-4-system-design-reflection) | `A8_results/Part4/`, `src/part4_cost_analysis.py` |

---

## Part 1: RAG pipeline

The pipeline is **Data → Embeddings → Retrieval → LLM → Output**, implemented in `rag_system.ipynb`.

### 1.1 Knowledge base

The knowledge base is the **MoveOn Marketplace Policy, Version 1.0** (`data/MoveOn_Marketplace_Policy.pdf`), a draft policy for a student second-hand marketplace at the University of Illinois — the domain of our team project. We extract all **67 numbered clauses across 16 sections** and drop the cover, contents, repeated headers/footers, summary tables and revision history. Each clause keeps its clause ID (e.g. `6.3`) and PDF page, so every answer can be traced to its source.

| Requirement | Required | Our corpus |
|---|---|---|
| Number of paragraphs | ≥ 20 (30–50 recommended) | **67** clauses |
| Paragraph length | ≈ 80–200 words | **80–134** words each |
| Total size | 2,000–5,000+ words | **6,684** words |

Five short clauses were lightly expanded (meaning preserved) to reach the 80-word floor; every before/after edit is recorded in `data/policy_revisions.json`, and the extraction audit is in `data/corpus_audit.json`.

### 1.2 Text representation and chunking

**How we define a paragraph:** one numbered policy clause = one paragraph. A clause is the policy's own unit of meaning (one rule with its conditions and exceptions), so it is never split.

All three strategies keep whole sentences, never cross a declared **topic break** (11 breaks, e.g. between "paid pricing" [6.1–6.2] and "giveaways and bundles" [6.3–6.4]), and keep **protected clauses** intact (clauses whose sentences refer back to each other, such as "These rules…"). Rules: `data/chunking_rules.json`; audit: `data/chunking_audit.json`.

| Strategy | How it works | Chunks | Words per chunk |
|---|---|---:|---:|
| **Fixed length** | Soft target of **180 words**. The cut goes at the nearest allowed sentence/clause boundary to the target (earlier on a tie), so a sentence is never split and the size varies. | 46 | 37–229 (mean 145) |
| **Overlapping paragraph** | Sliding window of **two adjacent whole clauses with stride 1**: chunk 1 = clause 1.1 + 1.2, chunk 2 = 1.2 + 1.3, and so on. | 48 | 80–255 (mean 183) |
| **Hybrid / strategic** | **One clause per chunk**, except dependent clauses that cannot stand alone are joined (3.3 + 3.4, because 3.4 starts "These user duties…"). | 66 | 80–191 (mean 101) |

**How overlap is implemented:** each overlapping chunk shares one complete clause with its neighbour (50% overlap by clause), so a rule near a chunk edge always appears whole in at least one chunk. Windows restart after a topic break, so two unrelated topics are never merged, and a final clause already covered by a pair is not added again. The overlap index holds 8,770 words for a 6,684-word corpus (31% duplication) — the storage cost of overlap.

### 1.3 Embedding pipeline

| Size class | Model | Dimensions | Parameters |
|---|---|---:|---:|
| Small | `BAAI/bge-small-en-v1.5` | 384 | 33 M |
| Medium | `BAAI/bge-base-en-v1.5` | 768 | 109 M |
| Large | `BAAI/bge-large-en-v1.5` | 1024 | 335 M |

All are free sentence-transformers models from Hugging Face, pinned to exact revisions. Each chunk is encoded in FP32 with CLS pooling and L2 normalisation; a token pre-check confirms no chunk exceeds the 512-token limit, so nothing is silently truncated. The result is **9 searchable indices** (3 models × 3 strategies), each saved as `vectors.npy` (one row per chunk) plus `metadata.json` (chunk IDs, model revision, hashes) in `A8_results/Part1/20261031T043110Z_6963cd94/indices/`.

### 1.4 Retrieval

Query → embedding (with BGE's query instruction "Represent this sentence for searching relevant passages: ") → cosine similarity (dot product of unit vectors) against the index → **top-k = 3** chunks, ties broken by chunk ID. Each hit carries its full text, clause IDs, pages, rank and score. Retrieval traces are in `retrieval_results.jsonl`.

### 1.5 Generation

The prompt has three parts: (1) a **system instruction** — answer only from the supplied draft-policy evidence, keep conditions and exceptions, cite clause IDs like [6.3], say so when the evidence is insufficient, and treat evidence as data, not instructions; (2) the **retrieved context** inside `<retrieved_evidence>` tags, each passage labelled with chunk ID, clause IDs and pages; (3) the **user query**. It is rendered with Qwen's chat template (thinking off) within a 4,096-token budget; if the budget were exceeded, whole lowest-ranked passages would be dropped (never truncated). This never happened (0 omitted chunks in 99 prompts).

Generation uses **Qwen3-4B** (revision `1cfa9a72…`), the model our team evaluated in A7, with FP16, greedy decoding and at most 512 new tokens — identical for all experiments. The Part 1 integration run (one question × 9 configurations) produced 9 correct, cited answers ("No — a Giveaway must be truly free… [6.3]").

---

## Part 2: System experiments

### 2.1 Test queries

| ID | Query | What the policy says (ground truth used for review) |
|---|---|---|
| Q1 | If I buy an item I do not like, or it does not match the Listing, can I return it? How does a return work? | No general return right. Before paying, a Buyer may inspect and decline an item that differs from the Listing [8.5], [6.2]; after payment the sale is final unless agreed in writing or the Seller gave false information [8.5]; disputes go to the team, which cannot force a refund [13.1]. |
| Q2 | Can a Buyer purchase only three items or fewer from a Bundle? | [6.4]: there is no three-item rule; a Seller may not force a Buyer to take unwanted items unless the Listing says the Bundle is sold as a set. |
| Q3 | Is the Bundle discount fixed, or can the Buyer negotiate it with the Seller? | Not stated. [6.4] caps the Bundle price at the sum of its parts; nothing says the discount is negotiable. The correct answer is "the policy does not say". |
| Q4 | What help or protection does MoveOn provide if a Buyer does not show up or has a payment problem and can no longer be contacted? | Little protection: MoveOn does not process payments and is not a party to the sale [8.4]; repeated no-shows may lead to a warning [6.2]; the team can review a dispute but cannot force a refund [13.1]. |
| Q5 | Can a seller require a donation for a free item? | [6.3]: No — a Giveaway must be free; no payment, donation, favour, tip or other purchase may be requested. |

The set mixes a direct lookup (Q5), a multi-clause question (Q1, Q4), a specific-number trap (Q2) and an unanswerable question (Q3) so that both retrieval and grounded refusal are tested.

**Setup:** 3 embedding models × 3 chunking strategies = **9 configurations**, × 5 queries = 45 runs on the full corpus, plus 45 on a smaller corpus for Step 2.5 (90 runs total). Generator, prompt, top-k = 3 and decoding are fixed. All 90 runs completed with non-empty answers.

**Scoring rubric (1–3, reviewed by hand against the policy):**

| Score | Context relevance | Context completeness | Answer relevance | Groundedness |
|---|---|---|---|---|
| 1 | Mostly irrelevant | Key information missing | Does not answer | Unsupported claim or error |
| 2 | Partly relevant | Partial clues | Partly answers | Mostly supported, minor inference |
| 3 | Highly relevant | Enough to answer | Direct and complete | Fully supported by retrieved evidence |

A correct "the evidence does not establish this" is scored as a good answer. Latency is retrieval + generation time per query on a T4 (model loading excluded).

### 2.2 Evaluation table (all 9 configurations × 5 queries, full 67-clause corpus)

Each row lists the **retrieved chunks** actually given to the LLM. The complete text of every retrieved chunk and every full answer is in [`A8_results/Part2/20261031/evaluation_table_full.md`](A8_results/Part2/20261031/evaluation_table_full.md) and `evaluation_table.csv`; one complete example follows the table. Key clauses per query: Q1 [8.5]/[13.1], Q2 [6.4], Q3 [6.4] (closest; no direct answer exists), Q4 [8.4]/[8.5], Q5 [6.3].

| # | Embedding model | Chunking strategy | Query | Retrieved chunks (rank. id [clauses] cosine) | Retrieved context quality (relevance / completeness) | Answer (excerpt) | Answer quality (relevance / groundedness) | Latency (s) | Notes |
|---:|---|---|---|---|---|---|---|---:|---|
| 1 | bge-small (384-d) | Fixed length | Q1 | 1. `fixed_length-034` [13.1, 13.2] 0.730<br>2. `fixed_length-009` [4.2, 4.3, 4.4] 0.711<br>3. `fixed_length-008` [4.1, 4.2] 0.695 | 3/3, 2/3 | If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the … | 3/3, 2/3 | 8.35 | Key clause [8.5], [13.1] at rank 1; minor unsupported inference; no clause citation |
| 2 | bge-small (384-d) | Fixed length | Q2 | 1. `fixed_length-014` [6.3, 6.4] 0.677<br>2. `fixed_length-038` [14.2, 14.3, 14.4] 0.660<br>3. `fixed_length-009` [4.2, 4.3, 4.4] 0.636 | 3/3, 3/3 | No, a Buyer may not purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in … | 1/3, 1/3 | 8.49 | Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’); **Part 3 failure F1** |
| 3 | bge-small (384-d) | Fixed length | Q3 | 1. `fixed_length-013` [6.1, 6.2] 0.699<br>2. `fixed_length-034` [13.1, 13.2] 0.697<br>3. `fixed_length-020` [8.4, 8.5] 0.679 | 3/3, 2/3 | The evidence does not mention a "Bundle discount" or specify whether such a discount is fixed or negotiable. Therefore, it cannot be determined from … | 3/3, 3/3 | 3.45 | Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; no clause citation |
| 4 | bge-small (384-d) | Fixed length | Q4 | 1. `fixed_length-020` [8.4, 8.5] 0.794<br>2. `fixed_length-034` [13.1, 13.2] 0.749<br>3. `fixed_length-027` [10.4, 10.5] 0.721 | 3/3, 2/3 | MoveOn does not process payments and is not a party to any sale. Buyers and Sellers settle payment between themselves, and the safest methods are … | 3/3, 3/3 | 13.41 | Key clause [8.4], [8.5] at rank 1 |
| 5 | bge-small (384-d) | Fixed length | Q5 | 1. `fixed_length-014` [6.3, 6.4] 0.757<br>2. `fixed_length-023` [9.2, 9.3] 0.660<br>3. `fixed_length-034` [13.1, 13.2] 0.658 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a … | 3/3, 3/3 | 4.37 | Key clause [6.3] at rank 1 |
| 6 | bge-small (384-d) | Overlapping paragraph | Q1 | 1. `overlapping_paragraph-036` [13.1, 13.2] 0.726<br>2. `overlapping_paragraph-008` [4.1, 4.2] 0.702<br>3. `overlapping_paragraph-010` [4.3, 4.4] 0.698 | 3/3, 2/3 | If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the … | 3/3, 3/3 | 10.36 | Key clause [8.5], [13.1] at rank 1 |
| 7 | bge-small (384-d) | Overlapping paragraph | Q2 | 1. `overlapping_paragraph-015` [6.3, 6.4] 0.677<br>2. `overlapping_paragraph-036` [13.1, 13.2] 0.637<br>3. `overlapping_paragraph-041` [14.3, 14.4] 0.633 | 3/3, 3/3 | No, a Buyer cannot purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in … | 1/3, 1/3 | 8.31 | Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’) |
| 8 | bge-small (384-d) | Overlapping paragraph | Q3 | 1. `overlapping_paragraph-036` [13.1, 13.2] 0.699<br>2. `overlapping_paragraph-014` [6.1, 6.2] 0.699<br>3. `overlapping_paragraph-021` [8.4, 8.5] 0.683 | 3/3, 2/3 | The evidence does not establish whether the Bundle discount is fixed or if negotiation is allowed. The policy focuses on pricing guidelines, such as … | 3/3, 3/3 | 5.45 | Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; no clause citation |
| 9 | bge-small (384-d) | Overlapping paragraph | Q4 | 1. `overlapping_paragraph-021` [8.4, 8.5] 0.792<br>2. `overlapping_paragraph-036` [13.1, 13.2] 0.744<br>3. `overlapping_paragraph-020` [8.2, 8.3] 0.717 | 3/3, 2/3 | MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. … | 3/3, 3/3 | 10.33 | Key clause [8.4], [8.5] at rank 1 |
| 10 | bge-small (384-d) | Overlapping paragraph | Q5 | 1. `overlapping_paragraph-015` [6.3, 6.4] 0.757<br>2. `overlapping_paragraph-036` [13.1, 13.2] 0.658<br>3. `overlapping_paragraph-010` [4.3, 4.4] 0.652 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free: a Seller may not ask for a payment, … | 3/3, 3/3 | 4.58 | Key clause [6.3] at rank 1 |
| 11 | bge-small (384-d) | Hybrid strategic | Q1 | 1. `hybrid_strategic-031` [8.5] 0.734<br>2. `hybrid_strategic-020` [6.2] 0.711<br>3. `hybrid_strategic-050` [13.1] 0.706 | 3/3, 3/3 | If you buy an item you do not like or it does not match the Listing, you may have the right to return it, but the process depends on the … | 3/3, 2/3 | 13.76 | Key clause [8.5], [13.1] at rank 1; minor unsupported inference; cites [8.2], which is not in context; **Part 3 failure F3** |
| 12 | bge-small (384-d) | Hybrid strategic | Q2 | 1. `hybrid_strategic-022` [6.4] 0.747<br>2. `hybrid_strategic-020` [6.2] 0.685<br>3. `hybrid_strategic-057` [14.4] 0.667 | 3/3, 3/3 | The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is implied that Buyers can … | 3/3, 3/3 | 5.38 | Key clause [6.4] at rank 1 |
| 13 | bge-small (384-d) | Hybrid strategic | Q3 | 1. `hybrid_strategic-020` [6.2] 0.737<br>2. `hybrid_strategic-022` [6.4] 0.710<br>3. `hybrid_strategic-031` [8.5] 0.694 | 3/3, 2/3 | The Bundle discount is not fixed, and a Buyer may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described … | 2/3, 1/3 | 7.34 | Key clause [6.4] only at rank 2; no clause says whether the discount is negotiable; unsupported claim; **Part 3 failure F2** |
| 14 | bge-small (384-d) | Hybrid strategic | Q4 | 1. `hybrid_strategic-030` [8.4] 0.800<br>2. `hybrid_strategic-051` [13.2] 0.725<br>3. `hybrid_strategic-034` [9.3] 0.716 | 3/3, 2/3 | MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. … | 3/3, 3/3 | 6.19 | Key clause [8.4], [8.5] at rank 1 |
| 15 | bge-small (384-d) | Hybrid strategic | Q5 | 1. `hybrid_strategic-021` [6.3] 0.773<br>2. `hybrid_strategic-031` [8.5] 0.667<br>3. `hybrid_strategic-050` [13.1] 0.660 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must truly be free, and a Seller may not ask for a … | 3/3, 3/3 | 3.97 | Key clause [6.3] at rank 1 |
| 16 | bge-base (768-d) | Fixed length | Q1 | 1. `fixed_length-034` [13.1, 13.2] 0.676<br>2. `fixed_length-029` [11.3] 0.641<br>3. `fixed_length-012` [5.4] 0.636 | 3/3, 2/3 | If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the … | 3/3, 3/3 | 11.96 | Key clause [8.5], [13.1] at rank 1 |
| 17 | bge-base (768-d) | Fixed length | Q2 | 1. `fixed_length-014` [6.3, 6.4] 0.660<br>2. `fixed_length-038` [14.2, 14.3, 14.4] 0.618<br>3. `fixed_length-003` [2.1, 2.2] 0.591 | 3/3, 3/3 | The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is clear that a Bundle is a … | 3/3, 3/3 | 12.86 | Key clause [6.4] at rank 1 |
| 18 | bge-base (768-d) | Fixed length | Q3 | 1. `fixed_length-034` [13.1, 13.2] 0.607<br>2. `fixed_length-014` [6.3, 6.4] 0.602<br>3. `fixed_length-013` [6.1, 6.2] 0.585 | 3/3, 2/3 | The Bundle discount is not fixed, and Buyers may negotiate it with the Seller. According to clause 6.2, every item in a Bundle must be described … | 2/3, 1/3 | 7.43 | Key clause [6.4] only at rank 2; no clause says whether the discount is negotiable; unsupported claim |
| 19 | bge-base (768-d) | Fixed length | Q4 | 1. `fixed_length-020` [8.4, 8.5] 0.721<br>2. `fixed_length-034` [13.1, 13.2] 0.683<br>3. `fixed_length-023` [9.2, 9.3] 0.657 | 3/3, 2/3 | MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. … | 3/3, 3/3 | 9.23 | Key clause [8.4], [8.5] at rank 1 |
| 20 | bge-base (768-d) | Fixed length | Q5 | 1. `fixed_length-014` [6.3, 6.4] 0.704<br>2. `fixed_length-029` [11.3] 0.616<br>3. `fixed_length-012` [5.4] 0.606 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a … | 3/3, 3/3 | 4.20 | Key clause [6.3] at rank 1 |
| 21 | bge-base (768-d) | Overlapping paragraph | Q1 | 1. `overlapping_paragraph-036` [13.1, 13.2] 0.673<br>2. `overlapping_paragraph-038` [13.4] 0.634<br>3. `overlapping_paragraph-010` [4.3, 4.4] 0.632 | 3/3, 2/3 | If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the … | 3/3, 3/3 | 7.87 | Key clause [8.5], [13.1] at rank 1 |
| 22 | bge-base (768-d) | Overlapping paragraph | Q2 | 1. `overlapping_paragraph-015` [6.3, 6.4] 0.660<br>2. `overlapping_paragraph-041` [14.3, 14.4] 0.600<br>3. `overlapping_paragraph-036` [13.1, 13.2] 0.589 | 3/3, 3/3 | No, a Buyer cannot purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in … | 1/3, 1/3 | 8.59 | Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’) |
| 23 | bge-base (768-d) | Overlapping paragraph | Q3 | 1. `overlapping_paragraph-036` [13.1, 13.2] 0.604<br>2. `overlapping_paragraph-015` [6.3, 6.4] 0.602<br>3. `overlapping_paragraph-021` [8.4, 8.5] 0.585 | 3/3, 2/3 | The Bundle discount is not fixed, and Buyers may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described … | 3/3, 3/3 | 7.91 | Key clause [6.4] only at rank 2; no clause says whether the discount is negotiable |
| 24 | bge-base (768-d) | Overlapping paragraph | Q4 | 1. `overlapping_paragraph-021` [8.4, 8.5] 0.716<br>2. `overlapping_paragraph-036` [13.1, 13.2] 0.684<br>3. `overlapping_paragraph-014` [6.1, 6.2] 0.645 | 3/3, 3/3 | MoveOn provides protection by allowing Sellers to offer the item to others if a Buyer does not show up or becomes uncontactable. The platform expects … | 3/3, 3/3 | 12.15 | Key clause [8.4], [8.5] at rank 1 |
| 25 | bge-base (768-d) | Overlapping paragraph | Q5 | 1. `overlapping_paragraph-015` [6.3, 6.4] 0.704<br>2. `overlapping_paragraph-013` [5.3, 5.4] 0.625<br>3. `overlapping_paragraph-010` [4.3, 4.4] 0.622 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a … | 3/3, 3/3 | 4.61 | Key clause [6.3] at rank 1 |
| 26 | bge-base (768-d) | Hybrid strategic | Q1 | 1. `hybrid_strategic-050` [13.1] 0.696<br>2. `hybrid_strategic-031` [8.5] 0.692<br>3. `hybrid_strategic-020` [6.2] 0.659 | 3/3, 3/3 | If you buy an item you do not like or it does not match the Listing, you may have the option to return it, but the process depends on the … | 3/3, 3/3 | 12.96 | Key clause [8.5], [13.1] at rank 1 |
| 27 | bge-base (768-d) | Hybrid strategic | Q2 | 1. `hybrid_strategic-022` [6.4] 0.716<br>2. `hybrid_strategic-057` [14.4] 0.658<br>3. `hybrid_strategic-031` [8.5] 0.609 | 3/3, 3/3 | The evidence does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is implied that Buyers can … | 3/3, 3/3 | 7.66 | Key clause [6.4] at rank 1 |
| 28 | bge-base (768-d) | Hybrid strategic | Q3 | 1. `hybrid_strategic-022` [6.4] 0.673<br>2. `hybrid_strategic-050` [13.1] 0.614<br>3. `hybrid_strategic-057` [14.4] 0.608 | 3/3, 2/3 | The evidence does not establish whether the Bundle discount is fixed or if negotiation is allowed. It states that the Bundle price must be lower than … | 3/3, 3/3 | 3.49 | Key clause [6.4] at rank 1; no clause says whether the discount is negotiable |
| 29 | bge-base (768-d) | Hybrid strategic | Q4 | 1. `hybrid_strategic-030` [8.4] 0.724<br>2. `hybrid_strategic-051` [13.2] 0.666<br>3. `hybrid_strategic-034` [9.3] 0.650 | 3/3, 2/3 | MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. … | 3/3, 3/3 | 6.12 | Key clause [8.4], [8.5] at rank 1 |
| 30 | bge-base (768-d) | Hybrid strategic | Q5 | 1. `hybrid_strategic-021` [6.3] 0.718<br>2. `hybrid_strategic-014` [4.4] 0.634<br>3. `hybrid_strategic-020` [6.2] 0.628 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must truly be free, and a Seller may not ask for a … | 3/3, 3/3 | 4.02 | Key clause [6.3] at rank 1 |
| 31 | bge-large (1024-d) | Fixed length | Q1 | 1. `fixed_length-034` [13.1, 13.2] 0.711<br>2. `fixed_length-009` [4.2, 4.3, 4.4] 0.682<br>3. `fixed_length-012` [5.4] 0.676 | 3/3, 2/3 | If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the … | 3/3, 3/3 | 10.74 | Key clause [8.5], [13.1] at rank 1 |
| 32 | bge-large (1024-d) | Fixed length | Q2 | 1. `fixed_length-014` [6.3, 6.4] 0.672<br>2. `fixed_length-016` [7.2, 7.3] 0.670<br>3. `fixed_length-009` [4.2, 4.3, 4.4] 0.670 | 3/3, 3/3 | No, a Buyer may not purchase only three items or fewer from a Bundle. The policy states that every item in a Bundle must be described individually in … | 1/3, 1/3 | 8.28 | Key clause [6.4] at rank 1; answer contradicts itself (‘No’ then ‘not restricted’) |
| 33 | bge-large (1024-d) | Fixed length | Q3 | 1. `fixed_length-034` [13.1, 13.2] 0.657<br>2. `fixed_length-013` [6.1, 6.2] 0.656<br>3. `fixed_length-020` [8.4, 8.5] 0.645 | 3/3, 2/3 | The evidence does not mention a "Bundle discount" or specify whether such a discount is fixed or negotiable. Therefore, it cannot be determined from … | 3/3, 2/3 | 3.90 | Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; minor unsupported inference; no clause citation |
| 34 | bge-large (1024-d) | Fixed length | Q4 | 1. `fixed_length-020` [8.4, 8.5] 0.729<br>2. `fixed_length-019` [8.2, 8.3] 0.701<br>3. `fixed_length-034` [13.1, 13.2] 0.696 | 3/3, 2/3 | MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. … | 3/3, 3/3 | 10.37 | Key clause [8.4], [8.5] at rank 1 |
| 35 | bge-large (1024-d) | Fixed length | Q5 | 1. `fixed_length-014` [6.3, 6.4] 0.775<br>2. `fixed_length-009` [4.2, 4.3, 4.4] 0.658<br>3. `fixed_length-003` [2.1, 2.2] 0.647 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, and a Seller may not ask for a … | 3/3, 3/3 | 4.90 | Key clause [6.3] at rank 1 |
| 36 | bge-large (1024-d) | Overlapping paragraph | Q1 | 1. `overlapping_paragraph-036` [13.1, 13.2] 0.722<br>2. `overlapping_paragraph-010` [4.3, 4.4] 0.677<br>3. `overlapping_paragraph-008` [4.1, 4.2] 0.666 | 3/3, 2/3 | If you buy an item you do not like or it does not match the Listing, you can attempt to resolve the issue through a polite conversation with the … | 3/3, 3/3 | 16.20 | Key clause [8.5], [13.1] at rank 1 |
| 37 | bge-large (1024-d) | Overlapping paragraph | Q2 | 1. `overlapping_paragraph-010` [4.3, 4.4] 0.678<br>2. `overlapping_paragraph-015` [6.3, 6.4] 0.672<br>3. `overlapping_paragraph-004` [2.1, 2.2] 0.662 | 3/3, 3/3 | The policy does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it specifies that every item in a … | 3/3, 3/3 | 11.02 | Key clause [6.4] only at rank 2 |
| 38 | bge-large (1024-d) | Overlapping paragraph | Q3 | 1. `overlapping_paragraph-036` [13.1, 13.2] 0.658<br>2. `overlapping_paragraph-021` [8.4, 8.5] 0.657<br>3. `overlapping_paragraph-014` [6.1, 6.2] 0.656 | 3/3, 2/3 | The evidence does not mention a "Bundle discount" or provide information on whether such a discount is fixed or negotiable. Therefore, it cannot be … | 3/3, 2/3 | 4.18 | Key clause [6.4] not retrieved; no clause says whether the discount is negotiable; minor unsupported inference; no clause citation |
| 39 | bge-large (1024-d) | Overlapping paragraph | Q4 | 1. `overlapping_paragraph-021` [8.4, 8.5] 0.737<br>2. `overlapping_paragraph-036` [13.1, 13.2] 0.696<br>3. `overlapping_paragraph-020` [8.2, 8.3] 0.685 | 3/3, 2/3 | MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. … | 3/3, 3/3 | 10.30 | Key clause [8.4], [8.5] at rank 1 |
| 40 | bge-large (1024-d) | Overlapping paragraph | Q5 | 1. `overlapping_paragraph-015` [6.3, 6.4] 0.775<br>2. `overlapping_paragraph-010` [4.3, 4.4] 0.669<br>3. `overlapping_paragraph-021` [8.4, 8.5] 0.655 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must be truly free, meaning a Seller may not ask for a … | 3/3, 3/3 | 4.64 | Key clause [6.3] at rank 1 |
| 41 | bge-large (1024-d) | Hybrid strategic | Q1 | 1. `hybrid_strategic-050` [13.1] 0.715<br>2. `hybrid_strategic-031` [8.5] 0.697<br>3. `hybrid_strategic-020` [6.2] 0.685 | 3/3, 3/3 | If you buy an item you do not like or it does not match the Listing, you may have the option to return it, but the process depends on the … | 3/3, 3/3 | 13.14 | Key clause [8.5], [13.1] at rank 1 |
| 42 | bge-large (1024-d) | Hybrid strategic | Q2 | 1. `hybrid_strategic-022` [6.4] 0.765<br>2. `hybrid_strategic-057` [14.4] 0.681<br>3. `hybrid_strategic-031` [8.5] 0.672 | 3/3, 3/3 | The evidence does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is implied that Buyers can … | 3/3, 3/3 | 7.77 | Key clause [6.4] at rank 1 |
| 43 | bge-large (1024-d) | Hybrid strategic | Q3 | 1. `hybrid_strategic-022` [6.4] 0.719<br>2. `hybrid_strategic-020` [6.2] 0.693<br>3. `hybrid_strategic-031` [8.5] 0.670 | 3/3, 2/3 | The Bundle discount is not fixed, and a Buyer may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described … | 3/3, 3/3 | 10.50 | Key clause [6.4] at rank 1; no clause says whether the discount is negotiable |
| 44 | bge-large (1024-d) | Hybrid strategic | Q4 | 1. `hybrid_strategic-030` [8.4] 0.718<br>2. `hybrid_strategic-032` [9.1] 0.686<br>3. `hybrid_strategic-051` [13.2] 0.675 | 3/3, 2/3 | MoveOn does not provide direct help or protection in cases where a Buyer does not show up or has a payment problem and can no longer be contacted. … | 3/3, 3/3 | 5.82 | Key clause [8.4], [8.5] at rank 1 |
| 45 | bge-large (1024-d) | Hybrid strategic | Q5 | 1. `hybrid_strategic-021` [6.3] 0.766<br>2. `hybrid_strategic-031` [8.5] 0.657<br>3. `hybrid_strategic-014` [4.4] 0.655 | 3/3, 3/3 | No, a seller may not require a donation for a free item. According to the policy, a Giveaway must truly be free, and a Seller may not ask for a … | 3/3, 3/3 | 4.10 | Key clause [6.3] at rank 1 |

#### Worked example with full retrieved chunks

`large_67_clauses__bge_base__hybrid_strategic__bundle_three_items` — Q2, bge-base, hybrid strategic. Context 3/3, 3/3; answer 3/3, 3/3.

**Rank 1 — `hybrid_strategic-022`, clauses [6.4], page(s) 7, 8, cosine 0.716**

> Sellers may group related items into Bundles, such as a kitchen starter set or a desk-and-chair pair, and the team may highlight selected bundles as Featured Bundles. Every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. A Seller may not force a Buyer to take an unwanted item to get a wanted one unless the Listing clearly says the Bundle is sold as a set. Featured Bundles are selected by the team on the basis of quality, safety, and usefulness to students, and not by payment. If the platform ever accepts promotion fees, those listings must be clearly labeled as promoted.

**Rank 2 — `hybrid_strategic-057`, clauses [14.4], page(s) 14, cosine 0.658**

> Featured Bundles help new students equip a room in one trip, and the team may build seasonal collections such as a "first-week kit" or a "kitchen starter set". Items included in a Featured Bundle must pass a quick quality and safety check, and the Seller must agree to the Bundle terms. The team will explain how Bundles are chosen so that the process is fair, and will rotate them so that different Sellers get exposure. Seasonal campaigns may be run with student groups, but may not carry advertising that conflicts with Section 6.

**Rank 3 — `hybrid_strategic-031`, clauses [8.5], page(s) 9, cosine 0.609**

> Buyers have the right to inspect an item before they pay, and Sellers should allow time to test it, plug it in, or open it. A Buyer who finds that an item differs from the Listing may decline it or ask for a lower price. Once payment is made and the item leaves the Seller's hands, the sale is final unless the Seller agreed otherwise in writing or the Seller knowingly gave false information, in which case the Buyer may ask the team to review the case under Section 13.

**Answer:** The evidence does not explicitly state whether a Buyer can purchase only three items or fewer from a Bundle. However, it is implied that Buyers can purchase individual items from a Bundle, as every item in a Bundle must be described individually in the Listing [6.4]. Additionally, the policy allows Buyers to decline an item if it differs from the Listing [8.5], suggesting that partial purchases may be possible. Since the policy does not explicitly restrict the number of items a Buyer can purchase from a Bundle, it is reasonable to infer that a Buyer could purchase three items or fewer from a Bundle.

### 2.3 Comparing embedding models

Full 67-clause corpus (15 runs per model; the key-clause columns show whether retrieval found the clause that answers the question):

| Embedding model | Context relevance | Context completeness | Answer relevance | Groundedness | Key clause at rank 1 | Key clause in top-3 | Mean latency (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| bge-small (384-d) | 3.00 | 2.47 | 2.67 | 2.47 | 12/15 | 13/15 | 7.58 |
| bge-base (768-d) | 3.00 | 2.53 | 2.80 | 2.73 | 13/15 | 15/15 | 8.07 |
| bge-large (1024-d) | 3.00 | 2.47 | 2.87 | 2.73 | 12/15 | 13/15 | 8.39 |

All 90 runs (both corpus sizes):

| Embedding model | Context relevance | Context completeness | Answer relevance | Groundedness | Mean latency (s) |
|---|---:|---:|---:|---:|---:|
| bge-small (384-d) | 2.17 | 1.77 | 2.77 | 2.70 | 6.61 |
| bge-base (768-d) | 2.10 | 1.77 | 2.83 | 2.87 | 6.54 |
| bge-large (1024-d) | 2.27 | 1.77 | 2.80 | 2.87 | 6.93 |

**Retrieval quality.** Embedding size made only a small difference. All three models scored 3.00 context relevance on the full corpus. **bge-base was the most reliable retriever**: it was the only model that had the key clause in the top-3 for all 15 queries (small and large each missed it twice, both times on the hard Q3 Bundle-discount question with fixed/overlapping chunks). bge-large had the best all-runs context relevance (2.27 vs 2.17 / 2.10), but that difference comes from the small corpus, where no model can retrieve clauses that are missing.

**Answer quality.** bge-small had the lowest groundedness (2.47 full corpus): three of the four Part 3 failures used small-model retrieval. bge-base and bge-large tied at 2.73 groundedness; large had slightly higher answer relevance (2.87 vs 2.80). Because the generator is fixed, these answer differences come from which chunks were retrieved — e.g. small/hybrid on Q3 retrieved [6.2] first, and the model turned its agreed-price rule into an invented "negotiation" right.

**Did larger embeddings always perform better? No.** bge-large (3× the parameters and 1.33× the storage of bge-base) did not beat bge-base on context relevance, completeness or groundedness, and missed the Q3 key clause twice where base did not. Raw cosine scores are not comparable across models either (bge-small's top-1 mean was the highest, 0.740, without being the best retriever). On a small, clearly worded policy corpus the medium model is the best quality-per-cost choice; larger models are more likely to pay off on bigger, noisier or more paraphrased corpora.

### 2.4 Comparing chunking strategies

Full 67-clause corpus (15 runs per strategy):

| Chunking strategy | Context relevance | Context completeness | Answer relevance | Groundedness | Key clause at rank 1 | Key clause in top-3 | Mean latency (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Fixed length | 3.00 | 2.40 | 2.67 | 2.47 | 12/15 | 13/15 | 8.13 |
| Overlapping paragraph | 3.00 | 2.47 | 2.73 | 2.67 | 11/15 | 13/15 | 8.43 |
| Hybrid strategic | 3.00 | 2.60 | 2.93 | 2.80 | 14/15 | 15/15 | 7.48 |

All 90 runs:

| Chunking strategy | Context relevance | Context completeness | Answer relevance | Groundedness | Mean latency (s) |
|---|---:|---:|---:|---:|---:|
| Fixed length | 2.13 | 1.70 | 2.70 | 2.73 | 6.89 |
| Overlapping paragraph | 2.13 | 1.73 | 2.73 | 2.80 | 7.20 |
| Hybrid strategic | 2.27 | 1.87 | 2.97 | 2.90 | 5.99 |

**Which worked better? Hybrid/strategic (one clause per chunk)** — best or tied-best on every quality measure, and the fastest (smallest prompts: 610 input tokens vs 888 fixed and 981 overlapping).

**Why?** The policy is written as self-contained clauses, so a clause-sized chunk has one topic and one embedding that represents it sharply. Fixed-length and overlapping chunks join two or three clauses, so the vector is an average of several topics: the Bundle rule [6.4] shares a chunk with the Giveaway rule [6.3], and the query's similarity to the combined vector is diluted.

**Effect on retrieval relevance.** Hybrid put the key clause at rank 1 in 14/15 queries and in the top-3 in 15/15. Fixed and overlapping missed [6.4] for Q3 in 2 of 3 models each, because the more general pricing chunk [6.1+6.2] and dispute chunk [13.1+13.2] outranked the combined [6.3+6.4] chunk.

**Effect on final answers.** All four contradictory Q2 answers ("No, a Buyer may not purchase three or fewer… however, it does not explicitly restrict…") came from fixed or overlapping chunks, where the model saw the Giveaway and Bundle rules mixed together; hybrid had none. Smaller chunks also mean less irrelevant text for the model to misread. The trade-off: clause-sized chunks can cut off context when an answer needs neighbouring clauses, which is why the dependent pair 3.3+3.4 is kept together, and why for Q3 the larger fixed-length chunks gave the better answer (Part 3.3).

### 2.5 Data scaling experiment

The same 9 configurations and 5 queries were run on a **smaller dataset** (the first 20 clauses, 1.1–6.1, 2,125 words) and the **larger dataset** (all 67 clauses, 6,684 words). The small subset deliberately lacks the key clauses for all five queries (they are in sections 6–13), which shows how the system behaves when relevant data is missing.

| Corpus | Chunks per index | Context relevance | Context completeness | Answer relevance | Groundedness | Mean top-1 cosine | Mean gap rank 1 → rank 3 | Mean latency (s) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Small (20 clauses) | 12 / 13 / 19 | 1.36 | 1.04 | 2.82 | 2.98 | 0.645 | 0.024 | 5.37 |
| Large (67 clauses) | 46 / 48 / 66 | 3.00 | 2.49 | 2.78 | 2.64 | 0.714 | 0.058 | 8.02 |

(Chunks per index: fixed / overlapping / hybrid.)

**Effect on retrieval quality.** More data greatly improved retrieval: context relevance rose from 1.36 to 3.00 and completeness from 1.04 to 2.49, because the answering clauses only exist in the larger corpus. Retrieval cannot be better than the knowledge base behind it.

**Effect on noise.** With the small corpus, top-k is still always filled with 3 chunks, so most answers received three mostly *irrelevant* passages (ownership, listing and account rules; only Q3 still found the general pricing clause [6.1]). Those passages scored nearly as high as real matches (top-1 cosine 0.645 vs 0.714), and the spread between rank 1 and rank 3 shrank from 0.058 to 0.024: the ranking became nearly flat, so a fixed score threshold could not separate signal from noise. In the larger corpus the right clause stands out more clearly. More data also adds *distractors* — e.g. Q3 retrieved dispute and pricing clauses ahead of [6.4] — which is why the large corpus had more unsupported inferences (groundedness 2.64 vs 2.98).

**Effect on answers.** Small-corpus groundedness looks high (2.98) because the model usually said the evidence was insufficient — a good behaviour — but the answers were not useful. Noise still leaked in: in F4 (Part 3) the model guessed a Giveaway rule from unrelated definition and ownership clauses. The larger corpus was slower: mean latency rose from 5.37 s to 8.02 s. Prompt sizes were similar (862 vs 826 tokens); the difference is longer answers (74 → 117 output tokens) once relevant evidence was available. Search itself stayed under 11 ms.

---

## Part 3: Failure analysis and improvement

### 3.1 Failure cases

Four failures from the Part 2 runs (verified automatically by `src/part3_analysis.py` against the saved traces):

| # | Record (model / strategy / corpus) | Query | Retrieved chunks [clauses] | What went wrong |
|---|---|---|---|---|
| F1 | bge-small / fixed / 67 clauses | Q2 Bundle of three or fewer | `fixed_length-014` [6.3, 6.4]; `fixed_length-038` [14.2–14.4]; `fixed_length-009` [4.2–4.4] | **Incorrect, self-contradicting answer.** Opens "No, a Buyer may not purchase only three items or fewer from a Bundle", then says the policy "does not explicitly restrict the number of items". The same contradiction appears in 3 other fixed/overlapping runs. |
| F2 | bge-small / hybrid / 67 clauses | Q3 Bundle discount negotiable? | `hybrid_strategic-020` [6.2]; `-022` [6.4]; `-031` [8.5] | **Hallucinated rule.** "The Bundle discount is not fixed, and a Buyer may negotiate it with the Seller." No clause says this; [6.4] only caps the Bundle price. |
| F3 | bge-small / hybrid / 67 clauses | Q1 Returns | `hybrid_strategic-031` [8.5]; `-020` [6.2]; `-050` [13.1] | **Wrong citation.** Says a Buyer may decline an item without penalty and cites **[8.2]**, which was not retrieved; the statement actually comes from [6.2]. |
| F4 | bge-large / hybrid / 20 clauses | Q5 Donation for a free item | `hybrid_strategic-014` [4.4]; `-005` [2.1]; `-013` [4.3] | **Incomplete context → overclaim.** The rule [6.3] is not in the small corpus, so retrieval returned unrelated ownership/definition clauses; the model still concluded a donation would "likely contradict" a Giveaway instead of abstaining. (Part 2's review scored it 3/3 because the answer hedges; on closer review we count it as a failure, since the conclusion rests on no retrieved rule.) |

### 3.2 Root cause analysis

| Failure | Chunking? | Embedding model? | Query formulation? | Root cause |
|---|---|---|---|---|
| F1 | **Contributing.** The 180-word chunk merges the Giveaway rule [6.3] with the Bundle rule [6.4]; the contradiction only occurred with merged (fixed/overlapping) chunks, never with hybrid. | No — happened with small, base and large. | Partly — the question presupposes a "three items" rule, inviting a yes/no answer the policy doesn't support. | **Generation consistency**, made more likely by mixed-topic chunks. The right clause *was* retrieved. |
| F2 | Contributing — clause-sized chunks gave [6.2] ("honour the agreed price") without its surrounding context. | Contributing — bge-small ranked the general pricing clause [6.2] above the Bundle clause [6.4]. | Yes — the question asks about a "discount" and "negotiation", terms the policy never uses, so no chunk can match it directly. | **Generation inference**: the model filled a gap with a plausible rule instead of saying the policy is silent. |
| F3 | No — the supporting clause [6.2] was retrieved intact. | No. | No — the question is explicit. | **Generation / citation control**: the model mislabelled a clause ID. |
| F4 | No — [6.3] was excluded before chunking. | No — no model can retrieve a missing clause. | No — "donation" and "free item" are explicit. | **Corpus coverage gap** (data), followed by a generation overclaim on noisy context. |

The common thread: retrieval usually found the right evidence on the full corpus, and most errors happened when the generator went beyond it. Chunking and query wording raised the risk (F1, F2); missing data caused F4.

### 3.3 System improvement — adjust chunk size (fixes F2)

**Change:** for the Bundle-discount question, use the 180-word fixed-length chunks instead of clause-sized hybrid chunks. Everything else is identical: query, 67-clause corpus, bge-small, top-k = 3, Qwen3-4B, prompt and greedy decoding.

| | Before: clause-sized chunks (hybrid) | After: 180-word target chunks (fixed) |
|---|---|---|
| Retrieved chunks | `hybrid_strategic-020`, `hybrid_strategic-022`, `hybrid_strategic-031` | `fixed_length-013`, `fixed_length-034`, `fixed_length-020` |
| Retrieved clauses | [6.2], [6.4], [8.5] | [13.1], [13.2], [6.1], [6.2], [8.4], [8.5] |
| Chunk sizes (words) | 113, 121, 90 | 229, 176, 161 |
| Answer | "The Bundle discount is not fixed, and a Buyer may negotiate it with the Seller. According to clause 6.4, every item in a Bundle must be described individually in the Listing, and the Bundle price must be lower than or equal to the combined price of its parts. This implies that the Bundle price is determined by the Seller and may be subject to negotiation, as there is no explicit rule that the Bundle discount is fixed or non-negotiable. However, the platform does not provide specific guidance on negotiation practices for Bundle discounts. [6.4]" | "The evidence does not mention a "Bundle discount" or specify whether such a discount is fixed or negotiable. Therefore, it cannot be determined from the provided policy evidence whether the Bundle discount is fixed or can be negotiated." |
| Answer relevance / groundedness | 2/3, **1/3** | 3/3, **3/3** |
| Latency | 7.34 s | 3.45 s |

**Result:** the hallucinated negotiation rule disappears and the system correctly says the policy does not answer the question (groundedness 1 → 3, latency 7.34 s → 3.45 s). A likely reason: the larger chunk gave the model [6.1]+[6.2] together, so the "agreed price" sentence was read in its full pricing context instead of being stretched into a negotiation right. The answer is also much shorter (45 vs 114 output tokens), which explains the lower latency.

**Limits:** this is one paired case. The larger chunks no longer include [6.4], and Part 2 showed fixed-length chunks are worse on average, so the selected configuration (`A8_results/Part3/selected_configuration.json`) applies to this question type only. As a second, output-side fix for F3, `src/part3_analysis.py` includes a **citation guard** that checks every cited clause ID against the retrieved context and flags F3's invalid [8.2] (`citation_guard_results.jsonl`); it cannot catch an unsupported claim that cites a valid clause.

---

## Part 4: System design reflection

Measurements come from the 90 Part 2 runs (`src/part4_cost_analysis.py` → `A8_results/Part4/cost_analysis.md` / `.json`). Scaling figures are estimates with the stated assumptions.

### 4.1 Cost awareness

**Where the cost is today.** Per query, query embedding takes ~15 ms and the similarity search 0.3 ms, but LLM generation takes 6.68 s — **99.8% of query time**. Generation time is almost exactly explained by token counts (R² = 0.998):

> generation seconds ≈ -1.17 + 2.1 ms × input tokens + 63.5 ms × output tokens

and prompt size by retrieved text (R² = 0.987): **input tokens ≈ 230 + 1.26 × retrieved words**. So anything that changes how much text reaches the LLM changes cost; anything that only affects retrieval barely does. (With a paid LLM API the same holds: price is per token.)

| Factor | What it changes | Measured effect in our system | Impact on cost |
|---|---|---|---|
| **top-k retrieval** | Number of chunks in every prompt | Prompt tokens grow linearly with k: hybrid 359 → 619 → 1527 tokens for k = 1 / 3 / 10; overlapping reaches 2793 at k = 10. | **Highest** — paid on every query, multiplies with chunk size. |
| **Chunk size** | Words per retrieved chunk (and index size) | At k = 3: hybrid (101 words/chunk) 610 tokens, 7.48 s; overlapping (183) 981 tokens, 8.43 s (+61% tokens). Overlap also stores 31% duplicate text. | **High** — same per-query multiplier as top-k. |
| **Embedding size** | Vector storage, encoding compute, query latency | 1.5 / 3 / 4 KB per vector (384/768/1024-d); 1.4 / 2.9 / 3.8 GiB per million chunks; query encode 13 / 12 / 21 ms; 10× more parameters small → large. Our whole index is under 300 KiB. | **Low per query**; grows with corpus size (vector DB memory, re-embedding everything when the model changes). |

![Projected prompt tokens vs top-k](A8_results/Part4/topk_prompt_tokens.png)

**Conclusion.** Among the three factors, the ranking is **top-k ≈ chunk size ≫ embedding size**. top-k and chunk size multiply into prompt tokens, which are paid on every query (k = 10 with overlapping chunks would mean ~4.6× our current prompt). Embedding size is mostly a one-time indexing cost plus a few milliseconds per query; it becomes a main cost only at millions of chunks or when the corpus must be re-embedded. Since bge-base matched bge-large's groundedness at one-third of the parameters, a larger embedding model would add cost without a quality gain here.

Outside those three factors, the biggest single driver on our hardware is **answer length**: one output token costs ≈ 30× an input token, so a typical answer (116 tokens ≈ 7.4 s) takes longer than reading the whole prompt (610 tokens ≈ 1.3 s). That is why the prompt asks for concise answers and output is capped at 512 tokens. Retrieval settings also affect answer length indirectly: in 2.5, more relevant context produced longer answers. The cheapest setup — hybrid chunks, k = 3, bge-base — was also the most accurate.

### 4.2 RAG vs alternatives

| Approach | When to use | Strengths | Weaknesses / cost | For MoveOn |
|---|---|---|---|---|
| **RAG** | Knowledge that changes, must be cited, or is larger than the context window; factual Q&A over documents. | Update by re-indexing (minutes, no training); answers cite the source clause; failures can be traced to retrieved chunks (as in Part 3); can say "not in the policy". | Extra retrieval infrastructure; quality capped by retrieval and chunking; ~610 prompt tokens per query. | **Best fit.** The policy is a draft (v1.0) that will be revised, and users need clause-level citations. |
| **Fine-tuning** | Teaching *behaviour* rather than facts: tone, output format, domain vocabulary, consistent refusal; knowledge that is stable; large labelled data available. | Short prompts at inference; consistent style; can make a small model follow rules better. | GPU training and labelled data up front; must retrain on every policy change; facts baked into weights can't be cited and may be hallucinated; hard to audit. | **Complement, not replacement.** Most Part 3 failures were generation errors (contradiction, invented rule, wrong citation); fine-tuning Qwen3-4B on "answer only from evidence / abstain / cite" examples could reduce them while RAG still supplies the facts. |
| **Pure prompting** | Small, stable knowledge that fits in the context window; prototypes; general tasks that need no private data. | No index or pipeline; simplest to build. | The whole policy in every prompt ≈ **8,628 input tokens per query** (≈14× our RAG prompts); exceeds our 4,096-token budget; long contexts slow generation and bury the relevant clause; doesn't scale to more documents. | Fine as a quick baseline; too costly and slow at 10K users/day. |

### 4.3 System design for 10K users/day

**Load estimate** (assumptions: 3 queries per user per day, 15% of traffic in the busiest hour — e.g. move-in week — 30% answer-cache hit rate, ×8 throughput from continuous batching, $0.35/GPU-hour):

| Quantity | Estimate |
|---|---:|
| Queries per day | 30,000 |
| Average / peak queries per second | 0.35 / 1.25 |
| LLM tokens per day (input / output) | 18.3 M / 3.5 M |
| GPUs at peak serving one answer at a time (as in our experiments) | 10 (≈ $84/day) |
| GPUs at peak with answer cache + continuous batching (+1 spare) | 2 (≈ $17/day) |
| Generator memory (measured peak) | 10.5 GB → fits one 16 GB T4 or 24 GB L4 |

Retrieval is not the bottleneck: one bge-base instance encodes a query in ~12 ms (measured on the T4), so a single CPU/GPU instance handles peak load, and the 66-chunk index (198 KiB) fits in memory on every server. The LLM is the component to scale.

#### Architecture diagram

![System design](A8_results/Part4/system_design.png)

```mermaid
flowchart LR
    U[User] --> Q[Query<br/>API gateway, auth, rate limit]
    Q --> C{Answer cache<br/>hit?}
    C -- hit --> RESP
    C -- miss --> E[Embedding<br/>bge-base-en-v1.5]
    E --> V[(Vector Store<br/>cosine top-k = 3)]
    V --> RC[Retrieved Context<br/>clause IDs + pages]
    RC --> L[LLM<br/>Qwen3-4B on vLLM]
    L --> G[Citation guard]
    G --> RESP[Response]
    subgraph OFF [Offline ingestion]
      P[Policy PDF] --> X[Clause extraction] --> H[Hybrid chunking] --> B[Batch embedding]
    end
    B -- new index version --> V
    RESP -.-> M["Monitoring: latency, tokens, cache hits, guard failures"]
```

Plain-text version of the required flow:

```
User → Query → Embedding → Vector Store → Retrieved Context → LLM → Response
        │ (API gateway,  (bge-base,   (top-k = 3,      (≤ 4,096-token   (Qwen3-4B,  (citation guard,
        │  cache check)   ~12 ms)      cosine)          prompt)          vLLM)       streamed)
        └── cache hit ───────────────────────────────────────────────────────────────▶ Response
Offline: Policy PDF → clause extraction → hybrid chunking → batch embedding → new index version → Vector Store
```

**Components and how they scale**

1. **API gateway / query service** — authentication (university login), per-user rate limits, input length limits. Stateless; scale horizontally behind a load balancer.
2. **Answer cache** — key = normalised query + index version. Policy questions repeat heavily ("can I return…", "is a giveaway free…"), so a cache skips the expensive LLM call; it is cleared automatically when a new index version is published. A semantic cache (reuse an answer when a new query's embedding is very close to a cached one) can raise the hit rate once a safe threshold is validated.
3. **Embedding service** — bge-base, batched requests, small CPU or shared GPU instance.
4. **Vector store** — today an in-memory NumPy matrix (exact search, 0.3 ms). If MoveOn adds more documents (help articles, other university policies, >100K chunks), move to an approximate-nearest-neighbour index (FAISS HNSW, pgvector or Qdrant) with metadata filters such as policy version and section.
5. **Context builder** — top-k = 3 hybrid chunks within a 4,096-token budget, dropping whole low-ranked chunks if needed.
6. **LLM serving** — Qwen3-4B on vLLM: continuous batching (many users share one GPU), paged KV cache, prefix caching for the fixed system instruction, token streaming so users see text in under a second. Autoscale GPU replicas on queue length; keep one spare for failover.
7. **Citation guard** (from Part 3) — rejects or flags answers that cite clauses not in the retrieved context; falls back to "the policy does not say — see section X".
8. **Offline ingestion** — when the policy is revised: extract → chunk → embed → build a new versioned index, re-run the Part 2 query set as a regression test, then swap atomically.
9. **Monitoring** — p50/p95 latency, tokens per query, cache hit rate, guard failures, and a weekly human review of a sample using the Part 2 rubric.

**What we would optimize (in order of impact)**

1. **LLM throughput:** continuous batching (the biggest saving — ≈10 GPUs → 2 at peak), and 8-bit or 4-bit quantization of Qwen3-4B to fit cheaper GPUs, re-checked on the Part 2 queries before adoption.
2. **Prompt size:** keep hybrid chunks and k = 3 (smallest prompts *and* best groundedness); trim the system prompt; lower `max_new_tokens` from 512 to ~256 (longest observed answer: 232 tokens).
3. **Caching:** answer cache plus query-embedding cache.
4. **Skip the LLM when retrieval is weak:** if no chunk passes a calibrated similarity threshold, return a "not covered by the policy" answer. Part 2.5 shows irrelevant chunks still score 0.55–0.71, so the threshold must be tuned per model.
5. **Answer quality at scale:** citation guard, a self-consistency check for yes/no answers (F1), and query rewriting for terms the policy doesn't use (F2: "discount", "negotiate").
6. **Embedding model:** stay with bge-base (or bge-small for CPU-only serving) — bge-large adds cost without improving answers here.

---

## Reproducibility

- `rag_system.ipynb` runs Parts 1–4 top to bottom (GPU recommended; see `README.md`). Its saved outputs come from the Colab T4 runs analysed here.
- Parts 3 and 4 also run without a GPU or model downloads: `python src/part3_analysis.py` and `python src/part4_cost_analysis.py`.
- Part 2 traces: `A8_results/Part2/20261031/experiment_results.jsonl` (full prompts, retrieved chunks, answers, token counts, timings); reviewed scores and full chunk text: `evaluation_table.csv`; readable full appendix: `evaluation_table_full.md`.
